-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: tabletra1_v1_3_02
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `area_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `areas_branch_id_foreign` (`branch_id`),
  CONSTRAINT `areas_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,1,'Dhanmondi','0503e59c987423e201435bbc12fbde4f.jpg','2026-06-06 02:04:56','2026-06-06 02:04:56'),(2,3,'Garden Area','a67f7e9a11b1dec84e5b3b6c538bfa27.jpg','2026-06-10 00:48:48','2026-06-10 00:48:48'),(3,3,'Floor 01','736c412e485e6c833653cba6f7f5fa1c.jpg','2026-06-10 01:17:01','2026-06-10 01:17:01'),(4,3,'Rooftop','6effdcf374abd35017aa502cdd979d87.jpg','2026-06-10 01:17:49','2026-06-10 01:17:49');
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assign_waiter_to_tables`
--

DROP TABLE IF EXISTS `assign_waiter_to_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assign_waiter_to_tables` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `table_id` bigint unsigned NOT NULL,
  `waiter_id` bigint unsigned DEFAULT NULL,
  `backup_waiter_id` bigint unsigned DEFAULT NULL,
  `assigned_by` bigint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assign_waiter_to_tables_waiter_id_foreign` (`waiter_id`),
  KEY `assign_waiter_to_tables_backup_waiter_id_foreign` (`backup_waiter_id`),
  KEY `assign_waiter_to_tables_assigned_by_foreign` (`assigned_by`),
  KEY `assign_waiter_to_tables_table_id_waiter_id_index` (`table_id`,`waiter_id`),
  KEY `assign_waiter_to_tables_is_active_index` (`is_active`),
  CONSTRAINT `assign_waiter_to_tables_assigned_by_foreign` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `assign_waiter_to_tables_backup_waiter_id_foreign` FOREIGN KEY (`backup_waiter_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assign_waiter_to_tables_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `assign_waiter_to_tables_waiter_id_foreign` FOREIGN KEY (`waiter_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assign_waiter_to_tables`
--

LOCK TABLES `assign_waiter_to_tables` WRITE;
/*!40000 ALTER TABLE `assign_waiter_to_tables` DISABLE KEYS */;
INSERT INTO `assign_waiter_to_tables` VALUES (1,5,11,11,10,1,'2026-06-10','2026-06-10','2026-06-10 03:05:52','2026-06-10 03:05:52');
/*!40000 ALTER TABLE `assign_waiter_to_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch_delivery_settings`
--

DROP TABLE IF EXISTS `branch_delivery_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch_delivery_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `max_radius` decimal(8,2) NOT NULL DEFAULT '5.00',
  `unit` enum('km','miles') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'km',
  `fee_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `fixed_fee` decimal(8,2) DEFAULT NULL,
  `per_distance_rate` decimal(8,2) DEFAULT NULL,
  `free_delivery_over_amount` decimal(8,2) DEFAULT NULL,
  `free_delivery_within_radius` double DEFAULT NULL,
  `delivery_schedule_start` time DEFAULT NULL,
  `delivery_schedule_end` time DEFAULT NULL,
  `prep_time_minutes` int NOT NULL DEFAULT '20',
  `additional_eta_buffer_time` int DEFAULT NULL,
  `avg_delivery_speed_kmh` int NOT NULL DEFAULT '30',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `branch_delivery_settings_branch_id_foreign` (`branch_id`),
  CONSTRAINT `branch_delivery_settings_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch_delivery_settings`
--

LOCK TABLES `branch_delivery_settings` WRITE;
/*!40000 ALTER TABLE `branch_delivery_settings` DISABLE KEYS */;
INSERT INTO `branch_delivery_settings` VALUES (1,3,20.00,'km','tiered',NULL,NULL,NULL,NULL,'13:00:00','22:00:00',20,10,30,1,'2026-06-10 02:27:20','2026-06-10 02:29:01');
/*!40000 ALTER TABLE `branch_delivery_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch_operational_shifts`
--

DROP TABLE IF EXISTS `branch_operational_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch_operational_shifts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `shift_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Optional name for the shift (e.g., Morning Shift, Evening Shift)',
  `start_time` time NOT NULL COMMENT 'Start time of the shift (e.g., 09:00 for 9 AM)',
  `end_time` time NOT NULL COMMENT 'End time of the shift (e.g., 14:00 for 2 PM or 01:00 for 1 AM next day)',
  `day_of_week` json NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT 'Display order for shifts',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `branch_operational_shifts_branch_id_is_active_index` (`branch_id`,`is_active`),
  KEY `branch_operational_shifts_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `branch_operational_shifts_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `branch_operational_shifts_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch_operational_shifts`
--

LOCK TABLES `branch_operational_shifts` WRITE;
/*!40000 ALTER TABLE `branch_operational_shifts` DISABLE KEYS */;
INSERT INTO `branch_operational_shifts` VALUES (1,1,1,'Full Day Shift','03:00:00','17:59:00','[\"Monday\", \"Tuesday\", \"Wednesday\", \"Thursday\", \"Friday\", \"Saturday\", \"Sunday\"]',1,0,'2026-06-09 05:52:10','2026-06-09 22:16:56');
/*!40000 ALTER TABLE `branch_operational_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unique_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cloned_branch_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cloned_branch_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_menu_clone` tinyint(1) NOT NULL DEFAULT '0',
  `is_item_categories_clone` tinyint(1) NOT NULL DEFAULT '0',
  `is_menu_items_clone` tinyint(1) NOT NULL DEFAULT '0',
  `is_item_modifiers_clone` tinyint(1) NOT NULL DEFAULT '0',
  `is_clone_reservation_settings` tinyint(1) NOT NULL DEFAULT '0',
  `is_clone_delivery_settings` tinyint(1) NOT NULL DEFAULT '0',
  `is_clone_kot_setting` tinyint(1) NOT NULL DEFAULT '0',
  `is_modifiers_groups_clone` tinyint(1) NOT NULL DEFAULT '0',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cr_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lng` decimal(10,7) DEFAULT NULL,
  `count_orders` int NOT NULL DEFAULT '0',
  `total_orders` int NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_unique_hash_unique` (`unique_hash`),
  KEY `branches_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `branches_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'117044f3fb0bb7938693',1,'Kacchi Vai',NULL,NULL,0,0,0,0,0,0,0,0,'Dhanmondi, Dhaka-1205',NULL,NULL,'2026-06-05 23:44:08','2026-06-10 23:13:00',26.9124336,75.7872719,23,-1),(2,'49d315bc7a9890472308',1,'Delhi',NULL,NULL,0,0,0,0,0,0,0,0,'12, Connaught Place, New Delhi, Delhi 110001, India',NULL,NULL,'2026-06-05 23:44:09','2026-06-05 23:44:09',28.6284541,77.2069816,0,-1),(3,'0c709bc94e5d5167d018',1,'Sultan Dine',NULL,NULL,0,0,0,0,0,0,0,0,'Mirpur 10 Road, Dhaka, Dhaka Division, Bangladesh','TRAD/DNCC/041852/2026','e-TIN : 518493027461','2026-06-10 00:34:49','2026-06-10 23:27:51',23.8007525,90.3565779,20,-1);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_header_images`
--

DROP TABLE IF EXISTS `cart_header_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_header_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_header_setting_id` bigint unsigned NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_header_images_cart_header_setting_id_foreign` (`cart_header_setting_id`),
  CONSTRAINT `cart_header_images_cart_header_setting_id_foreign` FOREIGN KEY (`cart_header_setting_id`) REFERENCES `cart_header_settings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_header_images`
--

LOCK TABLES `cart_header_images` WRITE;
/*!40000 ALTER TABLE `cart_header_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_header_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_header_settings`
--

DROP TABLE IF EXISTS `cart_header_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_header_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `header_type` enum('text','image') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `header_text` text COLLATE utf8mb4_unicode_ci,
  `is_header_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_header_settings_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `cart_header_settings_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_header_settings`
--

LOCK TABLES `cart_header_settings` WRITE;
/*!40000 ALTER TABLE `cart_header_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_header_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_item_modifier_options`
--

DROP TABLE IF EXISTS `cart_item_modifier_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_item_modifier_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_item_id` bigint unsigned DEFAULT NULL,
  `modifier_option_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_item_modifier_options_cart_item_id_foreign` (`cart_item_id`),
  KEY `cart_item_modifier_options_modifier_option_id_foreign` (`modifier_option_id`),
  CONSTRAINT `cart_item_modifier_options_cart_item_id_foreign` FOREIGN KEY (`cart_item_id`) REFERENCES `cart_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_item_modifier_options_modifier_option_id_foreign` FOREIGN KEY (`modifier_option_id`) REFERENCES `modifier_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_item_modifier_options`
--

LOCK TABLES `cart_item_modifier_options` WRITE;
/*!40000 ALTER TABLE `cart_item_modifier_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_item_modifier_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_session_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `menu_item_id` bigint unsigned DEFAULT NULL,
  `menu_item_variation_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `tax_amount` decimal(16,2) DEFAULT NULL,
  `tax_percentage` decimal(8,4) DEFAULT NULL,
  `tax_breakup` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_items_cart_session_id_foreign` (`cart_session_id`),
  KEY `cart_items_branch_id_foreign` (`branch_id`),
  KEY `cart_items_menu_item_id_foreign` (`menu_item_id`),
  KEY `cart_items_menu_item_variation_id_foreign` (`menu_item_variation_id`),
  CONSTRAINT `cart_items_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_cart_session_id_foreign` FOREIGN KEY (`cart_session_id`) REFERENCES `cart_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_menu_item_variation_id_foreign` FOREIGN KEY (`menu_item_variation_id`) REFERENCES `menu_item_variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_sessions`
--

DROP TABLE IF EXISTS `cart_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `order_id` bigint unsigned DEFAULT NULL,
  `order_type_id` bigint unsigned DEFAULT NULL,
  `placed_via` enum('pos','shop','kiosk') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_total` decimal(16,2) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `total_tax_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `tax_mode` enum('order','item') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'order',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_sessions_branch_id_foreign` (`branch_id`),
  KEY `cart_sessions_order_id_foreign` (`order_id`),
  KEY `cart_sessions_order_type_id_foreign` (`order_type_id`),
  CONSTRAINT `cart_sessions_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_sessions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_sessions_order_type_id_foreign` FOREIGN KEY (`order_type_id`) REFERENCES `order_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_sessions`
--

LOCK TABLES `cart_sessions` WRITE;
/*!40000 ALTER TABLE `cart_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` bigint unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `contacts_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'support@example.com','Bond Hobbs Inc',NULL,'957 Jamie Station, Lamontborough, SD 27319-9459','2026-06-05 23:44:10','2026-06-05 23:44:10');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `countries_code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countries_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonecode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `countries_countries_code_index` (`countries_code`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','Afghanistan','93'),(2,'AX','Åland Islands','358'),(3,'AL','Albania','355'),(4,'DZ','Algeria','213'),(5,'AS','American Samoa','1684'),(6,'AD','Andorra','376'),(7,'AO','Angola','244'),(8,'AI','Anguilla','1264'),(9,'AQ','Antarctica','0'),(10,'AG','Antigua and Barbuda','1268'),(11,'AR','Argentina','54'),(12,'AM','Armenia','374'),(13,'AW','Aruba','297'),(14,'AU','Australia','61'),(15,'AT','Austria','43'),(16,'AZ','Azerbaijan','994'),(17,'BS','Bahamas','1242'),(18,'BH','Bahrain','973'),(19,'BD','Bangladesh','880'),(20,'BB','Barbados','1246'),(21,'BY','Belarus','375'),(22,'BE','Belgium','32'),(23,'BZ','Belize','501'),(24,'BJ','Benin','229'),(25,'BM','Bermuda','1441'),(26,'BT','Bhutan','975'),(27,'BO','Bolivia, Plurinational State of','591'),(28,'BQ','Bonaire, Sint Eustatius and Saba','599'),(29,'BA','Bosnia and Herzegovina','387'),(30,'BW','Botswana','267'),(31,'BV','Bouvet Island','0'),(32,'BR','Brazil','55'),(33,'IO','British Indian Ocean Territory','246'),(34,'BN','Brunei Darussalam','673'),(35,'BG','Bulgaria','359'),(36,'BF','Burkina Faso','226'),(37,'BI','Burundi','257'),(38,'KH','Cambodia','855'),(39,'CM','Cameroon','237'),(40,'CA','Canada','1'),(41,'CV','Cape Verde','238'),(42,'KY','Cayman Islands','1345'),(43,'CF','Central African Republic','236'),(44,'TD','Chad','235'),(45,'CL','Chile','56'),(46,'CN','China','86'),(47,'CX','Christmas Island','61'),(48,'CC','Cocos (Keeling) Islands','672'),(49,'CO','Colombia','57'),(50,'KM','Comoros','269'),(51,'CG','Congo','242'),(52,'CD','Congo, the Democratic Republic of the','242'),(53,'CK','Cook Islands','682'),(54,'CR','Costa Rica','506'),(55,'CI','Côte d\'Ivoire','225'),(56,'HR','Croatia','385'),(57,'CU','Cuba','53'),(58,'CW','Curaçao','599'),(59,'CY','Cyprus','357'),(60,'CZ','Czech Republic','420'),(61,'DK','Denmark','45'),(62,'DJ','Djibouti','253'),(63,'DM','Dominica','1767'),(64,'DO','Dominican Republic','1809'),(65,'EC','Ecuador','593'),(66,'EG','Egypt','20'),(67,'SV','El Salvador','503'),(68,'GQ','Equatorial Guinea','240'),(69,'ER','Eritrea','291'),(70,'EE','Estonia','372'),(71,'ET','Ethiopia','251'),(72,'FK','Falkland Islands (Malvinas)','500'),(73,'FO','Faroe Islands','298'),(74,'FJ','Fiji','679'),(75,'FI','Finland','358'),(76,'FR','France','33'),(77,'GF','French Guiana','594'),(78,'PF','French Polynesia','689'),(79,'TF','French Southern Territories','0'),(80,'GA','Gabon','241'),(81,'GM','Gambia','220'),(82,'GE','Georgia','995'),(83,'DE','Germany','49'),(84,'GH','Ghana','233'),(85,'GI','Gibraltar','350'),(86,'GR','Greece','30'),(87,'GL','Greenland','299'),(88,'GD','Grenada','1473'),(89,'GP','Guadeloupe','590'),(90,'GU','Guam','1671'),(91,'GT','Guatemala','502'),(92,'GG','Guernsey','44'),(93,'GN','Guinea','224'),(94,'GW','Guinea-Bissau','245'),(95,'GY','Guyana','592'),(96,'HT','Haiti','509'),(97,'HM','Heard Island and McDonald Islands','0'),(98,'VA','Holy See (Vatican City State)','39'),(99,'HN','Honduras','504'),(100,'HK','Hong Kong','852'),(101,'HU','Hungary','36'),(102,'IS','Iceland','354'),(103,'IN','India','91'),(104,'ID','Indonesia','62'),(105,'IR','Iran, Islamic Republic of','98'),(106,'IQ','Iraq','964'),(107,'IE','Ireland','353'),(108,'IM','Isle of Man','44'),(109,'IL','Israel','972'),(110,'IT','Italy','39'),(111,'JM','Jamaica','1876'),(112,'JP','Japan','81'),(113,'JE','Jersey','44'),(114,'JO','Jordan','962'),(115,'KZ','Kazakhstan','7'),(116,'KE','Kenya','254'),(117,'KI','Kiribati','686'),(118,'KP','Korea, Democratic People\'s Republic of','850'),(119,'KR','Korea, Republic of','82'),(120,'KW','Kuwait','965'),(121,'KG','Kyrgyzstan','996'),(122,'LA','Lao People\'s Democratic Republic','856'),(123,'LV','Latvia','371'),(124,'LB','Lebanon','961'),(125,'LS','Lesotho','266'),(126,'LR','Liberia','231'),(127,'LY','Libya','218'),(128,'LI','Liechtenstein','423'),(129,'LT','Lithuania','370'),(130,'LU','Luxembourg','352'),(131,'MO','Macao','853'),(132,'MK','Macedonia, the Former Yugoslav Republic of','389'),(133,'MG','Madagascar','261'),(134,'MW','Malawi','265'),(135,'MY','Malaysia','60'),(136,'MV','Maldives','960'),(137,'ML','Mali','223'),(138,'MT','Malta','356'),(139,'MH','Marshall Islands','692'),(140,'MQ','Martinique','596'),(141,'MR','Mauritania','222'),(142,'MU','Mauritius','230'),(143,'YT','Mayotte','269'),(144,'MX','Mexico','52'),(145,'FM','Micronesia, Federated States of','691'),(146,'MD','Moldova, Republic of','373'),(147,'MC','Monaco','377'),(148,'MN','Mongolia','976'),(149,'ME','Montenegro','382'),(150,'MS','Montserrat','1664'),(151,'MA','Morocco','212'),(152,'MZ','Mozambique','258'),(153,'MM','Myanmar','95'),(154,'NA','Namibia','264'),(155,'NR','Nauru','674'),(156,'NP','Nepal','977'),(157,'NL','Netherlands','31'),(158,'NC','New Caledonia','687'),(159,'NZ','New Zealand','64'),(160,'NI','Nicaragua','505'),(161,'NE','Niger','227'),(162,'NG','Nigeria','234'),(163,'NU','Niue','683'),(164,'NF','Norfolk Island','672'),(165,'MP','Northern Mariana Islands','1670'),(166,'NO','Norway','47'),(167,'OM','Oman','968'),(168,'PK','Pakistan','92'),(169,'PW','Palau','680'),(170,'PS','Palestine, State of','970'),(171,'PA','Panama','507'),(172,'PG','Papua New Guinea','675'),(173,'PY','Paraguay','595'),(174,'PE','Peru','51'),(175,'PH','Philippines','63'),(176,'PN','Pitcairn','0'),(177,'PL','Poland','48'),(178,'PT','Portugal','351'),(179,'PR','Puerto Rico','1787'),(180,'QA','Qatar','974'),(181,'RE','Réunion','262'),(182,'RO','Romania','40'),(183,'RU','Russian Federation','7'),(184,'RW','Rwanda','250'),(185,'BL','Saint Barthélemy','590'),(186,'SH','Saint Helena, Ascension and Tristan da Cunha','290'),(187,'KN','Saint Kitts and Nevis','1869'),(188,'LC','Saint Lucia','1758'),(189,'MF','Saint Martin (French part)','590'),(190,'PM','Saint Pierre and Miquelon','508'),(191,'VC','Saint Vincent and the Grenadines','1784'),(192,'WS','Samoa','684'),(193,'SM','San Marino','378'),(194,'ST','Sao Tome and Principe','239'),(195,'SA','Saudi Arabia','966'),(196,'SN','Senegal','221'),(197,'RS','Serbia','381'),(198,'SC','Seychelles','248'),(199,'SL','Sierra Leone','232'),(200,'SG','Singapore','65'),(201,'SX','Sint Maarten (Dutch part)','1'),(202,'SK','Slovakia','421'),(203,'SI','Slovenia','386'),(204,'SB','Solomon Islands','677'),(205,'SO','Somalia','252'),(206,'ZA','South Africa','27'),(207,'GS','South Georgia and the South Sandwich Islands','0'),(208,'SS','South Sudan','211'),(209,'ES','Spain','34'),(210,'LK','Sri Lanka','94'),(211,'SD','Sudan','249'),(212,'SR','Suriname','597'),(213,'SJ','Svalbard and Jan Mayen','47'),(214,'SZ','Swaziland','268'),(215,'SE','Sweden','46'),(216,'CH','Switzerland','41'),(217,'SY','Syrian Arab Republic','963'),(218,'TW','Taiwan, Province of China','886'),(219,'TJ','Tajikistan','992'),(220,'TZ','Tanzania, United Republic of','255'),(221,'TH','Thailand','66'),(222,'TL','Timor-Leste','670'),(223,'TG','Togo','228'),(224,'TK','Tokelau','690'),(225,'TO','Tonga','676'),(226,'TT','Trinidad and Tobago','1868'),(227,'TN','Tunisia','216'),(228,'TR','Turkey','90'),(229,'TM','Turkmenistan','7370'),(230,'TC','Turks and Caicos Islands','1649'),(231,'TV','Tuvalu','688'),(232,'UG','Uganda','256'),(233,'UA','Ukraine','380'),(234,'AE','United Arab Emirates','971'),(235,'GB','United Kingdom','44'),(236,'US','United States','1'),(237,'UM','United States Minor Outlying Islands','1'),(238,'UY','Uruguay','598'),(239,'UZ','Uzbekistan','998'),(240,'VU','Vanuatu','678'),(241,'VE','Venezuela, Bolivarian Republic of','58'),(242,'VN','Viet Nam','84'),(243,'VG','Virgin Islands, British','1284'),(244,'VI','Virgin Islands, U.S.','1340'),(245,'WF','Wallis and Futuna','681'),(246,'EH','Western Sahara','212'),(247,'YE','Yemen','967'),(248,'ZM','Zambia','260'),(249,'ZW','Zimbabwe','263');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `currency_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_position` enum('left','right','left_with_space','right_with_space') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'left',
  `no_of_decimal` int unsigned NOT NULL DEFAULT '2',
  `thousand_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT ',',
  `decimal_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '.',
  `exchange_rate` decimal(16,2) DEFAULT NULL,
  `usd_price` decimal(16,2) DEFAULT NULL,
  `is_cryptocurrency` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `currencies_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `currencies_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,1,'Dollars','USD','$','left',2,',','.',NULL,NULL,'no'),(2,1,'Rupee','INR','₹','left',2,',','.',NULL,NULL,'no'),(3,1,'Pounds','GBP','£','left',2,',','.',NULL,NULL,'no'),(4,1,'Euros','EUR','€','left',2,',','.',NULL,NULL,'no'),(5,1,'Taka','BDT','৳','left',0,',','.',NULL,NULL,'no');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_menus`
--

DROP TABLE IF EXISTS `custom_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_content` longtext COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `position` enum('header','footer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'header',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `custom_menus_menu_slug_unique` (`menu_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_menus`
--

LOCK TABLES `custom_menus` WRITE;
/*!40000 ALTER TABLE `custom_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned DEFAULT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `lat` decimal(10,7) DEFAULT NULL,
  `lng` decimal(10,7) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_addresses_customer_id_foreign` (`customer_id`),
  CONSTRAINT `customer_addresses_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
INSERT INTO `customer_addresses` VALUES (1,20,NULL,'mirpur',23.8007525,90.3565779,'2026-06-10 04:50:23','2026-06-10 04:50:23');
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_otp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delivery_address` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_restaurant_email_unique` (`restaurant_id`,`email`),
  UNIQUE KEY `customers_email_restaurant_unique` (`email`,`restaurant_id`),
  CONSTRAINT `customers_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,1,'Saiful Islam','1909430970','880','dev4retailsolution@gmail.com',NULL,'2026-06-09 03:10:01','2026-06-09 03:10:01','11th Floor, Razzak Plaza, 1 New Eskaton Road'),(2,1,'Rubel','17565623412','880','mahabub.retailsolution@gmail.com',NULL,'2026-06-09 04:58:21','2026-06-09 04:58:21','Katasure'),(3,1,'saiful','01943838532','880',NULL,NULL,'2026-06-10 02:48:25','2026-06-10 02:48:25',NULL),(4,1,'Faruk','196565165598','880',NULL,NULL,'2026-06-10 03:31:46','2026-06-10 03:31:46',NULL),(5,1,'Neon','4155747458545','880',NULL,NULL,'2026-06-10 03:37:53','2026-06-10 03:37:53',NULL),(6,1,'Rahul','63541652635','880',NULL,NULL,'2026-06-10 03:52:11','2026-06-10 03:52:11',NULL),(20,1,'SaiFul','01909430970','880','sm2saiful11@gmail.com',NULL,'2026-06-10 04:50:23','2026-06-10 04:50:23','mirpur'),(21,1,'Md Saiful','02164589500','880','sm2saiful@gmail.com',NULL,'2026-06-10 05:09:42','2026-06-10 05:09:42',NULL),(30,1,'saifulislam','65498165489458','880','saiful@gmail.com',NULL,'2026-06-10 05:27:49','2026-06-10 05:27:49',NULL),(31,1,'Risul','1707430790','880','risul@gmail.com',NULL,'2026-06-10 23:05:46','2026-06-10 23:05:46',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_cash_settlement_items`
--

DROP TABLE IF EXISTS `delivery_cash_settlement_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_cash_settlement_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `settlement_id` bigint unsigned NOT NULL,
  `order_cash_collection_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dcsi_settlement_collection_unique` (`settlement_id`,`order_cash_collection_id`),
  KEY `delivery_cash_settlement_items_order_cash_collection_id_foreign` (`order_cash_collection_id`),
  KEY `delivery_cash_settlement_items_order_id_foreign` (`order_id`),
  CONSTRAINT `delivery_cash_settlement_items_order_cash_collection_id_foreign` FOREIGN KEY (`order_cash_collection_id`) REFERENCES `order_cash_collections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_cash_settlement_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_cash_settlement_items_settlement_id_foreign` FOREIGN KEY (`settlement_id`) REFERENCES `delivery_cash_settlements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_cash_settlement_items`
--

LOCK TABLES `delivery_cash_settlement_items` WRITE;
/*!40000 ALTER TABLE `delivery_cash_settlement_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_cash_settlement_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_cash_settlements`
--

DROP TABLE IF EXISTS `delivery_cash_settlements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_cash_settlements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `delivery_executive_id` bigint unsigned NOT NULL,
  `settlement_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_amount` decimal(16,2) NOT NULL,
  `verified_amount` decimal(16,2) DEFAULT NULL,
  `status` enum('submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'submitted',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `delivery_cash_settlements_settlement_number_unique` (`settlement_number`),
  KEY `delivery_cash_settlements_branch_id_foreign` (`branch_id`),
  KEY `dcs_exec_status_idx` (`delivery_executive_id`,`status`),
  CONSTRAINT `delivery_cash_settlements_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_cash_settlements_delivery_executive_id_foreign` FOREIGN KEY (`delivery_executive_id`) REFERENCES `delivery_executives` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_cash_settlements`
--

LOCK TABLES `delivery_cash_settlements` WRITE;
/*!40000 ALTER TABLE `delivery_cash_settlements` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_cash_settlements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_executives`
--

DROP TABLE IF EXISTS `delivery_executives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_executives` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unique_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','on_delivery','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_online` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `delivery_executives_email_unique` (`email`),
  KEY `delivery_executives_branch_id_foreign` (`branch_id`),
  CONSTRAINT `delivery_executives_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_executives`
--

LOCK TABLES `delivery_executives` WRITE;
/*!40000 ALTER TABLE `delivery_executives` DISABLE KEYS */;
INSERT INTO `delivery_executives` VALUES (2,1,'Delivery Man 01','sm2saiful@gmail.com','1909430970','9NTT2','880',NULL,'active',1,'2026-06-09 05:15:19','2026-06-09 05:27:51');
/*!40000 ALTER TABLE `delivery_executives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_fee_tiers`
--

DROP TABLE IF EXISTS `delivery_fee_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_fee_tiers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `min_distance` double DEFAULT NULL,
  `max_distance` double DEFAULT NULL,
  `fee` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delivery_fee_tiers_branch_id_foreign` (`branch_id`),
  CONSTRAINT `delivery_fee_tiers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_fee_tiers`
--

LOCK TABLES `delivery_fee_tiers` WRITE;
/*!40000 ALTER TABLE `delivery_fee_tiers` DISABLE KEYS */;
INSERT INTO `delivery_fee_tiers` VALUES (2,3,0,10,60.00,'2026-06-10 02:28:38','2026-06-10 02:29:01'),(3,3,10.1,20,120.00,'2026-06-10 02:28:38','2026-06-10 02:29:01');
/*!40000 ALTER TABLE `delivery_fee_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_platforms`
--

DROP TABLE IF EXISTS `delivery_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_platforms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_type` enum('percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `commission_value` decimal(16,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delivery_platforms_branch_id_foreign` (`branch_id`),
  CONSTRAINT `delivery_platforms_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_platforms`
--

LOCK TABLES `delivery_platforms` WRITE;
/*!40000 ALTER TABLE `delivery_platforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `desktop_mobile_application`
--

DROP TABLE IF EXISTS `desktop_mobile_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_mobile_application` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `windows_file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac_file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linux_file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner_app_ios` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner_app_android` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waiter_pos_app_ios` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waiter_pos_app_android` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desktop_mobile_application`
--

LOCK TABLES `desktop_mobile_application` WRITE;
/*!40000 ALTER TABLE `desktop_mobile_application` DISABLE KEYS */;
INSERT INTO `desktop_mobile_application` VALUES (1,'https://envato.froid.works/app/download/windows','https://envato.froid.works/app/download/macos','https://envato.froid.works/app/download/linux','https://apps.apple.com/in/app/tabletrack-rider/id6759326050','https://play.google.com/store/apps/details?id=com.delivery.tabletrack&hl=en_IN',NULL,NULL,NULL,'2026-06-05 23:43:56');
/*!40000 ALTER TABLE `desktop_mobile_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_settings`
--

DROP TABLE IF EXISTS `email_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `mail_from_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_from_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_queue` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `mail_driver` enum('mail','smtp') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mail',
  `smtp_host` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_encryption` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_settings`
--

LOCK TABLES `email_settings` WRITE;
/*!40000 ALTER TABLE `email_settings` DISABLE KEYS */;
INSERT INTO `email_settings` VALUES (1,'TableTrack','from@email.com','no','smtp','smtp.gmail.com','465','ssl','myemail@gmail.com',NULL,'2026-06-05 23:44:10','2026-06-05 23:44:10',0,0);
/*!40000 ALTER TABLE `email_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `epay_payments`
--

DROP TABLE IF EXISTS `epay_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `epay_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `epay_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `epay_invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epay_secret_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epay_access_token` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `epay_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `epay_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epay_payments`
--

LOCK TABLES `epay_payments` WRITE;
/*!40000 ALTER TABLE `epay_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `epay_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_categories_branch_id_foreign` (`branch_id`),
  CONSTRAINT `expense_categories_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_categories`
--

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
INSERT INTO `expense_categories` VALUES (1,1,'Rent','Monthly rent for restaurant space',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,'Utilities','Electricity, water, gas, and other utilities',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,'Salaries','Employee salaries and wages',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,1,'Ingredients','Food ingredients and raw materials',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(5,1,'Equipment','Kitchen equipment and appliances',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(6,1,'Marketing','Advertising and promotional expenses',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(7,1,'Insurance','Business insurance and liability coverage',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(8,1,'Maintenance','Repairs and maintenance costs',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(9,1,'Licenses','Business licenses and permits',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(10,1,'Miscellaneous','Other miscellaneous expenses',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(11,2,'Rent','Monthly rent for restaurant space',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(12,2,'Utilities','Electricity, water, gas, and other utilities',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(13,2,'Salaries','Employee salaries and wages',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(14,2,'Ingredients','Food ingredients and raw materials',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(15,2,'Equipment','Kitchen equipment and appliances',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(16,2,'Marketing','Advertising and promotional expenses',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(17,2,'Insurance','Business insurance and liability coverage',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(18,2,'Maintenance','Repairs and maintenance costs',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(19,2,'Licenses','Business licenses and permits',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(20,2,'Miscellaneous','Other miscellaneous expenses',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(21,3,'Rent','Monthly rent for restaurant space',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(22,3,'Utilities','Electricity, water, gas, and other utilities',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(23,3,'Salaries','Employee salaries and wages',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(24,3,'Ingredients','Food ingredients and raw materials',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(25,3,'Equipment','Kitchen equipment and appliances',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(26,3,'Marketing','Advertising and promotional expenses',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(27,3,'Insurance','Business insurance and liability coverage',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(28,3,'Maintenance','Repairs and maintenance costs',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(29,3,'Licenses','Business licenses and permits',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(30,3,'Miscellaneous','Other miscellaneous expenses',1,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `expense_category_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned NOT NULL,
  `expenses_recurring_id` bigint unsigned DEFAULT NULL,
  `expense_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `amount` decimal(10,2) NOT NULL,
  `expense_date` date NOT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_due_date` date DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_expense_category_id_foreign` (`expense_category_id`),
  KEY `expenses_branch_id_foreign` (`branch_id`),
  KEY `expenses_expenses_recurring_id_foreign` (`expenses_recurring_id`),
  CONSTRAINT `expenses_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `expenses_expenses_recurring_id_foreign` FOREIGN KEY (`expenses_recurring_id`) REFERENCES `expenses_recurring` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_recurring`
--

DROP TABLE IF EXISTS `expenses_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_recurring` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `expense_category_id` bigint unsigned DEFAULT NULL,
  `item_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rotation` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `day_of_month` tinyint unsigned DEFAULT '1',
  `day_of_week` tinyint unsigned DEFAULT '1',
  `billing_cycle` int unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `next_expense_date` date DEFAULT NULL,
  `unlimited_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `immediate_expense` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `description` text COLLATE utf8mb4_unicode_ci,
  `bill` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_recurring_branch_id_foreign` (`branch_id`),
  KEY `expenses_recurring_expense_category_id_foreign` (`expense_category_id`),
  CONSTRAINT `expenses_recurring_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_recurring`
--

LOCK TABLES `expenses_recurring` WRITE;
/*!40000 ALTER TABLE `expenses_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage`
--

DROP TABLE IF EXISTS `file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_storage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int unsigned NOT NULL,
  `storage_location` enum('local','aws_s3','digitalocean','wasabi','minio') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `file_storage_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `file_storage_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage`
--

LOCK TABLES `file_storage` WRITE;
/*!40000 ALTER TABLE `file_storage` DISABLE KEYS */;
INSERT INTO `file_storage` VALUES (1,1,'qrcodes','qrcode-branch-1-1.png','image/png',2747,'local','2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,'qrcodes','qrcode-branch-1-1.png','image/png',2784,'local','2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,'qrcodes','qrcode-branch-2-1.png','image/png',2757,'local','2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,1,'qrcodes','qrcode-branch-2-1.png','image/png',2757,'local','2026-06-05 23:44:09','2026-06-05 23:44:09'),(5,1,'area','0503e59c987423e201435bbc12fbde4f.jpg','image/jpeg',417457,'local','2026-06-06 02:04:56','2026-06-06 02:04:56'),(6,1,'qrcodes','qrcode-1-t01.png','image/png',4969,'local','2026-06-06 02:05:28','2026-06-06 02:05:28'),(7,1,'item','5864ec792412c83f089223e689f23a24.jpg','image/jpeg',147943,'local','2026-06-06 02:09:57','2026-06-06 02:09:57'),(8,1,'item','5301c0c9b2fa5c31d0c6946f4fbf818b.jpg','image/jpeg',4629,'local','2026-06-07 02:50:55','2026-06-07 02:50:55'),(10,1,'item','c39902a651f729fefc9a5f3040ceae24.jpg','image/jpeg',235887,'local','2026-06-08 23:37:03','2026-06-08 23:37:03'),(11,1,'item','c25d7ba3a0b4fa897ca309974b04fa7d.jpeg','image/jpeg',46399,'local','2026-06-08 23:37:27','2026-06-08 23:37:27'),(12,1,'item','207ab28e7615905345eb68891e4259a9.jpg','image/jpeg',120485,'local','2026-06-08 23:38:29','2026-06-08 23:38:29'),(13,1,'item','e09153f13e89db277340ae23e0408290.jpg','image/jpeg',235887,'local','2026-06-08 23:38:44','2026-06-08 23:38:44'),(14,1,'item','e10a41d518e340bec6b723e21f9130d3.jpg','image/jpeg',284664,'local','2026-06-08 23:39:05','2026-06-08 23:39:05'),(15,1,'item','ba9f22a13e9bcf384f8e01ee7d1d4c53.jpg','image/jpeg',26471,'local','2026-06-08 23:39:26','2026-06-08 23:39:26'),(16,1,'item','0a9265422c1664c67674f2f20855e4b1.jpg','image/jpeg',28536,'local','2026-06-08 23:39:43','2026-06-08 23:39:43'),(17,1,'item','f5f3d0bc8237af366c7dae19388314d5.webp','image/webp',24644,'local','2026-06-08 23:40:08','2026-06-08 23:40:08'),(18,1,'item','7a8f163a2b8fb34a283b3f1504aa36b9.webp','image/webp',3676,'local','2026-06-08 23:40:25','2026-06-08 23:40:25'),(19,1,'item','f1e214b09cf13f4061879df8825cf31e.webp','image/webp',37208,'local','2026-06-08 23:40:56','2026-06-08 23:40:56'),(21,1,'item','903a048de5d1003ac8135dd44b8f83ff.jpg','image/jpeg',63104,'local','2026-06-08 23:42:49','2026-06-08 23:42:49'),(22,1,'item','40e8db6b5c357f29da3a9679d801987a.jpg','image/jpeg',50090,'local','2026-06-08 23:43:14','2026-06-08 23:43:14'),(23,1,'item','661968cf77f3ce9d2461164a343f3e29.jpg','image/jpeg',120485,'local','2026-06-08 23:43:58','2026-06-08 23:43:58'),(24,1,'item','ca90f9d59ffafdb3cb9e2c494485ff85.jpg','image/jpeg',74219,'local','2026-06-08 23:54:21','2026-06-08 23:54:21'),(25,1,'item','284fe889e28a718957d302eb3c8b8626.jpg','image/jpeg',93134,'local','2026-06-08 23:54:38','2026-06-08 23:54:38'),(26,1,'item','cb3b48d1acb9102f6e2e5abf7b8b3aae.jpg','image/jpeg',138776,'local','2026-06-08 23:55:19','2026-06-08 23:55:19'),(27,1,'item','78597f93e89c199279610089278415c3.jpg','image/jpeg',49961,'local','2026-06-08 23:55:36','2026-06-08 23:55:36'),(28,1,'item','3681eb969a58eddeb084561f2f65fdc2.jpg','image/jpeg',49961,'local','2026-06-08 23:55:55','2026-06-08 23:55:55'),(29,1,'logo','fcff797d7f67ab0071ef70ad5aa8dafd.jpeg','image/jpeg',58052,'local','2026-06-09 05:39:39','2026-06-09 05:39:39'),(30,1,'qrcodes','qrcode-branch-3-1.png','image/png',2904,'local','2026-06-10 00:34:49','2026-06-10 00:34:49'),(31,1,'area','a67f7e9a11b1dec84e5b3b6c538bfa27.jpg','image/jpeg',1509262,'local','2026-06-10 00:48:48','2026-06-10 00:48:48'),(32,1,'qrcodes','qrcode-3-ga-01.png','image/png',5347,'local','2026-06-10 01:13:41','2026-06-10 01:13:41'),(33,1,'area','736c412e485e6c833653cba6f7f5fa1c.jpg','image/jpeg',1769146,'local','2026-06-10 01:17:01','2026-06-10 01:17:01'),(34,1,'area','6effdcf374abd35017aa502cdd979d87.jpg','image/jpeg',477253,'local','2026-06-10 01:17:49','2026-06-10 01:17:49'),(35,1,'qrcodes','qrcode-3-ga-02.png','image/png',5579,'local','2026-06-10 01:18:11','2026-06-10 01:18:11'),(36,1,'qrcodes','qrcode-3-ga-03.png','image/png',5650,'local','2026-06-10 01:18:28','2026-06-10 01:18:28'),(37,1,'qrcodes','qrcode-3-fl-01.png','image/png',4979,'local','2026-06-10 01:26:30','2026-06-10 01:26:30'),(38,1,'qrcodes','qrcode-3-fl-02.png','image/png',5251,'local','2026-06-10 01:26:43','2026-06-10 01:26:43'),(39,1,'qrcodes','qrcode-3-fl-03.png','image/png',5330,'local','2026-06-10 01:27:03','2026-06-10 01:27:03'),(40,1,'qrcodes','qrcode-3-rf-01.png','image/png',5122,'local','2026-06-10 01:27:20','2026-06-10 01:27:20'),(41,1,'qrcodes','qrcode-3-rf-02.png','image/png',5319,'local','2026-06-10 01:27:53','2026-06-10 01:27:53'),(42,1,'qrcodes','qrcode-3-rf-03.png','image/png',5423,'local','2026-06-10 01:28:12','2026-06-10 01:28:12'),(43,1,'qrcodes','qrcode-3-rf-04.png','image/png',5215,'local','2026-06-10 01:28:27','2026-06-10 01:28:27'),(44,1,'qrcodes','qrcode-1-t02.png','image/png',5192,'local','2026-06-10 04:16:38','2026-06-10 04:16:38'),(45,1,'qrcodes','qrcode-3-fl-01.png','image/png',5011,'local','2026-06-10 04:47:54','2026-06-10 04:47:54');
/*!40000 ALTER TABLE `file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage_settings`
--

DROP TABLE IF EXISTS `file_storage_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_storage_settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `filesystem` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_keys` text COLLATE utf8mb4_unicode_ci,
  `status` enum('enabled','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disabled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage_settings`
--

LOCK TABLES `file_storage_settings` WRITE;
/*!40000 ALTER TABLE `file_storage_settings` DISABLE KEYS */;
INSERT INTO `file_storage_settings` VALUES (1,'local',NULL,'enabled','2026-06-05 23:42:10','2026-06-05 23:42:10');
/*!40000 ALTER TABLE `file_storage_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `capital` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `continent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
INSERT INTO `flags` VALUES (1,'Kabul','af','Asia','Afghanistan'),(2,'Mariehamn','ax','Europe','Aland Islands'),(3,'Tirana','al','Europe','Albania'),(4,'Algiers','dz','Africa','Algeria'),(5,'Pago Pago','as','Oceania','American Samoa'),(6,'Andorra la Vella','ad','Europe','Andorra'),(7,'Luanda','ao','Africa','Angola'),(8,'The Valley','ai','North America','Anguilla'),(9,'','aq','','Antarctica'),(10,'St. John\'s','ag','North America','Antigua and Barbuda'),(11,'Buenos Aires','ar','South America','Argentina'),(12,'Yerevan','am','Asia','Armenia'),(13,'Oranjestad','aw','South America','Aruba'),(14,'Georgetown','ac','Africa','Ascension Island'),(15,'Canberra','au','Oceania','Australia'),(16,'Vienna','at','Europe','Austria'),(17,'Baku','az','Asia','Azerbaijan'),(18,'Nassau','bs','North America','Bahamas'),(19,'Manama','bh','Asia','Bahrain'),(20,'Dhaka','bd','Asia','Bangladesh'),(21,'Bridgetown','bb','North America','Barbados'),(22,'Minsk','by','Europe','Belarus'),(23,'Brussels','be','Europe','Belgium'),(24,'Belmopan','bz','North America','Belize'),(25,'Porto-Novo','bj','Africa','Benin'),(26,'Hamilton','bm','North America','Bermuda'),(27,'Thimphu','bt','Asia','Bhutan'),(28,'Sucre','bo','South America','Bolivia'),(29,'Kralendijk','bq','South America','Bonaire, Sint Eustatius and Saba'),(30,'Sarajevo','ba','Europe','Bosnia and Herzegovina'),(31,'Gaborone','bw','Africa','Botswana'),(32,'','bv','','Bouvet Island'),(33,'Brasília','br','South America','Brazil'),(34,'Diego Garcia','io','Asia','British Indian Ocean Territory'),(35,'Bandar Seri Begawan','bn','Asia','Brunei Darussalam'),(36,'Sofia','bg','Europe','Bulgaria'),(37,'Ouagadougou','bf','Africa','Burkina Faso'),(38,'Bujumbura','bi','Africa','Burundi'),(39,'Praia','cv','Africa','Cabo Verde'),(40,'Phnom Penh','kh','Asia','Cambodia'),(41,'Yaoundé','cm','Africa','Cameroon'),(42,'Ottawa','ca','North America','Canada'),(43,'','ic','','Canary Islands'),(44,'','es-ct','','Catalonia'),(45,'George Town','ky','North America','Cayman Islands'),(46,'Bangui','cf','Africa','Central African Republic'),(47,'','cefta','','Central European Free Trade Agreement'),(48,'','ea','','Ceuta & Melilla'),(49,'N\'Djamena','td','Africa','Chad'),(50,'Santiago','cl','South America','Chile'),(51,'Beijing','cn','Asia','China'),(52,'Flying Fish Cove','cx','Asia','Christmas Island'),(53,'','cp','','Clipperton Island'),(54,'West Island','cc','Asia','Cocos (Keeling) Islands'),(55,'Bogotá','co','South America','Colombia'),(56,'Moroni','km','Africa','Comoros'),(57,'Avarua','ck','Oceania','Cook Islands'),(58,'San José','cr','North America','Costa Rica'),(59,'Zagreb','hr','Europe','Croatia'),(60,'Havana','cu','North America','Cuba'),(61,'Willemstad','cw','South America','Curaçao'),(62,'Nicosia','cy','Europe','Cyprus'),(63,'Prague','cz','Europe','Czech Republic'),(64,'Yamoussoukro','ci','Africa','Côte d\'Ivoire'),(65,'Kinshasa','cd','Africa','Democratic Republic of the Congo'),(66,'Copenhagen','dk','Europe','Denmark'),(67,'','dg','','Diego Garcia'),(68,'Djibouti','dj','Africa','Djibouti'),(69,'Roseau','dm','North America','Dominica'),(70,'Santo Domingo','do','North America','Dominican Republic'),(71,'Quito','ec','South America','Ecuador'),(72,'Cairo','eg','Africa','Egypt'),(73,'San Salvador','sv','North America','El Salvador'),(74,'London','gb-eng','Europe','England'),(75,'Malabo','gq','Africa','Equatorial Guinea'),(76,'Asmara','er','Africa','Eritrea'),(77,'Tallinn','ee','Europe','Estonia'),(78,'Lobamba, Mbabane','sz','Africa','Eswatini'),(79,'Addis Ababa','et','Africa','Ethiopia'),(80,'','eu','','Europe'),(81,'Stanley','fk','South America','Falkland Islands'),(82,'Tórshavn','fo','Europe','Faroe Islands'),(83,'Palikir','fm','Oceania','Federated States of Micronesia'),(84,'Suva','fj','Oceania','Fiji'),(85,'Helsinki','fi','Europe','Finland'),(86,'Paris','fr','Europe','France'),(87,'Cayenne','gf','South America','French Guiana'),(88,'Papeete','pf','Oceania','French Polynesia'),(89,'Saint-Pierre, Réunion','tf','Africa','French Southern Territories'),(90,'Libreville','ga','Africa','Gabon'),(91,'','es-ga','','Galicia'),(92,'Banjul','gm','Africa','Gambia'),(93,'Tbilisi','ge','Asia','Georgia'),(94,'Berlin','de','Europe','Germany'),(95,'Accra','gh','Africa','Ghana'),(96,'Gibraltar','gi','Europe','Gibraltar'),(97,'Athens','gr','Europe','Greece'),(98,'Nuuk','gl','North America','Greenland'),(99,'St. George\'s','gd','North America','Grenada'),(100,'Basse-Terre','gp','North America','Guadeloupe'),(101,'Hagåtña','gu','Oceania','Guam'),(102,'Guatemala City','gt','North America','Guatemala'),(103,'Saint Peter Port','gg','Europe','Guernsey'),(104,'Conakry','gn','Africa','Guinea'),(105,'Bissau','gw','Africa','Guinea-Bissau'),(106,'Georgetown','gy','South America','Guyana'),(107,'Port-au-Prince','ht','North America','Haiti'),(108,'','hm','','Heard Island and McDonald Islands'),(109,'Vatican City','va','Europe','Holy See'),(110,'Tegucigalpa','hn','North America','Honduras'),(111,'Hong Kong','hk','Asia','Hong Kong'),(112,'Budapest','hu','Europe','Hungary'),(113,'Reykjavik','is','Europe','Iceland'),(114,'New Delhi','in','Asia','India'),(115,'Jakarta','id','Asia','Indonesia'),(116,'Tehran','ir','Asia','Iran'),(117,'Baghdad','iq','Asia','Iraq'),(118,'Dublin','ie','Europe','Ireland'),(119,'Douglas','im','Europe','Isle of Man'),(120,'Jerusalem','il','Asia','Israel'),(121,'Rome','it','Europe','Italy'),(122,'Kingston','jm','North America','Jamaica'),(123,'Tokyo','jp','Asia','Japan'),(124,'Saint Helier','je','Europe','Jersey'),(125,'Amman','jo','Asia','Jordan'),(126,'Astana','kz','Asia','Kazakhstan'),(127,'Nairobi','ke','Africa','Kenya'),(128,'South Tarawa','ki','Oceania','Kiribati'),(129,'Pristina','xk','Europe','Kosovo'),(130,'Kuwait City','kw','Asia','Kuwait'),(131,'Bishkek','kg','Asia','Kyrgyzstan'),(132,'Vientiane','la','Asia','Laos'),(133,'Riga','lv','Europe','Latvia'),(134,'Beirut','lb','Asia','Lebanon'),(135,'Maseru','ls','Africa','Lesotho'),(136,'Monrovia','lr','Africa','Liberia'),(137,'Tripoli','ly','Africa','Libya'),(138,'Vaduz','li','Europe','Liechtenstein'),(139,'Vilnius','lt','Europe','Lithuania'),(140,'Luxembourg City','lu','Europe','Luxembourg'),(141,'Macau','mo','Asia','Macau'),(142,'Antananarivo','mg','Africa','Madagascar'),(143,'Lilongwe','mw','Africa','Malawi'),(144,'Kuala Lumpur','my','Asia','Malaysia'),(145,'Malé','mv','Asia','Maldives'),(146,'Bamako','ml','Africa','Mali'),(147,'Valletta','mt','Europe','Malta'),(148,'Majuro','mh','Oceania','Marshall Islands'),(149,'Fort-de-France','mq','North America','Martinique'),(150,'Nouakchott','mr','Africa','Mauritania'),(151,'Port Louis','mu','Africa','Mauritius'),(152,'Mamoudzou','yt','Africa','Mayotte'),(153,'Mexico City','mx','North America','Mexico'),(154,'Chișinău','md','Europe','Moldova'),(155,'Monaco','mc','Europe','Monaco'),(156,'Ulaanbaatar','mn','Asia','Mongolia'),(157,'Podgorica','me','Europe','Montenegro'),(158,'Little Bay, Brades, Plymouth','ms','North America','Montserrat'),(159,'Rabat','ma','Africa','Morocco'),(160,'Maputo','mz','Africa','Mozambique'),(161,'Naypyidaw','mm','Asia','Myanmar'),(162,'Windhoek','na','Africa','Namibia'),(163,'Yaren District','nr','Oceania','Nauru'),(164,'Kathmandu','np','Asia','Nepal'),(165,'Amsterdam','nl','Europe','Netherlands'),(166,'Nouméa','nc','Oceania','New Caledonia'),(167,'Wellington','nz','Oceania','New Zealand'),(168,'Managua','ni','North America','Nicaragua'),(169,'Niamey','ne','Africa','Niger'),(170,'Abuja','ng','Africa','Nigeria'),(171,'Alofi','nu','Oceania','Niue'),(172,'Kingston','nf','Oceania','Norfolk Island'),(173,'Pyongyang','kp','Asia','North Korea'),(174,'Skopje','mk','Europe','North Macedonia'),(175,'Belfast','gb-nir','Europe','Northern Ireland'),(176,'Saipan','mp','Oceania','Northern Mariana Islands'),(177,'Oslo','no','Europe','Norway'),(178,'Muscat','om','Asia','Oman'),(179,'Islamabad','pk','Asia','Pakistan'),(180,'Ngerulmud','pw','Oceania','Palau'),(181,'Panama City','pa','North America','Panama'),(182,'Port Moresby','pg','Oceania','Papua New Guinea'),(183,'Asunción','py','South America','Paraguay'),(184,'Lima','pe','South America','Peru'),(185,'Manila','ph','Asia','Philippines'),(186,'Adamstown','pn','Oceania','Pitcairn'),(187,'Warsaw','pl','Europe','Poland'),(188,'Lisbon','pt','Europe','Portugal'),(189,'San Juan','pr','North America','Puerto Rico'),(190,'Doha','qa','Asia','Qatar'),(191,'Brazzaville','cg','Africa','Republic of the Congo'),(192,'Bucharest','ro','Europe','Romania'),(193,'Moscow','ru','Europe','Russia'),(194,'Kigali','rw','Africa','Rwanda'),(195,'Saint-Denis','re','Africa','Réunion'),(196,'Gustavia','bl','North America','Saint Barthélemy'),(197,'Jamestown','sh','Africa','Saint Helena, Ascension and Tristan da Cunha'),(198,'Basseterre','kn','North America','Saint Kitts and Nevis'),(199,'Castries','lc','North America','Saint Lucia'),(200,'Marigot','mf','North America','Saint Martin'),(201,'Saint-Pierre','pm','North America','Saint Pierre and Miquelon'),(202,'Kingstown','vc','North America','Saint Vincent and the Grenadines'),(203,'Apia','ws','Oceania','Samoa'),(204,'San Marino','sm','Europe','San Marino'),(205,'São Tomé','st','Africa','Sao Tome and Principe'),(206,'Riyadh','sa','Asia','Saudi Arabia'),(207,'Edinburgh','gb-sct','Europe','Scotland'),(208,'Dakar','sn','Africa','Senegal'),(209,'Belgrade','rs','Europe','Serbia'),(210,'Victoria','sc','Africa','Seychelles'),(211,'Freetown','sl','Africa','Sierra Leone'),(212,'Singapore','sg','Asia','Singapore'),(213,'Philipsburg','sx','North America','Sint Maarten'),(214,'Bratislava','sk','Europe','Slovakia'),(215,'Ljubljana','si','Europe','Slovenia'),(216,'Honiara','sb','Oceania','Solomon Islands'),(217,'Mogadishu','so','Africa','Somalia'),(218,'Pretoria','za','Africa','South Africa'),(219,'King Edward Point','gs','Antarctica','South Georgia and the South Sandwich Islands'),(220,'Seoul','kr','Asia','South Korea'),(221,'Juba','ss','Africa','South Sudan'),(222,'Madrid','es','Europe','Spain'),(223,'Sri Jayawardenepura Kotte, Colombo','lk','Asia','Sri Lanka'),(224,'Ramallah','ps','Asia','State of Palestine'),(225,'Khartoum','sd','Africa','Sudan'),(226,'Paramaribo','sr','South America','Suriname'),(227,'Longyearbyen','sj','Europe','Svalbard and Jan Mayen'),(228,'Stockholm','se','Europe','Sweden'),(229,'Bern','ch','Europe','Switzerland'),(230,'Damascus','sy','Asia','Syria'),(231,'Taipei','tw','Asia','Taiwan'),(232,'Dushanbe','tj','Asia','Tajikistan'),(233,'Dodoma','tz','Africa','Tanzania'),(234,'Bangkok','th','Asia','Thailand'),(235,'Dili','tl','Asia','Timor-Leste'),(236,'Lomé','tg','Africa','Togo'),(237,'Nukunonu, Atafu,Tokelau','tk','Oceania','Tokelau'),(238,'Nukuʻalofa','to','Oceania','Tonga'),(239,'Port of Spain','tt','South America','Trinidad and Tobago'),(240,'','ta','','Tristan da Cunha'),(241,'Tunis','tn','Africa','Tunisia'),(242,'Ankara','tr','Asia','Turkey'),(243,'Ashgabat','tm','Asia','Turkmenistan'),(244,'Cockburn Town','tc','North America','Turks and Caicos Islands'),(245,'Funafuti','tv','Oceania','Tuvalu'),(246,'Kampala','ug','Africa','Uganda'),(247,'Kiev','ua','Europe','Ukraine'),(248,'Abu Dhabi','ae','Asia','United Arab Emirates'),(249,'London','gb','Europe','United Kingdom'),(250,'','un','','United Nations'),(251,'Washington, D.C.','um','North America','United States Minor Outlying Islands'),(252,'Washington, D.C.','us','North America','United States of America'),(253,'','xx','','Unknown'),(254,'Montevideo','uy','South America','Uruguay'),(255,'Tashkent','uz','Asia','Uzbekistan'),(256,'Port Vila','vu','Oceania','Vanuatu'),(257,'Caracas','ve','South America','Venezuela'),(258,'Hanoi','vn','Asia','Vietnam'),(259,'Road Town','vg','North America','Virgin Islands (British)'),(260,'Charlotte Amalie','vi','North America','Virgin Islands (U.S.)'),(261,'Cardiff','gb-wls','Europe','Wales'),(262,'Mata-Utu','wf','Oceania','Wallis and Futuna'),(263,'Laayoune','eh','Africa','Western Sahara'),(264,'Sana\'a','ye','Asia','Yemen'),(265,'Lusaka','zm','Africa','Zambia'),(266,'Harare','zw','Africa','Zimbabwe');
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flutterwave_payments`
--

DROP TABLE IF EXISTS `flutterwave_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flutterwave_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flutterwave_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flutterwave_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `flutterwave_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flutterwave_payments`
--

LOCK TABLES `flutterwave_payments` WRITE;
/*!40000 ALTER TABLE `flutterwave_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `flutterwave_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_details`
--

DROP TABLE IF EXISTS `front_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `front_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` bigint unsigned DEFAULT NULL,
  `header_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `header_description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_with_image_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_with_icon_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faq_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faq_description` text COLLATE utf8mb4_unicode_ci,
  `contact_heading` text COLLATE utf8mb4_unicode_ci,
  `footer_copyright_text` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_details_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_details_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_details`
--

LOCK TABLES `front_details` WRITE;
/*!40000 ALTER TABLE `front_details` DISABLE KEYS */;
INSERT INTO `front_details` VALUES (1,1,'Restaurant POS software made simple!','Easily manage orders, menus, and tables in one place. Save time, reduce errors, and grow your business faster',NULL,'Take Control of Your Restaurant','What Restaurant Owners Are Saying','Powerful Features Built to Elevate Your Restaurant Operations',NULL,'Simple, Transparent Pricing','Get everything you need to manage your restaurant with one affordable plan.','Your questions, answered','Answers to the most frequently asked questions.','Contact','© 2025 TableTrack. All Rights Reserved.','2026-06-05 23:44:10','2026-06-05 23:44:10');
/*!40000 ALTER TABLE `front_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_faq_settings`
--

DROP TABLE IF EXISTS `front_faq_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `front_faq_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` bigint unsigned DEFAULT NULL,
  `question` text COLLATE utf8mb4_unicode_ci,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_faq_settings_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_faq_settings_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_faq_settings`
--

LOCK TABLES `front_faq_settings` WRITE;
/*!40000 ALTER TABLE `front_faq_settings` DISABLE KEYS */;
INSERT INTO `front_faq_settings` VALUES (1,1,'How can I contact customer support 1?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL),(2,1,'How can I contact customer support?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL),(3,1,'How can I contact customer support?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL),(4,1,'How can I contact customer support?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL),(5,1,'How can I contact customer support?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL),(6,1,'How can I contact customer support?','Our dedicated support team is available via email to assist you with any questions or technical issues.',NULL,NULL);
/*!40000 ALTER TABLE `front_faq_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_features`
--

DROP TABLE IF EXISTS `front_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `front_features` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` bigint unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `image` longtext COLLATE utf8mb4_unicode_ci,
  `icon` longtext COLLATE utf8mb4_unicode_ci,
  `type` enum('image','icon','task','bills','team','apps') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_features_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_features_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_features`
--

LOCK TABLES `front_features` WRITE;
/*!40000 ALTER TABLE `front_features` DISABLE KEYS */;
INSERT INTO `front_features` VALUES (1,1,'Streamline Order Management','Never lose track of an order again. All your customer orders—from dine-in to takeout—are organized and easily accessible in one place.\n                                Speed up service and keep your kitchen running smoothly.',NULL,NULL,'image',NULL,NULL),(2,1,'Optimize Table Reservations','Maximize seating efficiency with real-time table tracking and reservations. Reduce wait times and ensure no table sits empty during peak hours, improving customer experience and turnover.',NULL,NULL,'image',NULL,NULL),(3,1,'Effortless Menu Management','Easily add, edit, or remove items from your menu on the go. Highlight specials, update prices, and keep everything in sync across all platforms, so your staff and customers always see the latest offerings.',NULL,NULL,'image',NULL,NULL),(4,1,'QR Code Menu','Contactless Ordering Made Easy','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                            class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                            <path\n                                d=\"M0 .5A.5.5 0 0 1 .5 0h3a.5.5 0 0 1 0 1H1v2.5a.5.5 0 0 1-1 0zm12 0a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-1 0V1h-2.5a.5.5 0 0 1-.5-.5M.5 12a.5.5 0 0 1 .5.5V15h2.5a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5v-3a.5.5 0 0 1 .5-.5m15 0a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1 0-1H15v-2.5a.5.5 0 0 1 .5-.5M4 4h1v1H4z\" />\n                            <path d=\"M7 2H2v5h5zM3 3h3v3H3zm2 8H4v1h1z\" />\n                            <path d=\"M7 9H2v5h5zm-4 1h3v3H3zm8-6h1v1h-1z\" />\n                            <path\n                                d=\"M9 2h5v5H9zm1 1v3h3V3zM8 8v2h1v1H8v1h2v-2h1v2h1v-1h2v-1h-3V8zm2 2H9V9h1zm4 2h-1v1h-2v1h3zm-4 2v-1H8v1z\" />\n                            <path d=\"M12 9h2V8h-2z\" />\n                        </svg>','bi-qr-code','icon',NULL,NULL),(5,1,'Payment Gateway Integration','Fast, Secure, and Flexible Payments using Stripe and Razorpay','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                        class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                        <path\n                            d=\"M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm6.226 5.385c-.584 0-.937.164-.937.593 0 .468.607.674 1.36.93 1.228.415 2.844.963 2.851 2.993C11.5 11.868 9.924 13 7.63 13a7.7 7.7 0 0 1-3.009-.626V9.758c.926.506 2.095.88 3.01.88.617 0 1.058-.165 1.058-.671 0-.518-.658-.755-1.453-1.041C6.026 8.49 4.5 7.94 4.5 6.11 4.5 4.165 5.988 3 8.226 3a7.3 7.3 0 0 1 2.734.505v2.583c-.838-.45-1.896-.703-2.734-.703\" />\n                    </svg>','bi-credit-card','icon',NULL,NULL),(6,1,'Staff Management','Separate login for every staff role with different permissions.','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                        class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                        <path\n                            d=\"M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1zm-7.978-1L7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002-.014.002zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0M6.936 9.28a6 6 0 0 0-1.23-.247A7 7 0 0 0 5 9c-4 0-5 3-5 4q0 1 1 1h4.216A2.24 2.24 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816M4.92 10A5.5 5.5 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0m3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4\" />\n                    </svg>','bi-people','icon',NULL,NULL),(7,1,'POS (Point of Sale)','Complete POS Integration','<svg class=\"size-6 transition duration-75 text-skin-base dark:text-skin-base\" fill=\"currentColor\"\n                        viewBox=\"0 -0.5 25 25\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\n                        <g id=\"SVGRepo_bgCarrier\" stroke-width=\"0\"></g>\n                        <g id=\"SVGRepo_tracerCarrier\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></g>\n                        <g id=\"SVGRepo_iconCarrier\">\n                            <path fill-rule=\"evenodd\"\n                                d=\"M16,6 L20,6 C21.1045695,6 22,6.8954305 22,8 L22,16 C22,17.1045695 21.1045695,18 20,18 L16,18 L16,19.9411765 C16,21.0658573 15.1177541,22 14,22 L4,22 C2.88224586,22 2,21.0658573 2,19.9411765 L2,4.05882353 C2,2.93414267 2.88224586,2 4,2 L14,2 C15.1177541,2 16,2.93414267 16,4.05882353 L16,6 Z M20,11 L16,11 L16,16 L20,16 L20,11 Z M14,19.9411765 L14,4.05882353 C14,4.01396021 13.9868154,4 14,4 L4,4 C4.01318464,4 4,4.01396021 4,4.05882353 L4,19.9411765 C4,19.9860398 4.01318464,20 4,20 L14,20 C13.9868154,20 14,19.9860398 14,19.9411765 Z M5,19 L5,17 L7,17 L7,19 L5,19 Z M8,19 L8,17 L10,17 L10,19 L8,19 Z M11,19 L11,17 L13,17 L13,19 L11,19 Z M5,16 L5,14 L7,14 L7,16 L5,16 Z M8,16 L8,14 L10,14 L10,16 L8,16 Z M11,16 L11,14 L13,14 L13,16 L11,16 Z M13,5 L13,13 L5,13 L5,5 L13,5 Z M7,7 L7,11 L11,11 L11,7 L7,7 Z M20,9 L20,8 L16,8 L16,9 L20,9 Z\">\n                            </path>\n                        </g>\n                    </svg>','bi-pos','icon',NULL,NULL),(8,1,'Custom Floor Plans','Design Your Restaurants Layout.','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                        class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                        <path\n                            d=\"M8.235 1.559a.5.5 0 0 0-.47 0l-7.5 4a.5.5 0 0 0 0 .882L3.188 8 .264 9.559a.5.5 0 0 0 0 .882l7.5 4a.5.5 0 0 0 .47 0l7.5-4a.5.5 0 0 0 0-.882L12.813 8l2.922-1.559a.5.5 0 0 0 0-.882zm3.515 7.008L14.438 10 8 13.433 1.562 10 4.25 8.567l3.515 1.874a.5.5 0 0 0 .47 0zM8 9.433 1.562 6 8 2.567 14.438 6z\" />\n                    </svg>','bi-grid-3x3-gap','icon',NULL,NULL),(9,1,'Kitchen Order Tickets (KOT)','Efficient Kitchen Workflow.','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                        class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                        <path\n                            d=\"M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5m0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5M11.5 4a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm0 2a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm0 2a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm0 2a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm0 2a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1z\" />\n                        <path\n                            d=\"M2.354.646a.5.5 0 0 0-.801.13l-.5 1A.5.5 0 0 0 1 2v13H.5a.5.5 0 0 0 0 1h15a.5.5 0 0 0 0-1H15V2a.5.5 0 0 0-.053-.224l-.5-1a.5.5 0 0 0-.8-.13L13 1.293l-.646-.647a.5.5 0 0 0-.708 0L11 1.293l-.646-.647a.5.5 0 0 0-.708 0L9 1.293 8.354.646a.5.5 0 0 0-.708 0L7 1.293 6.354.646a.5.5 0 0 0-.708 0L5 1.293 4.354.646a.5.5 0 0 0-.708 0L3 1.293zm-.217 1.198.51.51a.5.5 0 0 0 .707 0L4 1.707l.646.647a.5.5 0 0 0 .708 0L6 1.707l.646.647a.5.5 0 0 0 .708 0L8 1.707l.646.647a.5.5 0 0 0 .708 0L10 1.707l.646.647a.5.5 0 0 0 .708 0L12 1.707l.646.647a.5.5 0 0 0 .708 0l.509-.51.137.274V15H2V2.118z\" />\n                    </svg>','bi-receipt','icon',NULL,NULL),(10,1,'Bill Printing','Quick and Accurate Billing.','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\"\n                        class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                        <path d=\"M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1\" />\n                        <path\n                            d=\"M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1\" />\n                    </svg>','bi-printer','icon',NULL,NULL),(11,1,'Reports','Data-Driven Decisions.','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-qr-code-scan text-skin-base dark:text-skin-base size-6\" viewBox=\"0 0 16 16\">\n                    <path fill-rule=\"evenodd\" d=\"M0 0h1v15h15v1H0zm10 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V4.9l-3.613 4.417a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61L13.445 4H10.5a.5.5 0 0 1-.5-.5\"></path>\n                    </svg>','bi-arrow-right-circle-fill','icon',NULL,NULL);
/*!40000 ALTER TABLE `front_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_review_settings`
--

DROP TABLE IF EXISTS `front_review_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `front_review_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` bigint unsigned DEFAULT NULL,
  `reviews` text COLLATE utf8mb4_unicode_ci,
  `reviewer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewer_designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_review_settings_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_review_settings_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_review_settings`
--

LOCK TABLES `front_review_settings` WRITE;
/*!40000 ALTER TABLE `front_review_settings` DISABLE KEYS */;
INSERT INTO `front_review_settings` VALUES (1,1,'\" It has completely transformed how we operate. Managing orders, tables, and staff all from one platform has reduced our workload and made everything run more smoothly. \"','John Martin','Owner of Riverbend Bistro',NULL,NULL),(2,1,'\" The QR Code menu and payment integration have made a huge difference for us, especially after the pandemic. Customers love the ease, and we’ve seen faster table turnover.\"','Emily Thompson','Manager at Lakeside Grill',NULL,NULL),(3,1,'\" We are able to track every order in real time, keep our menu updated, and quickly manage payments. It is like having an extra set of hands in the restaurant.\"','Michael Scott','Owner of Downtown Eats',NULL,NULL);
/*!40000 ALTER TABLE `front_review_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_currencies`
--

DROP TABLE IF EXISTS `global_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` decimal(16,2) DEFAULT NULL,
  `usd_price` decimal(16,2) DEFAULT NULL,
  `is_cryptocurrency` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `currency_position` enum('left','right','left_with_space','right_with_space') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'left',
  `no_of_decimal` int unsigned NOT NULL DEFAULT '2',
  `thousand_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decimal_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('enable','disable') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_currencies`
--

LOCK TABLES `global_currencies` WRITE;
/*!40000 ALTER TABLE `global_currencies` DISABLE KEYS */;
INSERT INTO `global_currencies` VALUES (1,'Dollars','$','USD',NULL,NULL,'no','left',2,',','.','enable','2026-06-05 23:41:52','2026-06-05 23:41:52',NULL),(2,'Rupee','₹','INR',NULL,NULL,'no','left',2,',','.','enable','2026-06-05 23:41:52','2026-06-05 23:41:52',NULL),(3,'Pounds','£','GBP',NULL,NULL,'no','left',2,',','.','enable','2026-06-05 23:41:52','2026-06-05 23:41:52',NULL),(4,'Euros','€','EUR',NULL,NULL,'no','left',2,',','.','enable','2026-06-05 23:41:52','2026-06-05 23:41:52',NULL);
/*!40000 ALTER TABLE `global_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_invoices`
--

DROP TABLE IF EXISTS `global_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `package_id` bigint unsigned DEFAULT NULL,
  `global_subscription_id` bigint unsigned DEFAULT NULL,
  `offline_method_id` bigint unsigned DEFAULT NULL,
  `signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total` int DEFAULT NULL,
  `total` int DEFAULT NULL,
  `billing_frequency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_interval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recurring` enum('yes','no') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `stripe_invoice_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_date` datetime DEFAULT NULL,
  `next_pay_date` datetime DEFAULT NULL,
  `gateway_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `m_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pf_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `global_invoices_restaurant_id_foreign` (`restaurant_id`),
  KEY `global_invoices_currency_id_foreign` (`currency_id`),
  KEY `global_invoices_package_id_foreign` (`package_id`),
  KEY `global_invoices_global_subscription_id_foreign` (`global_subscription_id`),
  KEY `global_invoices_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `global_invoices_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_global_subscription_id_foreign` FOREIGN KEY (`global_subscription_id`) REFERENCES `global_subscriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_invoices`
--

LOCK TABLES `global_invoices` WRITE;
/*!40000 ALTER TABLE `global_invoices` DISABLE KEYS */;
INSERT INTO `global_invoices` VALUES (1,1,1,5,1,NULL,NULL,NULL,'XWDTFTXDR6QRPLM',NULL,NULL,'trial',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-06 05:44:08','2026-07-06 05:44:08','offline','active','2026-06-05 23:44:08','2026-06-05 23:44:08',NULL,NULL,NULL),(2,1,1,3,2,NULL,NULL,NULL,'FOPYOL3RRA4XYVE',NULL,NULL,'lifetime',NULL,199,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 00:00:00',NULL,'offline',NULL,'2026-06-09 04:39:10','2026-06-09 04:39:10',NULL,NULL,NULL);
/*!40000 ALTER TABLE `global_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_settings`
--

DROP TABLE IF EXISTS `global_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supported_until` timestamp NULL DEFAULT NULL,
  `last_license_verified_at` timestamp NULL DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `privacy_policy_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_privacy_consent_checkbox` tinyint(1) NOT NULL DEFAULT '0',
  `show_support_ticket` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dark_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_hex` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_rgb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `license_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hide_cron_job` tinyint(1) NOT NULL DEFAULT '0',
  `last_cron_run` timestamp NULL DEFAULT NULL,
  `system_update` tinyint(1) NOT NULL DEFAULT '1',
  `purchased_on` timestamp NULL DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Asia/Kolkata',
  `time_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'h:i A',
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'd/m/Y',
  `disable_landing_site` tinyint(1) NOT NULL DEFAULT '0',
  `landing_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dynamic',
  `landing_site_type` enum('theme','custom') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'theme',
  `landing_site_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installed_url` tinytext COLLATE utf8mb4_unicode_ci,
  `requires_approval_after_signup` tinyint(1) NOT NULL DEFAULT '0',
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yelp_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_business_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_currency_id` bigint unsigned DEFAULT NULL,
  `show_logo_text` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` text COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `meta_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_fav_icon_android_chrome_192` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_fav_icon_android_chrome_512` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_fav_icon_apple_touch_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_favicon_16` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_favicon_32` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `webmanifest` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_pwa_install_alert_show` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `google_map_api_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `map_provider` enum('google','osm') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'osm',
  `session_driver` enum('file','database') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'database',
  `enable_stripe` tinyint(1) NOT NULL DEFAULT '1',
  `enable_razorpay` tinyint(1) NOT NULL DEFAULT '1',
  `enable_flutterwave` tinyint(1) NOT NULL DEFAULT '1',
  `enable_payfast` tinyint(1) NOT NULL DEFAULT '1',
  `enable_paypal` tinyint(1) NOT NULL DEFAULT '1',
  `enable_paystack` tinyint(1) NOT NULL DEFAULT '1',
  `enable_xendit` tinyint(1) NOT NULL DEFAULT '1',
  `enable_paddle` tinyint(1) NOT NULL DEFAULT '1',
  `enable_epay` tinyint(1) NOT NULL DEFAULT '1',
  `vapid_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vapid_private_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vapid_subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mailto:admin@example.com',
  `enable_mollie` tinyint(1) NOT NULL DEFAULT '1',
  `enable_tap` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `global_settings_default_currency_id_foreign` (`default_currency_id`),
  CONSTRAINT `global_settings_default_currency_id_foreign` FOREIGN KEY (`default_currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_settings`
--

LOCK TABLES `global_settings` WRITE;
/*!40000 ALTER TABLE `global_settings` DISABLE KEYS */;
INSERT INTO `global_settings` VALUES (1,'b351060c-52db-4422-88c3-e552d7822fb4',NULL,'2026-06-05 23:45:03',NULL,NULL,0,1,'2026-06-05 23:44:06','2026-06-05 23:45:03','TableTrack',NULL,NULL,'#A78BFA','167, 139, 250','en',NULL,0,NULL,1,NULL,'Asia/Kolkata','h:i A','d/m/Y',0,'dynamic','theme',NULL,'https://tabletrack.datasolution.com.bd',0,'https://www.facebook.com/','https://www.instagram.com/','https://www.twitter.com/',NULL,'https://business.google.com/',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fb57ebe3f48c7a58fb174562a5941b36',NULL,'0',NULL,'osm','database',1,1,1,1,1,1,1,1,1,NULL,NULL,'mailto:admin@example.com',1,1);
/*!40000 ALTER TABLE `global_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_subscriptions`
--

DROP TABLE IF EXISTS `global_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `package_id` bigint unsigned DEFAULT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trial_ends_at` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `subscribed_on_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_payment_ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_customer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `global_subscriptions_restaurant_id_foreign` (`restaurant_id`),
  KEY `global_subscriptions_package_id_foreign` (`package_id`),
  KEY `global_subscriptions_currency_id_foreign` (`currency_id`),
  CONSTRAINT `global_subscriptions_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_subscriptions_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `global_subscriptions_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_subscriptions`
--

LOCK TABLES `global_subscriptions` WRITE;
/*!40000 ALTER TABLE `global_subscriptions` DISABLE KEYS */;
INSERT INTO `global_subscriptions` VALUES (1,1,5,1,'trial',NULL,'XWDTFTXDR6QRPLM',NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'offline','2026-07-06 05:44:08','inactive','2026-07-06 05:44:08','2026-06-06 05:44:08','2026-06-05 23:44:08','2026-06-09 04:39:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,3,1,'lifetime',NULL,'FOPYOL3RRA4XYVE',NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,'active',NULL,'2026-06-09 00:00:00','2026-06-09 04:39:10','2026-06-09 04:39:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `global_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_categories`
--

DROP TABLE IF EXISTS `item_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `category_name` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_categories_branch_id_foreign` (`branch_id`),
  CONSTRAINT `item_categories_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_categories`
--

LOCK TABLES `item_categories` WRITE;
/*!40000 ALTER TABLE `item_categories` DISABLE KEYS */;
INSERT INTO `item_categories` VALUES (1,1,'{\"en\":\"Drink\"}',NULL,0,'2026-06-06 02:07:33','2026-06-06 02:07:33'),(2,1,'{\"en\":\"Hot\"}',NULL,0,'2026-06-06 02:08:19','2026-06-06 02:08:19'),(3,1,'{\"en\":\"Cold\"}',NULL,0,'2026-06-07 02:48:48','2026-06-07 02:48:48'),(4,1,'{\"en\":\"Meat\"}',NULL,0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(5,1,'{\"en\":\"Kacchi\"}',NULL,0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(6,1,'{\"en\":\"Beverages\"}',NULL,0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(7,1,'{\"en\":\"Breads\"}',NULL,0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(8,1,'{\"en\":\"Starters\"}',NULL,0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(9,1,'{\"en\":\"Main Course\"}',NULL,0,'2026-06-08 23:35:48','2026-06-08 23:35:48'),(10,1,'{\"en\":\"Rice\"}',NULL,0,'2026-06-08 23:35:48','2026-06-08 23:35:48'),(11,3,'{\"en\":\"Drink\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(12,3,'{\"en\":\"Hot\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(13,3,'{\"en\":\"Cold\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(14,3,'{\"en\":\"Meat\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(15,3,'{\"en\":\"Kacchi\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(16,3,'{\"en\":\"Beverages\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(17,3,'{\"en\":\"Breads\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(18,3,'{\"en\":\"Starters\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(19,3,'{\"en\":\"Main Course\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(20,3,'{\"en\":\"Rice\"}',NULL,0,'2026-06-10 01:14:05','2026-06-10 01:14:05');
/*!40000 ALTER TABLE `item_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_modifiers`
--

DROP TABLE IF EXISTS `item_modifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_modifiers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_item_id` bigint unsigned DEFAULT NULL,
  `menu_item_variation_id` bigint unsigned DEFAULT NULL,
  `modifier_group_id` bigint unsigned DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `allow_multiple_selection` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_modifiers_menu_item_id_foreign` (`menu_item_id`),
  KEY `item_modifiers_modifier_group_id_foreign` (`modifier_group_id`),
  KEY `item_modifiers_menu_item_variation_id_foreign` (`menu_item_variation_id`),
  CONSTRAINT `item_modifiers_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `item_modifiers_menu_item_variation_id_foreign` FOREIGN KEY (`menu_item_variation_id`) REFERENCES `menu_item_variations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `item_modifiers_modifier_group_id_foreign` FOREIGN KEY (`modifier_group_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_modifiers`
--

LOCK TABLES `item_modifiers` WRITE;
/*!40000 ALTER TABLE `item_modifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_modifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kot_cancel_reasons`
--

DROP TABLE IF EXISTS `kot_cancel_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kot_cancel_reasons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cancel_order` tinyint(1) NOT NULL DEFAULT '0',
  `cancel_kot` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kot_cancel_reasons_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `kot_cancel_reasons_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kot_cancel_reasons`
--

LOCK TABLES `kot_cancel_reasons` WRITE;
/*!40000 ALTER TABLE `kot_cancel_reasons` DISABLE KEYS */;
INSERT INTO `kot_cancel_reasons` VALUES (1,1,'Customer changed their mind',1,0,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(2,1,'Customer requested to cancel',1,0,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(3,1,'Payment issues',1,0,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(4,1,'Customer no longer wants the order',1,0,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(5,1,'Ingredient not available',0,1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(6,1,'Preparation time too long',0,1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(7,1,'Quality issue with ingredients',0,1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(8,1,'System error/Technical issue',1,1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(9,1,'Restaurant closing early',1,1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(10,1,'Other',1,1,'2026-06-05 23:44:12','2026-06-05 23:44:12');
/*!40000 ALTER TABLE `kot_cancel_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kot_item_modifier_options`
--

DROP TABLE IF EXISTS `kot_item_modifier_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kot_item_modifier_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kot_item_id` bigint unsigned NOT NULL,
  `modifier_option_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kot_item_modifier_options_kot_item_id_foreign` (`kot_item_id`),
  KEY `kot_item_modifier_options_modifier_option_id_foreign` (`modifier_option_id`),
  CONSTRAINT `kot_item_modifier_options_kot_item_id_foreign` FOREIGN KEY (`kot_item_id`) REFERENCES `kot_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kot_item_modifier_options_modifier_option_id_foreign` FOREIGN KEY (`modifier_option_id`) REFERENCES `modifier_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kot_item_modifier_options`
--

LOCK TABLES `kot_item_modifier_options` WRITE;
/*!40000 ALTER TABLE `kot_item_modifier_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `kot_item_modifier_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kot_items`
--

DROP TABLE IF EXISTS `kot_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kot_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kot_id` bigint unsigned NOT NULL,
  `order_item_id` bigint unsigned DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu_item_id` bigint unsigned NOT NULL,
  `menu_item_variation_id` bigint unsigned DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `quantity` int NOT NULL,
  `price` decimal(16,2) DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `is_free_item_from_stamp` tinyint(1) NOT NULL DEFAULT '0',
  `stamp_rule_id` bigint unsigned DEFAULT NULL,
  `discount_amount` decimal(16,2) DEFAULT '0.00',
  `is_discounted` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('pending','cooking','ready','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_reason_id` bigint unsigned DEFAULT NULL,
  `cancel_reason_text` text COLLATE utf8mb4_unicode_ci,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kot_items_menu_item_variation_id_foreign` (`menu_item_variation_id`),
  KEY `kot_items_cancel_reason_id_foreign` (`cancel_reason_id`),
  KEY `idx_kot_items_kot_status` (`kot_id`,`status`),
  KEY `idx_kot_items_menu_variation_qty` (`menu_item_id`,`menu_item_variation_id`,`quantity`),
  KEY `idx_kot_items_order_item` (`order_item_id`),
  KEY `kot_items_cancelled_by_foreign` (`cancelled_by`),
  CONSTRAINT `kot_items_cancel_reason_id_foreign` FOREIGN KEY (`cancel_reason_id`) REFERENCES `kot_cancel_reasons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kot_items_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `kot_items_kot_id_foreign` FOREIGN KEY (`kot_id`) REFERENCES `kots` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kot_items_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kot_items_menu_item_variation_id_foreign` FOREIGN KEY (`menu_item_variation_id`) REFERENCES `menu_item_variations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kot_items_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kot_items`
--

LOCK TABLES `kot_items` WRITE;
/*!40000 ALTER TABLE `kot_items` DISABLE KEYS */;
INSERT INTO `kot_items` VALUES (1,1,NULL,NULL,1,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-06 02:28:19','2026-06-06 02:28:19'),(2,2,NULL,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 01:03:42','2026-06-09 01:03:42'),(3,3,NULL,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 01:06:46','2026-06-09 01:06:46'),(4,4,NULL,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 01:11:08','2026-06-09 01:11:08'),(5,5,NULL,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 01:12:54','2026-06-09 01:12:54'),(6,6,NULL,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 01:16:23','2026-06-09 01:16:23'),(7,7,NULL,NULL,4,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 02:40:46','2026-06-09 02:40:46'),(8,8,NULL,NULL,3,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:08:59','2026-06-09 04:08:59'),(9,9,NULL,NULL,3,NULL,NULL,1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:09:16','2026-06-09 04:09:16'),(10,10,129,NULL,4,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 04:12:04','2026-06-09 23:50:16'),(11,10,130,NULL,8,NULL,NULL,1,850.00,850.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 04:12:04','2026-06-09 23:50:16'),(12,10,131,NULL,13,NULL,NULL,1,320.00,320.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 04:12:04','2026-06-09 23:50:16'),(13,11,NULL,NULL,6,NULL,NULL,1,35.00,35.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 04:14:23','2026-06-09 04:19:44'),(14,11,NULL,NULL,3,NULL,NULL,1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:14:23','2026-06-09 04:14:23'),(15,12,NULL,NULL,5,NULL,NULL,1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:17:49','2026-06-09 04:17:49'),(16,13,NULL,NULL,15,NULL,NULL,1,180.00,180.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:18:35','2026-06-09 04:18:35'),(17,14,102,NULL,3,NULL,NULL,1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:38:36','2026-06-09 04:40:59'),(18,15,132,NULL,16,NULL,NULL,1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:38:57','2026-06-09 23:50:30'),(19,16,111,NULL,12,NULL,NULL,1,680.00,680.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:39:11','2026-06-09 05:05:00'),(20,17,127,NULL,20,NULL,NULL,1,300.00,300.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:46:48','2026-06-09 22:31:21'),(21,17,128,NULL,13,NULL,NULL,1,320.00,320.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:46:48','2026-06-09 22:31:21'),(22,18,NULL,NULL,2,3,NULL,1,NULL,NULL,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:50:02','2026-06-09 04:50:02'),(23,18,NULL,NULL,5,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-09 04:50:02','2026-06-09 04:50:02'),(24,19,NULL,NULL,3,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 04:51:18','2026-06-09 04:51:24'),(25,20,NULL,NULL,8,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:22:12','2026-06-09 22:23:48'),(26,20,NULL,NULL,9,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:22:12','2026-06-09 22:23:48'),(27,20,NULL,NULL,16,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:22:12','2026-06-09 22:23:48'),(28,20,NULL,NULL,18,NULL,NULL,1,NULL,NULL,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:22:12','2026-06-09 22:23:48'),(29,21,125,NULL,7,NULL,NULL,1,10.00,10.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:23:00','2026-06-09 22:25:01'),(30,21,126,NULL,12,NULL,NULL,1,680.00,680.00,0,NULL,0.00,0,'ready',NULL,NULL,NULL,'2026-06-09 22:23:00','2026-06-09 22:25:01'),(31,22,136,NULL,34,NULL,NULL,1,320.00,320.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 02:51:28','2026-06-10 03:01:41'),(32,22,137,NULL,27,NULL,NULL,1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 02:51:28','2026-06-10 03:01:41'),(33,22,138,NULL,23,6,NULL,1,40.00,40.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 02:51:28','2026-06-10 03:01:41'),(34,23,139,NULL,36,NULL,NULL,1,180.00,180.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 02:52:39','2026-06-10 03:01:41'),(37,25,140,NULL,41,NULL,NULL,1,300.00,300.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:39:19','2026-06-10 03:45:46'),(38,25,141,NULL,25,NULL,NULL,1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:39:19','2026-06-10 03:45:46'),(39,25,142,NULL,26,NULL,NULL,1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:39:19','2026-06-10 03:45:46'),(40,26,NULL,NULL,29,NULL,NULL,1,850.00,850.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:53:08','2026-06-10 03:53:08'),(41,26,NULL,NULL,31,NULL,NULL,1,550.00,550.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:53:08','2026-06-10 03:53:08'),(42,26,NULL,NULL,32,NULL,NULL,1,450.00,450.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 03:53:08','2026-06-10 03:53:08'),(43,27,146,'TXN_6a293722438f03.11858946_187993',25,NULL,'',1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:06:26','2026-06-10 04:06:26'),(44,27,147,'TXN_6a293722438f03.11858946_187993',23,5,'',1,25.00,25.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:06:26','2026-06-10 04:06:26'),(45,28,148,'TXN_6a2937a5d5a367.70330261_427592',3,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(46,28,149,'TXN_6a2937a5d5a367.70330261_427592',6,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(47,28,150,'TXN_6a2937a5d5a367.70330261_427592',5,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(48,29,151,'TXN_6a2937ed4990d5.57776457_161190',24,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(49,29,152,'TXN_6a2937ed4990d5.57776457_161190',27,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(50,29,153,'TXN_6a2937ed4990d5.57776457_161190',26,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(51,30,154,'TXN_6a2939db6d29f6.23867707_380018',1,NULL,'',1,30.00,30.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(52,30,155,'TXN_6a2939db6d29f6.23867707_380018',5,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(53,30,156,'TXN_6a2939db6d29f6.23867707_380018',7,NULL,'',1,10.00,10.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(54,30,157,'TXN_6a2939db6d29f6.23867707_380018',8,NULL,'',1,850.00,850.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(58,33,161,'TXN_6a2942df937b25.40371338_873911',25,NULL,'',1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(59,33,162,'TXN_6a2942df937b25.40371338_873911',34,NULL,'',1,320.00,320.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(60,33,163,'TXN_6a2942df937b25.40371338_873911',23,6,'',1,40.00,40.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(61,34,164,'TXN_6a2943da36b730.64646559_582909',6,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(62,34,165,'TXN_6a2943da36b730.64646559_582909',5,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(63,34,166,'TXN_6a2943da36b730.64646559_582909',3,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(64,35,167,'TXN_6a294410287aa9.35896749_813509',24,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(65,35,168,'TXN_6a294410287aa9.35896749_813509',27,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(66,35,169,'TXN_6a294410287aa9.35896749_813509',26,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(67,36,170,'TXN_6a2946933d0188.10575622_421011',25,NULL,'',1,500.00,500.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(68,36,171,'TXN_6a2946933d0188.10575622_421011',27,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(69,36,172,'TXN_6a2946933d0188.10575622_421011',26,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(70,37,173,'TXN_6a2948f7a69497.94260701_268751',27,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(71,37,174,'TXN_6a2948f7a69497.94260701_268751',24,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(72,37,175,'TXN_6a2948f7a69497.94260701_268751',26,NULL,'',1,20.00,20.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(73,38,176,'TXN_6a294b0c226a20.28502024_323223',29,NULL,'',1,850.00,850.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:31:24','2026-06-10 05:31:24'),(74,39,177,'TXN_6a294cd4e3bc53.28437236_310371',34,NULL,'',1,320.00,320.00,0,NULL,0.00,0,'cooking',NULL,NULL,NULL,'2026-06-10 05:39:00','2026-06-10 05:45:19'),(75,40,178,'TXN_6a294d21a8a4b5.20909758_211799',3,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 05:40:17','2026-06-10 05:40:17'),(76,41,186,'TXN_6a2a445d65cc03.51374602_541038',29,NULL,'',1,850.00,850.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:15:09','2026-06-10 23:15:09'),(77,42,187,'TXN_6a2a4546d06b14.53624515_544773',34,NULL,'',1,320.00,320.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:19:02','2026-06-10 23:19:02'),(78,43,188,NULL,33,NULL,NULL,1,680.00,680.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:23:01','2026-06-10 23:23:47'),(79,44,189,'TXN_6a2a46cf6ed756.72299177_348605',41,NULL,'',1,300.00,300.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:25:35','2026-06-10 23:25:35'),(80,45,190,'TXN_6a2a4757459ed5.47220017_300461',27,NULL,'',1,35.00,35.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(81,45,191,'TXN_6a2a4757459ed5.47220017_300461',24,NULL,'',1,120.00,120.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(82,45,192,'TXN_6a2a4757459ed5.47220017_300461',22,NULL,'',1,30.00,30.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(83,45,193,'TXN_6a2a4757459ed5.47220017_300461',23,5,'',1,25.00,25.00,0,NULL,0.00,0,NULL,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51');
/*!40000 ALTER TABLE `kot_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kot_places`
--

DROP TABLE IF EXISTS `kot_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kot_places` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `printer_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kot_places_branch_id_foreign` (`branch_id`),
  KEY `kot_places_printer_id_foreign` (`printer_id`),
  CONSTRAINT `kot_places_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kot_places_printer_id_foreign` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kot_places`
--

LOCK TABLES `kot_places` WRITE;
/*!40000 ALTER TABLE `kot_places` DISABLE KEYS */;
INSERT INTO `kot_places` VALUES (1,1,1,'Default Kitchen','food',1,1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,2,2,'Default Kitchen','food',1,1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,3,3,'Default Kitchen','food',1,1,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `kot_places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kot_settings`
--

DROP TABLE IF EXISTS `kot_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kot_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `default_status_pos` enum('pending','cooking') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `default_status_customer` enum('pending','cooking') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `enable_item_level_status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kot_settings_branch_id_foreign` (`branch_id`),
  CONSTRAINT `kot_settings_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kot_settings`
--

LOCK TABLES `kot_settings` WRITE;
/*!40000 ALTER TABLE `kot_settings` DISABLE KEYS */;
INSERT INTO `kot_settings` VALUES (1,1,'pending','pending',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,'pending','pending',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,2,'pending','pending',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,2,'pending','pending',1,'2026-06-05 23:44:10','2026-06-05 23:44:10'),(5,3,'pending','pending',1,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `kot_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kots`
--

DROP TABLE IF EXISTS `kots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `kot_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_number` int unsigned DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `order_type_id` bigint unsigned DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending_confirmation','in_kitchen','food_ready','served','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_kitchen',
  `cancel_reason_id` bigint unsigned DEFAULT NULL,
  `cancel_reason_text` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kots_cancel_reason_id_foreign` (`cancel_reason_id`),
  KEY `kots_order_type_id_foreign` (`order_type_id`),
  KEY `idx_kots_order_status` (`order_id`,`status`),
  KEY `idx_kots_branch` (`branch_id`),
  CONSTRAINT `kots_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kots_cancel_reason_id_foreign` FOREIGN KEY (`cancel_reason_id`) REFERENCES `kot_cancel_reasons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kots_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kots_order_type_id_foreign` FOREIGN KEY (`order_type_id`) REFERENCES `order_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kots`
--

LOCK TABLES `kots` WRITE;
/*!40000 ALTER TABLE `kots` DISABLE KEYS */;
INSERT INTO `kots` VALUES (1,1,'1',1,1,1,NULL,NULL,'pending_confirmation',NULL,NULL,'2026-06-06 02:28:19','2026-06-06 02:28:19'),(2,1,'2',1,14,1,NULL,'','served',NULL,NULL,'2026-06-09 01:03:42','2026-06-09 01:04:56'),(3,1,'3',2,15,1,NULL,'','served',NULL,NULL,'2026-06-09 01:06:46','2026-06-09 01:07:00'),(4,1,'4',3,17,1,NULL,'','served',NULL,NULL,'2026-06-09 01:11:08','2026-06-09 01:11:23'),(5,1,'5',4,18,1,NULL,'','served',NULL,NULL,'2026-06-09 01:12:54','2026-06-09 01:13:03'),(6,1,'6',5,19,1,NULL,'','served',NULL,NULL,'2026-06-09 01:16:23','2026-06-09 01:16:39'),(7,1,'7',6,23,3,NULL,NULL,'served',NULL,NULL,'2026-06-09 02:40:46','2026-06-09 03:57:26'),(8,1,'8',7,46,1,NULL,NULL,'served',NULL,NULL,'2026-06-09 04:08:59','2026-06-09 04:14:06'),(9,1,'9',8,47,1,NULL,'','served',NULL,NULL,'2026-06-09 04:09:16','2026-06-09 04:14:04'),(10,1,'10',9,48,1,NULL,'','served',NULL,NULL,'2026-06-09 04:12:04','2026-06-09 04:13:43'),(11,1,'11',10,49,1,NULL,'','served',NULL,NULL,'2026-06-09 04:14:23','2026-06-09 04:20:05'),(12,1,'12',11,49,1,NULL,'','served',NULL,NULL,'2026-06-09 04:17:49','2026-06-09 04:19:57'),(13,1,'13',12,49,1,NULL,'','served',NULL,NULL,'2026-06-09 04:18:35','2026-06-09 04:19:55'),(14,1,'14',13,55,1,NULL,'','served',NULL,NULL,'2026-06-09 04:38:36','2026-06-09 04:40:47'),(15,1,'15',14,56,1,NULL,'','served',NULL,NULL,'2026-06-09 04:38:57','2026-06-09 23:51:02'),(16,1,'16',15,57,1,NULL,'','served',NULL,NULL,'2026-06-09 04:39:11','2026-06-09 05:02:00'),(17,1,'17',16,59,1,NULL,'','served',NULL,NULL,'2026-06-09 04:46:48','2026-06-09 04:55:22'),(18,1,'18',17,60,3,NULL,NULL,'served',NULL,NULL,'2026-06-09 04:50:02','2026-06-09 04:57:09'),(19,1,'19',18,54,1,NULL,NULL,'served',NULL,NULL,'2026-06-09 04:51:18','2026-06-09 04:51:25'),(20,1,'20',1,70,1,NULL,NULL,'served',NULL,NULL,'2026-06-09 22:22:12','2026-06-09 22:23:58'),(21,1,'21',2,71,1,NULL,'','served',NULL,NULL,'2026-06-09 22:23:00','2026-06-09 22:23:56'),(22,3,'1',1,73,7,NULL,'','served',NULL,NULL,'2026-06-10 02:51:28','2026-06-10 03:01:07'),(23,3,'2',2,73,7,NULL,'','served',NULL,NULL,'2026-06-10 02:52:39','2026-06-10 02:58:07'),(25,3,'4',4,75,7,NULL,'VIP','served',NULL,NULL,'2026-06-10 03:39:19','2026-06-10 03:45:30'),(26,3,'5',5,76,7,NULL,'Premium server required.','served',NULL,NULL,'2026-06-10 03:53:08','2026-06-10 03:56:03'),(27,3,'7',6,77,7,'TXN_6a293722438f03.11858946_187993',NULL,'served',NULL,NULL,'2026-06-10 04:06:26','2026-06-10 04:08:02'),(28,1,'23',3,78,1,'TXN_6a2937a5d5a367.70330261_427592',NULL,'pending_confirmation',NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(29,3,'9',7,79,7,'TXN_6a2937ed4990d5.57776457_161190',NULL,'served',NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:13:45'),(30,1,'25',4,80,1,'TXN_6a2939db6d29f6.23867707_380018',NULL,'served',NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:59'),(33,3,'11',8,83,7,'TXN_6a2942df937b25.40371338_873911','Customer 01','served',NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:58:24'),(34,1,'27',5,84,1,'TXN_6a2943da36b730.64646559_582909',NULL,'pending_confirmation',NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(35,3,'13',9,85,7,'TXN_6a294410287aa9.35896749_813509','Customer 02','served',NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:03:07'),(36,3,'15',10,86,7,'TXN_6a2946933d0188.10575622_421011',NULL,'served',NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:14:15'),(37,3,'17',11,87,7,'TXN_6a2948f7a69497.94260701_268751',NULL,'served',NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:23:48'),(38,3,'19',12,88,7,'TXN_6a294b0c226a20.28502024_323223',NULL,'served',NULL,NULL,'2026-06-10 05:31:24','2026-06-10 05:32:08'),(39,3,'21',13,89,9,'TXN_6a294cd4e3bc53.28437236_310371',NULL,'served',NULL,NULL,'2026-06-10 05:39:00','2026-06-10 05:45:23'),(40,1,'29',6,89,9,'TXN_6a294d21a8a4b5.20909758_211799',NULL,'pending_confirmation',NULL,NULL,'2026-06-10 05:40:17','2026-06-10 05:40:17'),(41,3,'23',1,96,9,'TXN_6a2a445d65cc03.51374602_541038',NULL,'served',NULL,NULL,'2026-06-10 23:15:09','2026-06-10 23:16:45'),(42,3,'25',2,97,9,'TXN_6a2a4546d06b14.53624515_544773',NULL,'served',NULL,NULL,'2026-06-10 23:19:02','2026-06-10 23:19:43'),(43,3,'26',3,98,9,NULL,'','served',NULL,NULL,'2026-06-10 23:23:01','2026-06-10 23:23:19'),(44,3,'28',4,99,7,'TXN_6a2a46cf6ed756.72299177_348605',NULL,'served',NULL,NULL,'2026-06-10 23:25:35','2026-06-10 23:26:07'),(45,3,'30',5,100,7,'TXN_6a2a4757459ed5.47220017_300461',NULL,'served',NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:28:23');
/*!40000 ALTER TABLE `kots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_settings`
--

DROP TABLE IF EXISTS `language_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `flag_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_rtl` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_settings`
--

LOCK TABLES `language_settings` WRITE;
/*!40000 ALTER TABLE `language_settings` DISABLE KEYS */;
INSERT INTO `language_settings` VALUES (1,'en','English','gb',1,0,NULL,NULL),(2,'ar','Arabic','sa',0,1,NULL,NULL),(3,'de','German','de',0,0,NULL,NULL),(4,'es','Spanish','es',0,0,NULL,NULL),(5,'et','Estonian','et',0,0,NULL,NULL),(6,'fa','Farsi','ir',0,1,NULL,NULL),(7,'fr','French','fr',0,0,NULL,NULL),(8,'el','Greek','gr',0,0,NULL,NULL),(9,'it','Italian','it',0,0,NULL,NULL),(10,'nl','Dutch','nl',0,0,NULL,NULL),(11,'pl','Polish','pl',0,0,NULL,NULL),(12,'pt','Portuguese','pt',0,0,NULL,NULL),(13,'pt-br','Portuguese (Brazil)','br',0,0,NULL,NULL),(14,'ro','Romanian','ro',0,0,NULL,NULL),(15,'ru','Russian','ru',0,0,NULL,NULL),(16,'tr','Turkish','tr',0,0,NULL,NULL),(17,'zh-CN','Chinese (S)','cn',0,0,NULL,NULL),(18,'zh-TW','Chinese (T)','cn',0,0,NULL,NULL);
/*!40000 ALTER TABLE `language_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltm_translations`
--

DROP TABLE IF EXISTS `ltm_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ltm_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `status` int NOT NULL DEFAULT '0',
  `locale` varchar(191) COLLATE utf8mb4_bin NOT NULL,
  `group` varchar(191) COLLATE utf8mb4_bin NOT NULL,
  `key` text COLLATE utf8mb4_bin NOT NULL,
  `value` text COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltm_translations`
--

LOCK TABLES `ltm_translations` WRITE;
/*!40000 ALTER TABLE `ltm_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ltm_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_item_prices`
--

DROP TABLE IF EXISTS `menu_item_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_item_prices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_item_id` bigint unsigned NOT NULL,
  `order_type_id` bigint unsigned NOT NULL,
  `delivery_app_id` bigint unsigned DEFAULT NULL,
  `menu_item_variation_id` bigint unsigned DEFAULT NULL,
  `calculated_price` decimal(16,2) NOT NULL,
  `override_price` decimal(16,2) DEFAULT NULL,
  `final_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_item_prices_delivery_app_id_foreign` (`delivery_app_id`),
  KEY `menu_item_prices_menu_item_variation_id_foreign` (`menu_item_variation_id`),
  KEY `idx_prices_item_status_variation_type_app` (`menu_item_id`,`status`,`menu_item_variation_id`,`order_type_id`,`delivery_app_id`),
  KEY `idx_prices_item_status_type_app` (`menu_item_id`,`status`,`order_type_id`,`delivery_app_id`),
  KEY `idx_prices_type_app_status` (`order_type_id`,`delivery_app_id`,`status`),
  KEY `idx_prices_menu_item_id` (`menu_item_id`),
  CONSTRAINT `menu_item_prices_delivery_app_id_foreign` FOREIGN KEY (`delivery_app_id`) REFERENCES `delivery_platforms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_item_prices_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_item_prices_menu_item_variation_id_foreign` FOREIGN KEY (`menu_item_variation_id`) REFERENCES `menu_item_variations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_item_prices_order_type_id_foreign` FOREIGN KEY (`order_type_id`) REFERENCES `order_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_item_prices`
--

LOCK TABLES `menu_item_prices` WRITE;
/*!40000 ALTER TABLE `menu_item_prices` DISABLE KEYS */;
INSERT INTO `menu_item_prices` VALUES (1,2,1,NULL,1,15.00,NULL,15.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(2,2,2,NULL,1,15.00,NULL,15.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(3,2,3,NULL,1,15.00,NULL,15.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(4,2,1,NULL,2,25.00,NULL,25.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(5,2,2,NULL,2,25.00,NULL,25.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(6,2,3,NULL,2,25.00,NULL,25.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(7,2,1,NULL,3,40.00,NULL,40.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(8,2,2,NULL,3,40.00,NULL,40.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(9,2,3,NULL,3,40.00,NULL,40.00,1,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(16,6,1,NULL,NULL,35.00,NULL,35.00,1,'2026-06-08 23:37:27','2026-06-08 23:37:27'),(17,6,2,NULL,NULL,35.00,NULL,35.00,1,'2026-06-08 23:37:27','2026-06-08 23:37:27'),(18,6,3,NULL,NULL,35.00,NULL,35.00,1,'2026-06-08 23:37:27','2026-06-08 23:37:27'),(19,3,1,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:38:29','2026-06-08 23:38:29'),(20,3,2,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:38:29','2026-06-08 23:38:29'),(21,3,3,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:38:29','2026-06-08 23:38:29'),(25,19,1,NULL,NULL,130.00,NULL,130.00,1,'2026-06-08 23:39:05','2026-06-08 23:39:05'),(26,19,2,NULL,NULL,130.00,NULL,130.00,1,'2026-06-08 23:39:05','2026-06-08 23:39:05'),(27,19,3,NULL,NULL,130.00,NULL,130.00,1,'2026-06-08 23:39:05','2026-06-08 23:39:05'),(31,11,1,NULL,NULL,450.00,NULL,450.00,1,'2026-06-08 23:39:43','2026-06-08 23:39:43'),(32,11,2,NULL,NULL,450.00,NULL,450.00,1,'2026-06-08 23:39:43','2026-06-08 23:39:43'),(33,11,3,NULL,NULL,450.00,NULL,450.00,1,'2026-06-08 23:39:43','2026-06-08 23:39:43'),(34,7,1,NULL,NULL,10.00,NULL,10.00,1,'2026-06-08 23:40:08','2026-06-08 23:40:08'),(35,7,2,NULL,NULL,10.00,NULL,10.00,1,'2026-06-08 23:40:08','2026-06-08 23:40:08'),(36,7,3,NULL,NULL,10.00,NULL,10.00,1,'2026-06-08 23:40:08','2026-06-08 23:40:08'),(37,5,1,NULL,NULL,20.00,NULL,20.00,1,'2026-06-08 23:40:25','2026-06-08 23:40:25'),(38,5,2,NULL,NULL,20.00,NULL,20.00,1,'2026-06-08 23:40:25','2026-06-08 23:40:25'),(39,5,3,NULL,NULL,20.00,NULL,20.00,1,'2026-06-08 23:40:25','2026-06-08 23:40:25'),(40,9,1,NULL,NULL,750.00,NULL,750.00,1,'2026-06-08 23:40:56','2026-06-08 23:40:56'),(41,9,2,NULL,NULL,750.00,NULL,750.00,1,'2026-06-08 23:40:56','2026-06-08 23:40:56'),(42,9,3,NULL,NULL,750.00,NULL,750.00,1,'2026-06-08 23:40:56','2026-06-08 23:40:56'),(46,10,1,NULL,NULL,550.00,NULL,550.00,1,'2026-06-08 23:42:49','2026-06-08 23:42:49'),(47,10,2,NULL,NULL,550.00,NULL,550.00,1,'2026-06-08 23:42:49','2026-06-08 23:42:49'),(48,10,3,NULL,NULL,550.00,NULL,550.00,1,'2026-06-08 23:42:49','2026-06-08 23:42:49'),(49,8,1,NULL,NULL,850.00,NULL,850.00,1,'2026-06-08 23:43:14','2026-06-08 23:43:14'),(50,8,2,NULL,NULL,850.00,NULL,850.00,1,'2026-06-08 23:43:14','2026-06-08 23:43:14'),(51,8,3,NULL,NULL,850.00,NULL,850.00,1,'2026-06-08 23:43:14','2026-06-08 23:43:14'),(52,12,1,NULL,NULL,680.00,NULL,680.00,1,'2026-06-08 23:43:58','2026-06-08 23:43:58'),(53,12,2,NULL,NULL,680.00,NULL,680.00,1,'2026-06-08 23:43:58','2026-06-08 23:43:58'),(54,12,3,NULL,NULL,680.00,NULL,680.00,1,'2026-06-08 23:43:58','2026-06-08 23:43:58'),(58,14,1,NULL,NULL,250.00,NULL,250.00,1,'2026-06-08 23:54:21','2026-06-08 23:54:21'),(59,14,2,NULL,NULL,250.00,NULL,250.00,1,'2026-06-08 23:54:21','2026-06-08 23:54:21'),(60,14,3,NULL,NULL,250.00,NULL,250.00,1,'2026-06-08 23:54:21','2026-06-08 23:54:21'),(61,18,1,NULL,NULL,80.00,NULL,80.00,1,'2026-06-08 23:54:38','2026-06-08 23:54:38'),(62,18,2,NULL,NULL,80.00,NULL,80.00,1,'2026-06-08 23:54:38','2026-06-08 23:54:38'),(63,18,3,NULL,NULL,80.00,NULL,80.00,1,'2026-06-08 23:54:38','2026-06-08 23:54:38'),(64,16,1,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:55:19','2026-06-08 23:55:19'),(65,16,2,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:55:19','2026-06-08 23:55:19'),(66,16,3,NULL,NULL,120.00,NULL,120.00,1,'2026-06-08 23:55:19','2026-06-08 23:55:19'),(67,17,1,NULL,NULL,90.00,NULL,90.00,1,'2026-06-08 23:55:36','2026-06-08 23:55:36'),(68,17,2,NULL,NULL,90.00,NULL,90.00,1,'2026-06-08 23:55:36','2026-06-08 23:55:36'),(69,17,3,NULL,NULL,90.00,NULL,90.00,1,'2026-06-08 23:55:36','2026-06-08 23:55:36'),(70,15,1,NULL,NULL,180.00,NULL,180.00,1,'2026-06-08 23:55:55','2026-06-08 23:55:55'),(71,15,2,NULL,NULL,180.00,NULL,180.00,1,'2026-06-08 23:55:55','2026-06-08 23:55:55'),(72,15,3,NULL,NULL,180.00,NULL,180.00,1,'2026-06-08 23:55:55','2026-06-08 23:55:55'),(73,20,1,NULL,NULL,300.00,NULL,300.00,1,'2026-06-09 04:43:30','2026-06-09 04:43:30'),(74,20,2,NULL,NULL,300.00,NULL,300.00,1,'2026-06-09 04:43:30','2026-06-09 04:43:30'),(75,20,3,NULL,NULL,300.00,NULL,300.00,1,'2026-06-09 04:43:30','2026-06-09 04:43:30'),(76,13,1,NULL,NULL,320.00,NULL,320.00,1,'2026-06-09 04:43:51','2026-06-09 04:43:51'),(77,13,2,NULL,NULL,320.00,NULL,320.00,1,'2026-06-09 04:43:51','2026-06-09 04:43:51'),(78,13,3,NULL,NULL,320.00,NULL,320.00,1,'2026-06-09 04:43:51','2026-06-09 04:43:51'),(82,4,1,NULL,NULL,500.00,NULL,500.00,1,'2026-06-09 04:44:12','2026-06-09 04:44:12'),(83,4,2,NULL,NULL,500.00,NULL,500.00,1,'2026-06-09 04:44:12','2026-06-09 04:44:12'),(84,4,3,NULL,NULL,500.00,NULL,500.00,1,'2026-06-09 04:44:12','2026-06-09 04:44:12');
/*!40000 ALTER TABLE `menu_item_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_item_tax`
--

DROP TABLE IF EXISTS `menu_item_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_item_tax` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_item_id` bigint unsigned NOT NULL,
  `tax_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_item_tax_menu_item_id_foreign` (`menu_item_id`),
  KEY `menu_item_tax_tax_id_foreign` (`tax_id`),
  CONSTRAINT `menu_item_tax_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_item_tax_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_item_tax`
--

LOCK TABLES `menu_item_tax` WRITE;
/*!40000 ALTER TABLE `menu_item_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_item_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_item_translations`
--

DROP TABLE IF EXISTS `menu_item_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_item_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_item_id` bigint unsigned NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_item_translations_menu_item_id_locale_unique` (`menu_item_id`,`locale`),
  KEY `menu_item_translations_locale_index` (`locale`),
  CONSTRAINT `menu_item_translations_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_item_translations`
--

LOCK TABLES `menu_item_translations` WRITE;
/*!40000 ALTER TABLE `menu_item_translations` DISABLE KEYS */;
INSERT INTO `menu_item_translations` VALUES (1,1,'en','Cofee',NULL),(2,2,'en','Water',''),(3,3,'en','Lahori Nihari','Lahori Nihari Description'),(4,4,'en','Bashmoti Kacchi','Bashmoti Kacchi with borhani'),(5,6,'en','Naan','Soft and fluffy bread baked in a tandoor.'),(6,20,'en','Hyderabadi Chicken Biryani','Fragrant rice cooked with tender meat and aromatic spices.'),(7,19,'en','Uttapam','Thick rice and lentil pancake topped with onions and tomatoes.'),(8,13,'en','Butter Chicken','Tender chicken cooked in a rich tomato and butter gravy.'),(9,11,'en','Vegetable Hakka Noodles','Vegetable Hakka Noodles'),(10,7,'en','Tandoori Roti','Traditional whole wheat bread cooked in a clay oven.'),(11,5,'en','Drinking Water','Mum Drinking Water'),(12,9,'en','Spring Rolls','Crispy rolls stuffed with a mix of vegetables and served with tangy dip.'),(13,8,'en','Veg Manchow Soup','Spicy vegetable soup with crispy fried noodles.'),(14,10,'en','Chilli Paneer','Spicy cottage cheese cubes tossed in a tangy Indo-Chinese sauce.'),(15,12,'en','Chicken Manchurian','Juicy chicken balls in a tangy Manchurian sauce.'),(16,14,'en','Paneer Tikka','Grilled cottage cheese marinated in spicy yogurt.'),(17,18,'en','Medu Vada','Crispy lentil fritters with chutney and sambar.'),(18,16,'en','Masala Dosa','Crispy rice and lentil crepe filled with spiced mashed potatoes.'),(19,17,'en','Idli Sambar','Steamed rice cakes served with lentil soup and chutney.'),(20,15,'en','Dal Makhani','Creamy and rich black lentils cooked with butter and spices.'),(21,22,'en','Cofee',NULL),(22,23,'en','Water',''),(23,24,'en','Lahori Nihari','Lahori Nihari Description'),(24,25,'en','Bashmoti Kacchi','Bashmoti Kacchi with borhani'),(25,26,'en','Drinking Water','Mum Drinking Water'),(26,27,'en','Naan','Soft and fluffy bread baked in a tandoor.'),(27,28,'en','Tandoori Roti','Traditional whole wheat bread cooked in a clay oven.'),(28,29,'en','Veg Manchow Soup','Spicy vegetable soup with crispy fried noodles.'),(29,30,'en','Spring Rolls','Crispy rolls stuffed with a mix of vegetables and served with tangy dip.'),(30,31,'en','Chilli Paneer','Spicy cottage cheese cubes tossed in a tangy Indo-Chinese sauce.'),(31,32,'en','Vegetable Hakka Noodles','Vegetable Hakka Noodles'),(32,33,'en','Chicken Manchurian','Juicy chicken balls in a tangy Manchurian sauce.'),(33,34,'en','Butter Chicken','Tender chicken cooked in a rich tomato and butter gravy.'),(34,35,'en','Paneer Tikka','Grilled cottage cheese marinated in spicy yogurt.'),(35,36,'en','Dal Makhani','Creamy and rich black lentils cooked with butter and spices.'),(36,37,'en','Masala Dosa','Crispy rice and lentil crepe filled with spiced mashed potatoes.'),(37,38,'en','Idli Sambar','Steamed rice cakes served with lentil soup and chutney.'),(38,39,'en','Medu Vada','Crispy lentil fritters with chutney and sambar.'),(39,40,'en','Uttapam','Thick rice and lentil pancake topped with onions and tomatoes.'),(40,41,'en','Hyderabadi Chicken Biryani','Fragrant rice cooked with tender meat and aromatic spices.');
/*!40000 ALTER TABLE `menu_item_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_item_variations`
--

DROP TABLE IF EXISTS `menu_item_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_item_variations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `menu_item_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_item_variations_menu_item_id_foreign` (`menu_item_id`),
  CONSTRAINT `menu_item_variations_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_item_variations`
--

LOCK TABLES `menu_item_variations` WRITE;
/*!40000 ALTER TABLE `menu_item_variations` DISABLE KEYS */;
INSERT INTO `menu_item_variations` VALUES (1,'500ml',15.00,2,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(2,'1lt',25.00,2,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(3,'2lt',40.00,2,'2026-06-07 02:50:55','2026-06-07 02:50:55'),(4,'500ml',15.00,23,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(5,'1lt',25.00,23,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(6,'2lt',40.00,23,'2026-06-10 01:14:05','2026-06-10 01:14:05');
/*!40000 ALTER TABLE `menu_item_variations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `kot_place_id` bigint unsigned DEFAULT NULL,
  `item_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` enum('veg','non-veg','egg','drink','other','halal') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dietary_labels` json DEFAULT NULL,
  `price` decimal(16,2) DEFAULT NULL,
  `menu_id` bigint unsigned NOT NULL,
  `item_category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `preparation_time` int DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `show_on_customer_site` tinyint(1) NOT NULL DEFAULT '1',
  `in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `tax_inclusive` tinyint(1) NOT NULL DEFAULT '0',
  `eu_allergen_keys` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_branch_available` (`branch_id`,`is_available`),
  KEY `idx_menu_items_category` (`item_category_id`),
  KEY `idx_menu_items_menu` (`menu_id`),
  KEY `idx_menu_items_menu_category` (`menu_id`,`item_category_id`),
  CONSTRAINT `menu_items_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_items_item_category_id_foreign` FOREIGN KEY (`item_category_id`) REFERENCES `item_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,1,NULL,'Cofee','5864ec792412c83f089223e689f23a24.jpg',NULL,'drink','[]',30.00,1,2,'2026-06-06 02:09:57','2026-06-06 02:09:57',10,1,1,1,0,0,NULL),(2,1,NULL,'Water','5301c0c9b2fa5c31d0c6946f4fbf818b.jpg','','drink','[]',0.00,1,1,'2026-06-07 02:50:55','2026-06-07 02:50:55',5,1,1,1,0,0,NULL),(3,1,1,'Lahori Nihari','207ab28e7615905345eb68891e4259a9.jpg','Lahori Nihari Description','non-veg','[]',120.00,2,4,'2026-06-08 23:35:48','2026-06-08 23:38:29',NULL,1,1,1,0,0,NULL),(4,1,1,'Bashmoti Kacchi','c39902a651f729fefc9a5f3040ceae24.jpg','Bashmoti Kacchi with borhani','non-veg','[]',500.00,3,5,'2026-06-08 23:35:48','2026-06-09 04:44:12',30,0,1,1,0,0,NULL),(5,1,1,'Drinking Water','7a8f163a2b8fb34a283b3f1504aa36b9.webp','Mum Drinking Water','veg','[]',20.00,3,6,'2026-06-08 23:35:48','2026-06-08 23:40:25',NULL,1,1,1,0,0,NULL),(6,1,1,'Naan','c25d7ba3a0b4fa897ca309974b04fa7d.jpeg','Soft and fluffy bread baked in a tandoor.','veg','[]',35.00,2,7,'2026-06-08 23:35:48','2026-06-08 23:37:27',NULL,1,1,1,0,0,NULL),(7,1,1,'Tandoori Roti','f5f3d0bc8237af366c7dae19388314d5.webp','Traditional whole wheat bread cooked in a clay oven.','veg','[]',10.00,2,7,'2026-06-08 23:35:48','2026-06-08 23:40:08',NULL,1,1,1,0,0,NULL),(8,1,1,'Veg Manchow Soup','40e8db6b5c357f29da3a9679d801987a.jpg','Spicy vegetable soup with crispy fried noodles.','veg','[]',850.00,4,8,'2026-06-08 23:35:48','2026-06-08 23:43:14',NULL,1,1,1,0,0,NULL),(9,1,1,'Spring Rolls','f1e214b09cf13f4061879df8825cf31e.webp','Crispy rolls stuffed with a mix of vegetables and served with tangy dip.','veg','[]',750.00,4,8,'2026-06-08 23:35:48','2026-06-08 23:40:56',NULL,1,1,1,0,0,NULL),(10,1,1,'Chilli Paneer','903a048de5d1003ac8135dd44b8f83ff.jpg','Spicy cottage cheese cubes tossed in a tangy Indo-Chinese sauce.','veg','[]',550.00,4,8,'2026-06-08 23:35:48','2026-06-08 23:42:49',NULL,1,1,1,0,0,NULL),(11,1,1,'Vegetable Hakka Noodles','0a9265422c1664c67674f2f20855e4b1.jpg','Vegetable Hakka Noodles','veg','[]',450.00,4,8,'2026-06-08 23:35:48','2026-06-08 23:39:43',NULL,1,1,1,0,0,NULL),(12,1,1,'Chicken Manchurian','661968cf77f3ce9d2461164a343f3e29.jpg','Juicy chicken balls in a tangy Manchurian sauce.','veg','[]',680.00,4,8,'2026-06-08 23:35:48','2026-06-08 23:43:58',NULL,1,1,1,0,0,NULL),(13,1,1,'Butter Chicken','ba9f22a13e9bcf384f8e01ee7d1d4c53.jpg','Tender chicken cooked in a rich tomato and butter gravy.','non-veg','[]',320.00,5,9,'2026-06-08 23:35:48','2026-06-09 04:43:51',40,1,1,1,0,0,NULL),(14,1,1,'Paneer Tikka','ca90f9d59ffafdb3cb9e2c494485ff85.jpg','Grilled cottage cheese marinated in spicy yogurt.','veg','[]',250.00,5,8,'2026-06-08 23:35:48','2026-06-08 23:54:21',NULL,1,1,1,0,0,NULL),(15,1,1,'Dal Makhani','3681eb969a58eddeb084561f2f65fdc2.jpg','Creamy and rich black lentils cooked with butter and spices.','veg','[]',180.00,5,9,'2026-06-08 23:35:48','2026-06-08 23:55:55',NULL,1,1,1,0,0,NULL),(16,1,1,'Masala Dosa','cb3b48d1acb9102f6e2e5abf7b8b3aae.jpg','Crispy rice and lentil crepe filled with spiced mashed potatoes.','veg','[]',120.00,6,9,'2026-06-08 23:35:48','2026-06-08 23:55:19',NULL,1,1,1,0,0,NULL),(17,1,1,'Idli Sambar','78597f93e89c199279610089278415c3.jpg','Steamed rice cakes served with lentil soup and chutney.','veg','[]',90.00,6,9,'2026-06-08 23:35:48','2026-06-08 23:55:36',NULL,1,1,1,0,0,NULL),(18,1,1,'Medu Vada','284fe889e28a718957d302eb3c8b8626.jpg','Crispy lentil fritters with chutney and sambar.','veg','[]',80.00,6,8,'2026-06-08 23:35:48','2026-06-08 23:54:38',NULL,1,1,1,0,0,NULL),(19,1,1,'Uttapam','e10a41d518e340bec6b723e21f9130d3.jpg','Thick rice and lentil pancake topped with onions and tomatoes.','veg','[]',130.00,6,9,'2026-06-08 23:35:48','2026-06-08 23:39:05',NULL,1,1,1,0,0,NULL),(20,1,1,'Hyderabadi Chicken Biryani','e09153f13e89db277340ae23e0408290.jpg','Fragrant rice cooked with tender meat and aromatic spices.','non-veg','[]',300.00,6,10,'2026-06-08 23:35:48','2026-06-09 04:43:30',30,1,1,1,0,0,NULL),(21,1,1,'Weekly Special',NULL,'','veg',NULL,50.00,3,5,'2026-06-08 23:35:48','2026-06-08 23:35:48',NULL,1,1,1,0,0,NULL),(22,3,3,'Cofee','5864ec792412c83f089223e689f23a24.jpg',NULL,'drink','[]',30.00,7,12,'2026-06-10 01:14:05','2026-06-10 01:14:05',10,1,1,1,0,0,NULL),(23,3,3,'Water','5301c0c9b2fa5c31d0c6946f4fbf818b.jpg','','drink','[]',0.00,7,11,'2026-06-10 01:14:05','2026-06-10 01:14:05',5,1,1,1,0,0,NULL),(24,3,3,'Lahori Nihari','207ab28e7615905345eb68891e4259a9.jpg','Lahori Nihari Description','non-veg','[]',120.00,8,14,'2026-06-10 01:14:05','2026-06-10 01:14:05',NULL,1,1,1,0,0,NULL),(25,3,3,'Bashmoti Kacchi','c39902a651f729fefc9a5f3040ceae24.jpg','Bashmoti Kacchi with borhani','non-veg','[]',500.00,9,15,'2026-06-10 01:14:05','2026-06-10 03:08:29',30,1,1,1,0,0,NULL),(26,3,3,'Drinking Water','7a8f163a2b8fb34a283b3f1504aa36b9.webp','Mum Drinking Water','veg','[]',20.00,9,16,'2026-06-10 01:14:05','2026-06-10 01:14:05',NULL,1,1,1,0,0,NULL),(27,3,3,'Naan','c25d7ba3a0b4fa897ca309974b04fa7d.jpeg','Soft and fluffy bread baked in a tandoor.','veg','[]',35.00,8,17,'2026-06-10 01:14:05','2026-06-10 01:14:05',NULL,1,1,1,0,0,NULL),(28,3,3,'Tandoori Roti','f5f3d0bc8237af366c7dae19388314d5.webp','Traditional whole wheat bread cooked in a clay oven.','veg','[]',10.00,8,17,'2026-06-10 01:14:05','2026-06-10 01:14:05',NULL,1,1,1,0,0,NULL),(29,3,3,'Veg Manchow Soup','40e8db6b5c357f29da3a9679d801987a.jpg','Spicy vegetable soup with crispy fried noodles.','veg','[]',850.00,10,18,'2026-06-10 01:14:05','2026-06-10 01:14:05',NULL,1,1,1,0,0,NULL),(30,3,3,'Spring Rolls','f1e214b09cf13f4061879df8825cf31e.webp','Crispy rolls stuffed with a mix of vegetables and served with tangy dip.','veg','[]',750.00,10,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(31,3,3,'Chilli Paneer','903a048de5d1003ac8135dd44b8f83ff.jpg','Spicy cottage cheese cubes tossed in a tangy Indo-Chinese sauce.','veg','[]',550.00,10,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(32,3,3,'Vegetable Hakka Noodles','0a9265422c1664c67674f2f20855e4b1.jpg','Vegetable Hakka Noodles','veg','[]',450.00,10,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(33,3,3,'Chicken Manchurian','661968cf77f3ce9d2461164a343f3e29.jpg','Juicy chicken balls in a tangy Manchurian sauce.','veg','[]',680.00,10,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(34,3,3,'Butter Chicken','ba9f22a13e9bcf384f8e01ee7d1d4c53.jpg','Tender chicken cooked in a rich tomato and butter gravy.','non-veg','[]',320.00,11,19,'2026-06-10 01:14:06','2026-06-10 01:14:06',40,1,1,1,0,0,NULL),(35,3,3,'Paneer Tikka','ca90f9d59ffafdb3cb9e2c494485ff85.jpg','Grilled cottage cheese marinated in spicy yogurt.','veg','[]',250.00,11,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(36,3,3,'Dal Makhani','3681eb969a58eddeb084561f2f65fdc2.jpg','Creamy and rich black lentils cooked with butter and spices.','veg','[]',180.00,11,19,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(37,3,3,'Masala Dosa','cb3b48d1acb9102f6e2e5abf7b8b3aae.jpg','Crispy rice and lentil crepe filled with spiced mashed potatoes.','veg','[]',120.00,12,19,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(38,3,3,'Idli Sambar','78597f93e89c199279610089278415c3.jpg','Steamed rice cakes served with lentil soup and chutney.','veg','[]',90.00,12,19,'2026-06-10 01:14:06','2026-06-10 03:09:27',NULL,0,1,1,0,0,NULL),(39,3,3,'Medu Vada','284fe889e28a718957d302eb3c8b8626.jpg','Crispy lentil fritters with chutney and sambar.','veg','[]',80.00,12,18,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(40,3,3,'Uttapam','e10a41d518e340bec6b723e21f9130d3.jpg','Thick rice and lentil pancake topped with onions and tomatoes.','veg','[]',130.00,12,19,'2026-06-10 01:14:06','2026-06-10 01:14:06',NULL,1,1,1,0,0,NULL),(41,3,3,'Hyderabadi Chicken Biryani','e09153f13e89db277340ae23e0408290.jpg','Fragrant rice cooked with tender meat and aromatic spices.','non-veg','[]',300.00,12,20,'2026-06-10 01:14:06','2026-06-10 01:14:06',30,1,1,1,0,0,NULL),(42,3,3,'Weekly Special',NULL,'','veg',NULL,50.00,9,15,'2026-06-10 01:14:06','2026-06-10 03:09:03',NULL,0,1,1,0,0,NULL);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_table`
--

DROP TABLE IF EXISTS `menu_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_table` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `table_id` bigint unsigned NOT NULL,
  `menu_id` bigint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_table_table_id_menu_id_unique` (`table_id`,`menu_id`),
  KEY `menu_table_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menu_table_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_table_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_table`
--

LOCK TABLES `menu_table` WRITE;
/*!40000 ALTER TABLE `menu_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `menu_name` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menus_branch_id_foreign` (`branch_id`),
  CONSTRAINT `menus_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,1,'{\"en\":\"Drink\"}',0,'2026-06-06 02:06:03','2026-06-06 02:06:03'),(2,1,'{\"en\":\"Breakfast\"}',0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(3,1,'{\"en\":\"Dinner\"}',0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(4,1,'{\"en\":\"Chines Foods\"}',0,'2026-06-08 23:35:47','2026-06-08 23:35:47'),(5,1,'{\"en\":\"North Indian Delights\"}',0,'2026-06-08 23:35:48','2026-06-08 23:35:48'),(6,1,'{\"en\":\"South Indian Sensations\"}',0,'2026-06-08 23:35:48','2026-06-08 23:35:48'),(7,3,'{\"en\":\"Drink\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(8,3,'{\"en\":\"Breakfast\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(9,3,'{\"en\":\"Dinner\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(10,3,'{\"en\":\"Chines Foods\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(11,3,'{\"en\":\"North Indian Delights\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05'),(12,3,'{\"en\":\"South Indian Sensations\"}',0,'2026-06-10 01:14:05','2026-06-10 01:14:05');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2014_04_02_193005_create_translations_table',1),(5,'2024_01_01_create_printers_table',1),(6,'2024_03_13_000002_create_expense_categories_table',1),(7,'2024_07_01_060651_add_two_factor_columns_to_users_table',1),(8,'2024_07_01_060707_create_personal_access_tokens_table',1),(9,'2024_07_02_064204_create_menus_table',1),(10,'2024_07_12_070634_create_areas_table',1),(11,'2024_07_16_103816_create_orders_table',1),(12,'2024_07_21_083459_add_user_type_column',1),(13,'2024_07_24_131631_create_payments_table',1),(14,'2024_07_31_081306_add_email_otp_column',1),(15,'2024_08_02_061808_create_countries_table',1),(16,'2024_08_02_071637_create_restaurant_settings_table',1),(17,'2024_08_04_104258_create_razorpay_payments_table',1),(18,'2024_08_05_092258_create_stripe_payments_table',1),(19,'2024_08_05_110157_create_payment_gateway_credentials_table',1),(20,'2024_08_13_033139_create_global_settings_table',1),(21,'2024_08_13_073129_update_settings_add_envato_key',1),(22,'2024_08_13_073129_update_settings_add_support_key',1),(23,'2024_08_14_073129_update_settings_add_email',1),(24,'2024_08_14_073129_update_settings_add_last_verified_key',1),(25,'2024_09_13_081726_create_modules_table',1),(26,'2024_09_14_130619_create_permission_tables',1),(27,'2024_09_27_071339_create_reservations_table',1),(28,'2024_10_02_090924_create_email_settings_table',1),(29,'2024_10_03_073837_create_notification_settings_table',1),(30,'2024_10_11_100539_create_branches_table',1),(31,'2024_10_14_121135_create_onboarding_steps_table',1),(32,'2024_10_15_071238_add_restaurant_hash_column',1),(33,'2024_10_15_071238_storage',1),(34,'2024_10_15_100639_create_restaurant_payments_table',1),(35,'2024_10_27_101326_create_packages_table',1),(36,'2024_11_02_112920_create_language_settings_table',1),(37,'2024_11_02_120314_create_flags_table',1),(38,'2024_11_02_120314_email_settings_table',1),(39,'2024_11_08_071617_add_customer_login_required_column',1),(40,'2024_11_08_093032_create_superadmin_payment_gateways_table',1),(41,'2024_11_08_133506_add_stripe_column_for_license',1),(42,'2024_11_12_055119_create_delivery_executives_table',1),(43,'2024_11_12_055632_add_order_types_column',1),(44,'2024_11_12_060500_create_order_histories_table',1),(45,'2024_11_12_060500_global_license_type_table',1),(46,'2024_11_12_060500_global_purchase_on_table',1),(47,'2024_11_12_060500_global_setting_timezone_table',1),(48,'2024_11_17_052707_currency_position',1),(49,'2024_11_17_052707_move_qr_code',1),(50,'2024_11_19_113852_add_is_active_to_restaurants_table',1),(51,'2024_11_20_114816_add_staff_welcome_email_notification',1),(52,'2024_11_25_061322_create_pusher_settings_table',1),(53,'2024_11_26_090216_create_global_currencies_table',1),(54,'2024_12_03_085842_add_about_us_column',1),(55,'2024_12_03_104817_add_currency_id_packages',1),(56,'2024_12_04_080223_add_allow_customer_delivery_orders',1),(57,'2024_12_04_115601_add_preparation_time_column',1),(58,'2024_12_11_110000_create_tables_for_subscription_table',1),(59,'2024_12_11_131225_add_disable_landing_site_columns',1),(60,'2024_12_12_090840_create_waiter_requests_table',1),(61,'2024_12_13_090840_add_domain_global_setting',1),(62,'2024_12_16_080201_create_lifetime_subscriptions_for_paid_restaurants',1),(63,'2024_12_23_124452_add_payment_enabled_columns_to_payment_settings_table',1),(64,'2024_12_27_054246_add_table_reservation_default_status_to_restaurants_table',1),(65,'2024_12_30_074018_create_split_orders_table',1),(66,'2024_12_30_200942_create_restaurant_settings_table',1),(67,'2025_01_03_050139_add_social_media_links_to_reataurants_table',1),(68,'2025_01_03_093938_add_social_media_links_to_global_settings_table',1),(69,'2025_01_06_111550_create_receipt_settings_table',1),(70,'2025_01_09_073145_generate_qr_codes_for_existing_branches',1),(71,'2025_01_09_115652_update_receipt_settings_for_existing_restaurants',1),(72,'2025_01_10_064103_add_table_required_column_to_customer_settings_table',1),(73,'2025_01_10_100552_insert_to_file_storage_settings_default_values',1),(74,'2025_01_11_063817_add_default_currency_column',1),(75,'2025_01_15_000000_create_cart_header_settings_table',1),(76,'2025_01_15_000001_create_cart_header_images_table',1),(77,'2025_01_16_000000_add_is_header_disabled_to_cart_header_settings_table',1),(78,'2025_01_16_125322_add_is_enabled_to_menu_items_table',1),(79,'2025_01_16_131100_regenrate_qr_codes',1),(80,'2025_01_20_000000_add_restaurant_id_to_roles',1),(81,'2025_01_20_071544_add_branch_limit_to_packages_table',1),(82,'2025_01_20_091630_update_item_type',1),(83,'2025_01_20_125429_add_discount_columns_to_orders_table',1),(84,'2025_01_21_064139_add_show_logo_text_column',1),(85,'2025_01_21_064256_add_offline_payment',1),(86,'2025_01_21_132218_fix_user_roles',1),(87,'2025_01_22_114720_add_show_tax_to_receipt_setting',1),(88,'2025_01_23_065746_create_modifier_groups_table',1),(89,'2025_01_23_085333_create_restaurant_taxes_table',1),(90,'2025_01_23_090554_create_modifier_options_table',1),(91,'2025_01_23_094318_create_item_modifiers_table',1),(92,'2025_01_23_121154_create_order_item_modifier_options_table',1),(93,'2025_01_27_065822_add_balance_column_to_payment',1),(94,'2025_01_28_111039_add_allow_dine_in_orders_to_restaurant',1),(95,'2025_01_30_050755_add_yelp_icon_to_global_settings',1),(96,'2025_01_30_055744_add_yelp_link_to_restaurants',1),(97,'2025_01_30_100556_fix_package_price_length',1),(98,'2025_01_30_104043_add_meta_data_to_global_settings',1),(99,'2025_01_31_000001_create_predefined_amounts_table',1),(100,'2025_02_03_062109_add_is_cash_payment_enabled_to_payment',1),(101,'2025_02_04_140538_add_transaction_id_kot',1),(102,'2025_02_15_121956_add_hide_new_orders_option_to_restaurant',1),(103,'2025_02_17_052801_create_restaurant_charges_settings_table',1),(104,'2025_02_17_093729_add_favicon_to_restaurant',1),(105,'2025_02_19_091730_update_menu_name_to_json',1),(106,'2025_02_20_095321_add_waiter_request_options_to_restaurant',1),(107,'2025_02_21_051534_add_hash_to_global_settings_table',1),(108,'2025_02_21_102116_add_column_to_settings',1),(109,'2025_02_24_063827_add_payment_qr_to_receipt_settings',1),(110,'2025_02_24_111946_add_permissions_to_customers',1),(111,'2025_03_04_114535_add_is_enabled_to_restaurant_charges',1),(112,'2025_03_10_055100_add_tip_column_to_orders_table',1),(113,'2025_03_10_100727_add_is_pwa_intall_alert_show_column_in_restaurants_table',1),(114,'2025_03_17_090450_add_meta_title_to_global_settings',1),(115,'2025_03_18_044410_create_expenses_table',1),(116,'2025_03_19_092459_create_custom_menus_table',1),(117,'2025_03_19_103047_update_additional_modules',1),(118,'2025_03_24_084350_add_show_payments_column_to_receipt_settings_table',1),(119,'2025_04_01_050059_add_branch_id_to_expense_category',1),(120,'2025_04_01_051356_add_branch_id_to_expenses',1),(121,'2025_04_02_071911_update_kot_status_enum',1),(122,'2025_04_07_112351_add_payment_recived_status_to_orders_table',1),(123,'2025_04_08_063624_update_meta_keywords',1),(124,'2025_04_10_065753_add_flutterwave_payment_gateway_columns_and_tables',1),(125,'2025_04_15_084543_create_front_details_table',1),(126,'2025_04_22_065157_create_front_reviews_setting_table',1),(127,'2025_04_22_091055_create_branch_delivery_settings_table',1),(128,'2025_04_22_091146_create_customer_addresses_table',1),(129,'2025_04_22_091223_create_delivery_fee_tiers_table',1),(130,'2025_04_22_091258_add_delivery_columns_to_orders_table',1),(131,'2025_04_29_102014_add_landing_type_column_in_global_settings_table',1),(132,'2025_04_29_114538_add_front_data_in_front_details_table',1),(133,'2025_05_14_094039_update_printers_settings_columns_to_printers_table',1),(134,'2025_05_15_071027_create_kot_places_table',1),(135,'2025_05_23_124746_add_in_stock_column',1),(136,'2025_05_26_105151_relocate_map_api_key_to_superadmin_settings',1),(137,'2025_05_26_114443_modify_kot_places_table',1),(138,'2025_05_30_081624_add_show_item_on_customer_site_to_menu_items',1),(139,'2025_06_02_081928_add_session_driver_column_to_global_settings',1),(140,'2025_06_02_112147_add_columns_to_superadmin_payment_gateways_table',1),(141,'2025_06_02_112903_add_paypal_payment_column_to_payment_gateway_credentials',1),(142,'2025_06_02_113108_create_paypal_payments_table',1),(143,'2025_06_02_114326_add_paypal_payment_in_payment_method_to_payments',1),(144,'2025_06_03_095923_add_status_column_kot_item',1),(145,'2025_06_04_065130_add_columns_payfast_in_superadmin_payment_gateways_table',1),(146,'2025_06_05_063256_add_sort_order_columns_in_menu_and_items',1),(147,'2025_06_05_112055_create_kot_settings_table',1),(148,'2025_06_06_050159_add_payfast_payment_column_to_payment_gateway_credentials',1),(149,'2025_06_06_051204_create_payfast_payments_table',1),(150,'2025_06_10_093131_change_delete_cascade_for_orders',1),(151,'2025_06_11_061716_add_uuid_to_orders_table',1),(152,'2025_06_11_062354_add_columns_paystack_in_superadmin_payment_gateways_table',1),(153,'2025_06_13_112612_add_phone_to_users',1),(154,'2025_06_13_113200_add_column_paystack_payments_to_payment_gateway_credentials',1),(155,'2025_06_13_113240_create_paystack_payments_table',1),(156,'2025_06_16_104533_add_note_columns_to_kot_items_and_order_items',1),(157,'2025_06_18_112425_add_payment_gateways_to_restaurants_table',1),(158,'2025_06_19_070518_add_position_to_custom_menus_table',1),(159,'2025_06_20_060452_add_columns_to_branch_table',1),(160,'2025_06_20_092521_add_others_type_to_payments_table',1),(161,'2025_06_23_101041_create_kot_cancel_reasons_table',1),(162,'2025_06_23_120021_update_kot_place_id_in_menu_items',1),(163,'2025_06_24_092521_disable_printer',1),(164,'2025_06_24_092811_add_column_cancel_kot_reason_to_kots_table',1),(165,'2025_06_24_102830_update_enum_status_to_kots_table',1),(166,'2025_06_25_094311_add_column_cancellation_reason_to_orders_table',1),(167,'2025_06_26_060831_add_custom_delivery_options_to_restaurants_table',1),(168,'2025_06_27_084541_insert_sample_kot_cancel_reasons_data',1),(169,'2025_07_01_112529_create_print_jobs_table',1),(170,'2025_07_01_133114_add_placed_via_column_orders_table',1),(171,'2025_07_02_090709_create_order_types_table',1),(172,'2025_07_02_105440_add_translations_columns_for_modifier_group',1),(173,'2025_07_02_114040_add_unique_hash_to_branches_table',1),(174,'2025_07_03_123829_update_kot_place_id_for_cloned_menu_items',1),(175,'2025_07_04_064350_update_order_type_id_in_orders',1),(176,'2025_07_04_081809_add_tax_mode_to_restaurants_table',1),(177,'2025_07_04_131541_create_desktop_applications_table',1),(178,'2025_07_07_070122_add_pusher_broadcast_to_pusher_settings_table',1),(179,'2025_07_07_110131_create_menu_item_taxes_table',1),(180,'2025_07_14_082950_add_columns_to_restaurants_table',1),(181,'2025_07_14_124125_add_pick_up_date_range_in_restaurants_table',1),(182,'2025_07_17_122331_create_order_number_settings',1),(183,'2025_07_29_063129_modify_item_type_in-menus',1),(184,'2025_07_29_082605_add_show_halal_and_veg_option_to_restaurants',1),(185,'2025_07_30_125616_add_tax_mode_to_orders',1),(186,'2025_08_01_114055_add_reservation_column_to_restaurants_table',1),(187,'2025_08_04_131541_create_desktop_applications_update_table',1),(188,'2025_08_05_081541_modify_split_orders_table_add_bank_transfer',1),(189,'2025_08_06_065323_change_payment_method_to_string_in_payments_table',1),(190,'2025_08_07_033322_add_column_disable_slot_minutes_to_restaurants_table',1),(191,'2025_08_08_115502_add_variation_id_to_item_modifiers',1),(192,'2025_08_12_133228_change_package_description_length',1),(193,'2025_08_13_060315_rename_payfast_columns_in_superadmin_payment_gateways_table',1),(194,'2025_08_13_110934_add_default_expense_categories_to_existing_branches',1),(195,'2025_08_16_110310_add_slot_time_difference_to_reservations',1),(196,'2025_08_19_071639_fix_tax_percent_to_unlimited_decimal',1),(197,'2025_08_19_131541_create_desktop_applications_mac_update_table',1),(198,'2025_08_20_000001_add_quantity_to_split_order_items',1),(199,'2025_08_21_100452_add_html_content_print_job',1),(200,'2025_08_25_050939_add_hide_menu_item_image_columns_to_restaurants_table',1),(201,'2025_08_25_060934_add_xendit_payment_gateway_to_payment_gateway_credentials_table',1),(202,'2025_08_25_061405_add_xendit_to_global_settings_table',1),(203,'2025_08_25_061500_create_xendit_payments_table',1),(204,'2025_08_25_062000_add_xendit_webhook_verification_tokens',1),(205,'2025_08_29_091315_add_phone_code_to_customers_table',1),(206,'2025_09_02_085025_add_xendit_payment_column_to_superadmin_payment_gateways_table',1),(207,'2025_09_02_113846_add_xendit_payments_column_to_packages_table',1),(208,'2025_09_02_130000_create_otps_table',1),(209,'2025_09_11_094443_remove_phone_unique',1),(210,'2025_09_15_100452_remove_extra_content_print_job',1),(211,'2025_09_17_094034_create_cart_session_tables',1),(212,'2025_09_18_051324_add_limit_columns_to_packages_table',1),(213,'2025_09_18_083624_add_table_lock_columns_and_settings',1),(214,'2025_09_23_062535_add_cancel_functionality_to_kot_items_table',1),(215,'2025_09_25_063220_add_xendit_webhook_token_to_superadmin_payment_gateways',1),(216,'2025_09_26_115847_add_token_number_to_orders_table',1),(217,'2025_09_26_115854_add_enable_token_number_to_order_types_table',1),(218,'2025_09_29_095519_create_delivery_platforms_table',1),(219,'2025_10_01_064424_create_menu_item_prices_table',1),(220,'2025_10_07_070000_add_reference_id_to_payment_tables',1),(221,'2025_10_07_094006_add_token_number_to_kots_table',1),(222,'2025_10_07_094018_remove_token_number_from_orders_table',1),(223,'2025_10_08_095954_add_columns_paddle_payment_keys_to_superadmin_payment_gateways',1),(224,'2025_10_08_102000_add_paddle_client_token_columns_to_superadmin_payment_gateways',1),(225,'2025_10_09_041734_add_enable_paddle_to_global_settings_table',1),(226,'2025_10_09_065853_remove_payload_from_print_jobs',1),(227,'2025_10_09_084200_add_package_id_to_restaurant_payments_table',1),(228,'2025_10_09_091500_add_paddle_price_ids_to_packages_table',1),(229,'2025_10_10_100000_add_paddle_webhook_secret_to_superadmin_payment_gateways',1),(230,'2025_10_10_122321_add_privacy_policy_link_to_global_settings_table',1),(231,'2025_10_14_000001_create_modifier_option_prices_table',1),(232,'2025_10_14_071228_add_consent_fields_to_users_table',1),(233,'2025_10_14_105354_add_order_item_id_to_kot_items_table',1),(234,'2025_10_15_045419_sms_count_packages',1),(235,'2025_10_17_074528_add_delivery_app_id_orders_table',1),(236,'2025_10_27_065853_add_from_printer_type',1),(237,'2025_10_28_065738_add_discount_permission_to_existing_roles',1),(238,'2025_10_28_081340_add_multipos_limit_to_packages_table',1),(239,'2025_10_30_055800_add_qr_order_location_columns_to_restaurants_table',1),(240,'2025_11_03_065853_add_from_printer_enum',1),(241,'2025_11_07_065319_add_disable_order_type_popup_to_restaurants_table',1),(242,'2025_11_10_000000_add_show_customer_phone_to_receipt_settings_table',1),(243,'2025_11_10_000001_add_show_payment_status_to_receipt_settings_table',1),(244,'2025_11_10_100652_add_added_by_to_orders_table',1),(245,'2025_11_12_081126_create_table_epay_payments_table',1),(246,'2025_11_13_060849_add_cancelled_by_to_orders_table',1),(247,'2025_11_18_083606_add_modifier_option_prices_column_to_table',1),(248,'2025_11_21_092424_add_time_format_to_restaurants_table',1),(249,'2025_11_21_095021_add_date_format_to_restaurants_table',1),(250,'2025_11_21_164300_add_time_format_and_date_format_to_global_settings_table',1),(251,'2025_11_27_082212_create_push_notifications_table',1),(252,'2025_11_27_084813_allow_duplicate_customer_email_per_restaurant',1),(253,'2025_12_01_061505_add_columns_to_restaurants_table',1),(254,'2025_12_03_055406_change_column_into_orders_table',1),(255,'2025_12_03_063129_add_cancel_time_to_orders_table',1),(256,'2025_12_03_090241_add_phone_code_to_delivery_executives_table',1),(257,'2025_12_03_101309_add_disable_from_customer_site_to_order_types_table',1),(258,'2025_12_05_120000_update_customer_email_unique_per_restaurant',1),(259,'2025_12_10_040806_add_order_confirmed_notification_to_existing_restaurants',1),(260,'2025_12_12_063203_add_enable_mollie_to_global_settings_table',1),(261,'2025_12_12_063224_add_mollie_payment_gateway_to_payment_gateway_credentials_table',1),(262,'2025_12_12_071258_create_mollie_payments_table',1),(263,'2025_12_15_022410_add_show_support_ticket_to_global_settings_table',1),(264,'2025_12_16_170214_add_indexes_for_pos_queries',1),(265,'2025_12_18_072141_add_mollie_webhook_secret_to_payment_gateway_credentials_table',1),(266,'2025_12_19_042834_add_loyalty_columns_to_orders_table',1),(267,'2025_12_20_000000_add_cancelled_by_to_kot_items_table',1),(268,'2025_12_21_000001_create_refund_reasons_table',1),(269,'2025_12_24_075701_create_assign_waiter_to_tables_table',1),(270,'2025_12_31_063109_add_cascade_delete_to_split_orders_order_id',1),(271,'2025_12_31_081636_create_branch_operational_shifts_table',1),(272,'2025_12_31_093806_add_restaurant_id_and_update_day_of_week_to_branch_operational_shifts_table',1),(273,'2025_12_31_100538_change_day_of_week_from_enum_to_string_in_branch_operational_shifts_table',1),(274,'2026_01_02_052013_change_day_of_week_to_json_in_branch_operational_shifts_table',1),(275,'2026_01_07_120000_add_mollie_columns_to_superadmin_payment_gateways_table',1),(276,'2026_01_16_112054_create_menu_table_pivot_table',1),(277,'2026_01_20_000001_add_schedule_fields_to_notification_settings_table',1),(278,'2026_01_21_000001_update_kot_settings_default_status_columns',1),(279,'2026_01_21_120000_add_superadmin_modules_and_permissions_for_existing_installs',1),(280,'2026_01_22_000000_add_ai_monthly_request_limit_to_packages_table',1),(281,'2026_01_22_061911_add_menu_pdf_sent_notification_to_existing_restaurants',1),(282,'2026_01_22_102923_add_include_charges_in_tax_base_to_settings_table',1),(283,'2026_01_27_110718_add_columns_to_superadmin_payment_gateways_table_for_tap_table',1),(284,'2026_01_27_110905_create_tap_payment_gateway_tables',1),(285,'2026_02_03_063404_add_is_due_and_due_amount_received_to_payments_table',1),(286,'2026_02_03_105222_sync_cash_and_bank_transfer_to_offline_payment_methods',1),(287,'2026_02_04_000001_add_unique_code_to_delivery_executives_table',1),(288,'2026_02_05_072241_update_menu_table_is_active_column',1),(289,'2026_02_10_091859_add_payer_details_to_split_orders_table',1),(290,'2026_02_11_120000_add_order_note_to_orders_table',1),(291,'2026_02_16_095800_add_and_update_columns_to_restaurants_table',1),(292,'2026_02_16_215609_assign_export_menu_item_permission_to_existing_roles',1),(293,'2026_02_19_000001_add_show_order_number_on_board_to_order_types_table',1),(294,'2026_02_19_164315_add_waiter_response_to_orders_table',1),(295,'2026_02_20_000000_add_cr_vat_to_branches_table',1),(296,'2026_02_23_000001_add_branch_id_to_receipt_settings_table',1),(297,'2026_02_23_100000_add_branch_id_to_taxes_table',1),(298,'2026_02_26_000001_add_open_close_settings_to_restaurants_table',1),(299,'2026_02_27_000002_add_manual_open_close_type_to_restaurants_table',1),(300,'2026_02_27_000004_replace_restaurant_open_close_permissions',1),(301,'2026_03_05_000000_rename_desktop_applications_to_desktop_mobile_application',1),(302,'2026_03_09_000001_add_email_to_delivery_executives_table',1),(303,'2026_03_09_110642_add_refund_payments_permission_table',1),(304,'2026_03_10_000000_add_google_business_link_to_restaurants',1),(305,'2026_03_10_000001_add_google_business_link_to_global_settings',1),(306,'2026_03_12_120000_create_order_cash_collections_table',1),(307,'2026_03_12_160000_create_delivery_cash_settlements_tables',1),(308,'2026_03_16_000002_create_order_notification_settings_table',1),(309,'2026_03_19_000001_backfill_delivery_executive_online_status',1),(310,'2026_04_20_120000_add_discount_apply_on_to_orders_table',1),(311,'2026_04_23_000001_add_image_to_item_categories_table',1),(312,'2026_04_23_100000_add_meta_image_to_global_settings_table',1),(313,'2026_04_24_000000_add_menu_item_default_image_settings_to_restaurants_table',1),(314,'2026_04_28_100000_create_expenses_recurring_table',1),(315,'2026_04_28_100001_add_expenses_recurring_id_to_expenses_table',1),(316,'2026_04_29_120000_add_receipt_languages_to_receipt_settings_table',1),(317,'2026_04_29_141500_add_map_provider_to_global_settings_table',1),(318,'2026_05_07_120000_move_customer_delivery_address_to_customer_addresses_table',1),(319,'2026_05_11_120000_migrate_legacy_order_status_served_to_completed',1),(320,'2026_05_12_000001_add_eu_fic_allergen_settings_to_restaurants_table',1),(321,'2026_05_12_120000_migrate_read_legacy_order_status_served_to_completed',1),(322,'2026_05_13_000001_migrate_eu_allergen_settings_from_restaurants_table',1),(323,'2026_05_13_120000_add_auto_mark_order_completed_on_paid_to_restaurants_table',1),(324,'2026_05_13_150000_add_dietary_labels_to_menu_items_table',1),(325,'2026_05_14_000001_add_eu_allergen_keys_to_menu_items_table',1),(326,'2026_05_15_120000_rename_delivery_executive_status_available_to_active',1),(327,'2026_05_19_140000_add_waiter_pos_app_urls_to_desktop_mobile_application',1),(328,'2026_05_20_100000_add_route_sequence_and_delivery_proof_to_orders_table',1),(329,'2026_05_21_100000_add_app_update_superadmin_permission',1),(330,'2026_05_21_110000_add_custom_modules_superadmin_permission',1),(331,'2026_05_21_120000_add_area_id_to_reservations_table',1),(332,'2026_05_22_100000_add_image_to_areas_table',1),(333,'2026_05_22_120000_add_dark_logo_to_restaurants_table',1),(334,'2026_05_22_120001_add_dark_logo_to_global_settings_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(4,'App\\Models\\User',3),(4,'App\\Models\\User',4),(4,'App\\Models\\User',5),(4,'App\\Models\\User',6),(4,'App\\Models\\User',7),(2,'App\\Models\\User',8),(4,'App\\Models\\User',9),(3,'App\\Models\\User',10),(4,'App\\Models\\User',11),(5,'App\\Models\\User',12);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifier_group_translations`
--

DROP TABLE IF EXISTS `modifier_group_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modifier_group_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `modifier_group_id` bigint unsigned NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `modifier_group_translations_modifier_group_id_locale_unique` (`modifier_group_id`,`locale`),
  KEY `modifier_group_translations_locale_index` (`locale`),
  CONSTRAINT `modifier_group_translations_modifier_group_id_foreign` FOREIGN KEY (`modifier_group_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifier_group_translations`
--

LOCK TABLES `modifier_group_translations` WRITE;
/*!40000 ALTER TABLE `modifier_group_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifier_group_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifier_groups`
--

DROP TABLE IF EXISTS `modifier_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modifier_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `branch_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modifier_groups_branch_id_foreign` (`branch_id`),
  CONSTRAINT `modifier_groups_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifier_groups`
--

LOCK TABLES `modifier_groups` WRITE;
/*!40000 ALTER TABLE `modifier_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifier_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifier_option_prices`
--

DROP TABLE IF EXISTS `modifier_option_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modifier_option_prices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `modifier_group_id` bigint unsigned NOT NULL,
  `modifier_option_id` bigint unsigned DEFAULT NULL,
  `order_type_id` bigint unsigned DEFAULT NULL,
  `delivery_app_id` bigint unsigned DEFAULT NULL,
  `calculated_price` decimal(16,2) NOT NULL,
  `override_price` decimal(16,2) DEFAULT NULL,
  `final_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modifier_option_prices_modifier_group_id_foreign` (`modifier_group_id`),
  KEY `modifier_option_prices_modifier_option_id_foreign` (`modifier_option_id`),
  KEY `modifier_option_prices_order_type_id_foreign` (`order_type_id`),
  KEY `modifier_option_prices_delivery_app_id_foreign` (`delivery_app_id`),
  CONSTRAINT `modifier_option_prices_delivery_app_id_foreign` FOREIGN KEY (`delivery_app_id`) REFERENCES `delivery_platforms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `modifier_option_prices_modifier_group_id_foreign` FOREIGN KEY (`modifier_group_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `modifier_option_prices_modifier_option_id_foreign` FOREIGN KEY (`modifier_option_id`) REFERENCES `modifier_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `modifier_option_prices_order_type_id_foreign` FOREIGN KEY (`order_type_id`) REFERENCES `order_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifier_option_prices`
--

LOCK TABLES `modifier_option_prices` WRITE;
/*!40000 ALTER TABLE `modifier_option_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifier_option_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifier_options`
--

DROP TABLE IF EXISTS `modifier_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modifier_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `modifier_group_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(16,2) NOT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_preselected` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modifier_options_modifier_group_id_foreign` (`modifier_group_id`),
  CONSTRAINT `modifier_options_modifier_group_id_foreign` FOREIGN KEY (`modifier_group_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifier_options`
--

LOCK TABLES `modifier_options` WRITE;
/*!40000 ALTER TABLE `modifier_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifier_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_superadmin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'App Update',1,'2026-06-05 23:44:05','2026-06-05 23:44:05'),(2,'Restaurants',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(3,'Superadmin Payment',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(4,'Packages',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(5,'Billing',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(6,'Offline Request',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(7,'SuperAdmin',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(8,'Landing Site',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(9,'Superadmin Settings',1,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(10,'Menu',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(11,'Menu Item',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(12,'Item Category',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(13,'Area',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(14,'Table',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(15,'Reservation',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(16,'KOT',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(17,'Order',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(18,'Customer',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(19,'Staff',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(20,'Report',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(21,'Delivery Executive',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(22,'Waiter Request',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(23,'Expense',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(24,'Payment',0,'2026-06-05 23:44:06','2026-06-05 23:44:06'),(25,'Settings',0,'2026-06-05 23:44:06','2026-06-05 23:44:06');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mollie_payments`
--

DROP TABLE IF EXISTS `mollie_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mollie_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `mollie_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mollie_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `mollie_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mollie_payments`
--

LOCK TABLES `mollie_payments` WRITE;
/*!40000 ALTER TABLE `mollie_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `mollie_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_email` tinyint(1) NOT NULL DEFAULT '1',
  `send_time` time DEFAULT NULL,
  `last_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_settings_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `notification_settings_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
INSERT INTO `notification_settings` VALUES (1,1,'order_received',1,NULL,NULL,NULL,NULL),(2,1,'reservation_confirmed',1,NULL,NULL,NULL,NULL),(3,1,'new_reservation',1,NULL,NULL,NULL,NULL),(4,1,'order_bill_sent',1,NULL,NULL,NULL,NULL),(5,1,'staff_welcome',1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_restaurant_id_foreign` (`restaurant_id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`),
  CONSTRAINT `notifications_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_payment_methods`
--

DROP TABLE IF EXISTS `offline_payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offline_payment_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offline_payment_methods_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `offline_payment_methods_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_payment_methods`
--

LOCK TABLES `offline_payment_methods` WRITE;
/*!40000 ALTER TABLE `offline_payment_methods` DISABLE KEYS */;
INSERT INTO `offline_payment_methods` VALUES (1,1,'cash',NULL,'inactive','2026-06-05 23:44:08','2026-06-05 23:44:08'),(2,1,'bank_transfer',NULL,'inactive','2026-06-05 23:44:08','2026-06-05 23:44:08'),(3,1,'bKash','','active','2026-06-09 04:25:16','2026-06-09 04:25:16'),(4,1,'Nagad','','active','2026-06-09 04:25:34','2026-06-09 04:25:34'),(5,NULL,'bKash','','active','2026-06-10 03:16:44','2026-06-10 03:16:44');
/*!40000 ALTER TABLE `offline_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_plan_changes`
--

DROP TABLE IF EXISTS `offline_plan_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offline_plan_changes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `package_id` bigint unsigned NOT NULL,
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `invoice_id` bigint unsigned DEFAULT NULL,
  `offline_method_id` bigint unsigned DEFAULT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('verified','pending','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offline_plan_changes_restaurant_id_foreign` (`restaurant_id`),
  KEY `offline_plan_changes_package_id_foreign` (`package_id`),
  KEY `offline_plan_changes_invoice_id_foreign` (`invoice_id`),
  KEY `offline_plan_changes_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `offline_plan_changes_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `global_invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_plan_changes`
--

LOCK TABLES `offline_plan_changes` WRITE;
/*!40000 ALTER TABLE `offline_plan_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_plan_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onboarding_steps`
--

DROP TABLE IF EXISTS `onboarding_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `onboarding_steps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `add_area_completed` tinyint(1) NOT NULL DEFAULT '0',
  `add_table_completed` tinyint(1) NOT NULL DEFAULT '0',
  `add_menu_completed` tinyint(1) NOT NULL DEFAULT '0',
  `add_menu_items_completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onboarding_steps_branch_id_foreign` (`branch_id`),
  CONSTRAINT `onboarding_steps_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onboarding_steps`
--

LOCK TABLES `onboarding_steps` WRITE;
/*!40000 ALTER TABLE `onboarding_steps` DISABLE KEYS */;
INSERT INTO `onboarding_steps` VALUES (1,1,1,1,1,1,'2026-06-05 23:44:08','2026-06-06 02:09:57'),(2,1,0,0,0,0,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,2,0,0,0,0,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,2,0,0,0,0,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(5,3,1,1,1,1,'2026-06-10 00:34:49','2026-06-10 01:14:06');
/*!40000 ALTER TABLE `onboarding_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_cash_collections`
--

DROP TABLE IF EXISTS `order_cash_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_cash_collections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `delivery_executive_id` bigint unsigned DEFAULT NULL,
  `expected_amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `collected_amount` decimal(16,2) DEFAULT NULL,
  `status` enum('pending_collection','collected','partial','not_collected','submitted','settled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_collection',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `recorded_at` timestamp NULL DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `settled_at` timestamp NULL DEFAULT NULL,
  `settled_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_cash_collections_order_id_foreign` (`order_id`),
  KEY `occ_exec_status_idx` (`delivery_executive_id`,`status`),
  KEY `occ_branch_status_idx` (`branch_id`,`status`),
  CONSTRAINT `order_cash_collections_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_cash_collections_delivery_executive_id_foreign` FOREIGN KEY (`delivery_executive_id`) REFERENCES `delivery_executives` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_cash_collections_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_cash_collections`
--

LOCK TABLES `order_cash_collections` WRITE;
/*!40000 ALTER TABLE `order_cash_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_cash_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_charges`
--

DROP TABLE IF EXISTS `order_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_charges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `charge_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_charges_order_id_foreign` (`order_id`),
  KEY `order_charges_charge_id_foreign` (`charge_id`),
  CONSTRAINT `order_charges_charge_id_foreign` FOREIGN KEY (`charge_id`) REFERENCES `restaurant_charges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_charges_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_charges`
--

LOCK TABLES `order_charges` WRITE;
/*!40000 ALTER TABLE `order_charges` DISABLE KEYS */;
INSERT INTO `order_charges` VALUES (1,10,1),(2,11,1),(3,12,1),(4,13,1),(5,14,1),(6,15,1),(7,16,1),(8,17,1),(9,18,1),(10,19,1),(11,20,1),(12,21,1),(13,22,1),(14,23,1),(15,24,1),(16,25,1),(17,26,1),(18,27,1),(19,28,1),(20,29,1),(21,30,1),(22,31,1),(23,32,1),(25,34,1),(26,35,1),(27,36,1),(28,37,1),(29,38,1),(30,39,1),(31,40,1),(32,41,1),(33,42,1),(34,43,1),(35,44,1),(36,45,1),(37,46,1),(38,47,1),(42,49,1),(43,50,1),(45,52,1),(46,53,1),(47,54,1),(51,55,1),(52,58,1),(54,60,1),(55,61,1),(56,62,1),(57,63,1),(58,57,1),(59,64,1),(60,65,1),(61,66,1),(62,67,1),(63,68,1),(64,69,1),(65,70,1),(67,71,1),(68,59,1),(69,48,1),(70,56,1),(71,72,1),(74,73,1),(77,75,1),(78,76,1),(79,77,1),(80,78,1),(81,79,1),(82,80,1),(86,83,1),(87,84,1),(89,85,1),(90,86,1),(91,87,1),(92,88,1),(95,89,1),(96,90,1),(97,91,1),(98,92,1),(99,93,1),(100,94,1),(101,95,1),(103,96,1),(105,97,1),(107,98,1),(109,99,1),(111,100,1);
/*!40000 ALTER TABLE `order_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_histories`
--

DROP TABLE IF EXISTS `order_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_histories_order_id_foreign` (`order_id`),
  CONSTRAINT `order_histories_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_histories`
--

LOCK TABLES `order_histories` WRITE;
/*!40000 ALTER TABLE `order_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item_modifier_options`
--

DROP TABLE IF EXISTS `order_item_modifier_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item_modifier_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint unsigned NOT NULL,
  `modifier_option_id` bigint unsigned DEFAULT NULL,
  `modifier_option_name` text COLLATE utf8mb4_unicode_ci,
  `modifier_option_price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_item_modifier_options_order_item_id_foreign` (`order_item_id`),
  KEY `order_item_modifier_options_modifier_option_id_foreign` (`modifier_option_id`),
  CONSTRAINT `order_item_modifier_options_modifier_option_id_foreign` FOREIGN KEY (`modifier_option_id`) REFERENCES `modifier_options` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `order_item_modifier_options_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_modifier_options`
--

LOCK TABLES `order_item_modifier_options` WRITE;
/*!40000 ALTER TABLE `order_item_modifier_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_modifier_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu_item_id` bigint unsigned NOT NULL,
  `menu_item_variation_id` bigint unsigned DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_free_item_from_stamp` tinyint(1) NOT NULL DEFAULT '0',
  `stamp_rule_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `tax_percentage` decimal(8,4) DEFAULT NULL,
  `tax_breakup` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_menu_item_id_foreign` (`menu_item_id`),
  KEY `order_items_menu_item_variation_id_foreign` (`menu_item_variation_id`),
  KEY `order_items_branch_id_foreign` (`branch_id`),
  KEY `idx_order_items_order_menu_variation` (`order_id`,`menu_item_id`,`menu_item_variation_id`),
  KEY `idx_order_items_order_id` (`order_id`),
  CONSTRAINT `order_items_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_menu_item_variation_id_foreign` FOREIGN KEY (`menu_item_variation_id`) REFERENCES `menu_item_variations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,1,NULL,1,NULL,NULL,0,NULL,1,30.00,30.00,0.00,0.0000,NULL,'2026-06-06 02:28:12','2026-06-06 02:28:12'),(2,1,2,NULL,1,NULL,NULL,0,NULL,2,30.00,60.00,0.00,0.0000,NULL,'2026-06-06 02:28:49','2026-06-06 02:28:49'),(3,1,3,NULL,1,NULL,NULL,0,NULL,3,30.00,90.00,0.00,0.0000,NULL,'2026-06-06 02:29:20','2026-06-06 02:29:20'),(4,1,4,NULL,1,NULL,NULL,0,NULL,4,30.00,120.00,0.00,0.0000,NULL,'2026-06-06 02:30:35','2026-06-06 02:30:35'),(5,1,5,NULL,1,NULL,NULL,0,NULL,5,30.00,150.00,0.00,0.0000,NULL,'2026-06-06 02:30:59','2026-06-06 02:30:59'),(6,1,6,NULL,1,NULL,NULL,0,NULL,6,30.00,180.00,0.00,0.0000,NULL,'2026-06-06 02:31:17','2026-06-06 02:31:17'),(7,1,7,NULL,1,NULL,NULL,0,NULL,7,30.00,210.00,0.00,0.0000,NULL,'2026-06-06 02:31:45','2026-06-06 02:31:45'),(8,1,8,NULL,1,NULL,NULL,0,NULL,8,30.00,240.00,0.00,0.0000,NULL,'2026-06-06 02:32:04','2026-06-06 02:32:04'),(9,1,9,NULL,1,NULL,NULL,0,NULL,9,30.00,270.00,0.00,0.0000,NULL,'2026-06-06 02:32:53','2026-06-06 02:32:53'),(10,1,10,NULL,1,NULL,NULL,0,NULL,1,30.00,30.00,0.00,0.0000,NULL,'2026-06-06 05:26:25','2026-06-06 05:26:25'),(11,1,11,NULL,2,1,NULL,0,NULL,3,15.00,45.00,0.00,0.0000,NULL,'2026-06-07 02:54:30','2026-06-07 02:54:30'),(12,1,11,NULL,2,3,NULL,0,NULL,4,40.00,160.00,0.00,0.0000,NULL,'2026-06-07 02:54:30','2026-06-07 02:54:30'),(13,1,11,NULL,2,2,NULL,0,NULL,5,25.00,125.00,0.00,0.0000,NULL,'2026-06-07 02:54:30','2026-06-07 02:54:30'),(14,1,12,NULL,2,3,NULL,0,NULL,1,40.00,40.00,0.00,0.0000,NULL,'2026-06-07 02:55:31','2026-06-07 02:55:31'),(15,1,12,NULL,1,NULL,NULL,0,NULL,2,30.00,60.00,0.00,0.0000,NULL,'2026-06-07 02:55:31','2026-06-07 02:55:31'),(16,1,12,NULL,2,1,NULL,0,NULL,1,15.00,15.00,0.00,0.0000,NULL,'2026-06-07 02:55:31','2026-06-07 02:55:31'),(17,1,13,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 00:03:38','2026-06-09 00:03:38'),(18,1,14,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:03:42','2026-06-09 01:03:42'),(19,1,15,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:06:46','2026-06-09 01:06:46'),(20,1,16,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 01:08:48','2026-06-09 01:08:48'),(21,1,17,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:11:08','2026-06-09 01:11:08'),(22,1,18,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:12:54','2026-06-09 01:12:54'),(23,1,19,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:16:23','2026-06-09 01:16:23'),(24,1,20,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:18:34','2026-06-09 01:18:34'),(25,1,21,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:20:40','2026-06-09 01:20:40'),(26,1,22,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 01:36:46','2026-06-09 01:36:46'),(27,1,22,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 01:36:46','2026-06-09 01:36:46'),(28,1,22,NULL,5,NULL,NULL,0,NULL,1,20.00,20.00,0.00,0.0000,NULL,'2026-06-09 01:36:46','2026-06-09 01:36:46'),(29,1,22,NULL,6,NULL,NULL,0,NULL,1,35.00,35.00,0.00,0.0000,NULL,'2026-06-09 01:36:46','2026-06-09 01:36:46'),(30,1,23,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 02:40:32','2026-06-09 02:40:32'),(31,1,24,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 02:59:02','2026-06-09 02:59:02'),(32,1,25,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:06:55','2026-06-09 03:06:55'),(33,1,26,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:10:12','2026-06-09 03:10:12'),(34,1,27,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:11:14','2026-06-09 03:11:14'),(35,1,27,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 03:11:14','2026-06-09 03:11:14'),(36,1,28,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:12:41','2026-06-09 03:12:41'),(37,1,29,NULL,4,NULL,NULL,0,NULL,4,500.00,2000.00,0.00,0.0000,NULL,'2026-06-09 03:17:09','2026-06-09 03:17:09'),(38,1,30,NULL,4,NULL,NULL,0,NULL,4,500.00,2000.00,0.00,0.0000,NULL,'2026-06-09 03:18:49','2026-06-09 03:18:49'),(39,1,31,NULL,4,NULL,NULL,0,NULL,5,500.00,2500.00,0.00,0.0000,NULL,'2026-06-09 03:22:07','2026-06-09 03:22:07'),(40,1,32,NULL,4,NULL,NULL,0,NULL,4,500.00,2000.00,0.00,0.0000,NULL,'2026-06-09 03:23:45','2026-06-09 03:23:45'),(54,1,34,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 03:33:00','2026-06-09 03:33:00'),(55,1,34,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:33:00','2026-06-09 03:33:00'),(56,1,34,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-09 03:33:00','2026-06-09 03:33:00'),(57,1,34,NULL,19,NULL,NULL,0,NULL,1,130.00,130.00,0.00,0.0000,NULL,'2026-06-09 03:33:00','2026-06-09 03:33:00'),(58,1,35,NULL,1,NULL,NULL,0,NULL,1,30.00,30.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(59,1,35,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(60,1,35,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(61,1,35,NULL,6,NULL,NULL,0,NULL,1,35.00,35.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(62,1,35,NULL,7,NULL,NULL,0,NULL,1,10.00,10.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(63,1,35,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(64,1,35,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(65,1,35,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(66,1,35,NULL,16,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(67,1,35,NULL,17,NULL,NULL,0,NULL,1,90.00,90.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(68,1,35,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(69,1,35,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 03:36:41','2026-06-09 03:36:41'),(70,1,36,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 03:55:55','2026-06-09 03:55:55'),(71,1,37,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 03:59:56','2026-06-09 03:59:56'),(72,1,38,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 04:01:02','2026-06-09 04:01:02'),(73,1,39,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:01:28','2026-06-09 04:01:28'),(74,1,40,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:03:09','2026-06-09 04:03:09'),(75,1,40,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-09 04:03:09','2026-06-09 04:03:09'),(76,1,41,NULL,15,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-09 04:03:20','2026-06-09 04:03:20'),(77,1,41,NULL,16,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 04:03:20','2026-06-09 04:03:20'),(78,1,42,NULL,7,NULL,NULL,0,NULL,1,10.00,10.00,0.00,0.0000,NULL,'2026-06-09 04:03:33','2026-06-09 04:03:33'),(79,1,43,NULL,2,1,NULL,0,NULL,1,15.00,15.00,0.00,0.0000,NULL,'2026-06-09 04:03:54','2026-06-09 04:03:54'),(80,1,43,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 04:03:54','2026-06-09 04:03:54'),(81,1,44,NULL,15,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-09 04:04:26','2026-06-09 04:04:26'),(82,1,45,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:05:54','2026-06-09 04:05:54'),(83,1,46,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 04:08:09','2026-06-09 04:08:09'),(84,1,49,NULL,5,NULL,NULL,0,NULL,1,20.00,20.00,0.00,0.0000,NULL,'2026-06-09 04:17:49','2026-06-09 04:17:49'),(85,1,50,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 04:22:21','2026-06-09 04:22:21'),(86,1,50,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:22:21','2026-06-09 04:22:21'),(87,1,50,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 04:22:21','2026-06-09 04:22:21'),(88,1,50,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 04:22:21','2026-06-09 04:22:21'),(93,1,52,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 04:25:57','2026-06-09 04:25:57'),(94,1,52,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:25:57','2026-06-09 04:25:57'),(95,1,52,NULL,11,NULL,NULL,0,NULL,1,450.00,450.00,0.00,0.0000,NULL,'2026-06-09 04:25:57','2026-06-09 04:25:57'),(96,1,52,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 04:25:57','2026-06-09 04:25:57'),(97,1,53,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 04:30:40','2026-06-09 04:30:40'),(98,1,53,NULL,11,NULL,NULL,0,NULL,1,450.00,450.00,0.00,0.0000,NULL,'2026-06-09 04:30:40','2026-06-09 04:30:40'),(99,1,53,NULL,15,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-09 04:30:40','2026-06-09 04:30:40'),(100,1,53,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 04:30:40','2026-06-09 04:30:40'),(101,1,54,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 04:37:59','2026-06-09 04:37:59'),(102,1,55,NULL,3,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 04:40:59','2026-06-09 04:40:59'),(103,1,58,NULL,17,NULL,NULL,0,NULL,1,90.00,90.00,0.00,0.0000,NULL,'2026-06-09 04:42:13','2026-06-09 04:42:13'),(104,1,60,NULL,5,NULL,NULL,0,NULL,1,20.00,20.00,0.00,0.0000,NULL,'2026-06-09 04:49:30','2026-06-09 04:49:30'),(105,1,60,NULL,2,3,NULL,0,NULL,1,40.00,40.00,0.00,0.0000,NULL,'2026-06-09 04:49:30','2026-06-09 04:49:30'),(106,1,61,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 04:51:56','2026-06-09 04:51:56'),(107,1,62,NULL,5,NULL,NULL,0,NULL,2,20.00,40.00,0.00,0.0000,NULL,'2026-06-09 04:53:07','2026-06-09 04:53:07'),(108,1,62,NULL,2,3,NULL,0,NULL,1,40.00,40.00,0.00,0.0000,NULL,'2026-06-09 04:53:07','2026-06-09 04:53:07'),(109,1,63,NULL,6,NULL,NULL,0,NULL,1,35.00,35.00,0.00,0.0000,NULL,'2026-06-09 04:54:33','2026-06-09 04:54:33'),(110,1,63,NULL,7,NULL,NULL,0,NULL,1,10.00,10.00,0.00,0.0000,NULL,'2026-06-09 04:54:33','2026-06-09 04:54:33'),(111,1,57,NULL,12,NULL,NULL,0,NULL,1,680.00,680.00,0.00,0.0000,NULL,'2026-06-09 05:05:00','2026-06-09 05:05:00'),(112,1,64,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 05:11:52','2026-06-09 05:11:52'),(113,1,64,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 05:11:52','2026-06-09 05:11:52'),(114,1,65,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 05:15:43','2026-06-09 05:15:43'),(115,1,66,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 05:17:34','2026-06-09 05:17:34'),(116,1,67,NULL,15,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-09 05:19:35','2026-06-09 05:19:35'),(117,1,68,NULL,15,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-09 05:20:58','2026-06-09 05:20:58'),(118,1,69,NULL,16,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 05:22:03','2026-06-09 05:22:03'),(119,1,69,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-09 05:22:03','2026-06-09 05:22:03'),(120,1,69,NULL,19,NULL,NULL,0,NULL,1,130.00,130.00,0.00,0.0000,NULL,'2026-06-09 05:22:03','2026-06-09 05:22:03'),(121,1,70,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 22:17:09','2026-06-09 22:17:09'),(122,1,70,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-09 22:17:09','2026-06-09 22:17:09'),(123,1,70,NULL,16,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 22:17:09','2026-06-09 22:17:09'),(124,1,70,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-09 22:17:09','2026-06-09 22:17:09'),(125,1,71,NULL,7,NULL,NULL,0,NULL,1,10.00,10.00,0.00,0.0000,NULL,'2026-06-09 22:25:01','2026-06-09 22:25:01'),(126,1,71,NULL,12,NULL,NULL,0,NULL,1,680.00,680.00,0.00,0.0000,NULL,'2026-06-09 22:25:01','2026-06-09 22:25:01'),(127,1,59,NULL,20,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-09 22:31:21','2026-06-09 22:31:21'),(128,1,59,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 22:31:21','2026-06-09 22:31:21'),(129,1,48,NULL,4,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-09 23:50:16','2026-06-09 23:50:16'),(130,1,48,NULL,8,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-09 23:50:16','2026-06-09 23:50:16'),(131,1,48,NULL,13,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-09 23:50:16','2026-06-09 23:50:16'),(132,1,56,NULL,16,NULL,NULL,0,NULL,1,120.00,120.00,0.00,0.0000,NULL,'2026-06-09 23:50:30','2026-06-09 23:50:30'),(133,3,72,NULL,33,NULL,NULL,0,NULL,1,680.00,680.00,0.00,0.0000,NULL,'2026-06-10 02:49:09','2026-06-10 02:49:09'),(134,3,72,NULL,34,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-10 02:49:09','2026-06-10 02:49:09'),(135,3,72,NULL,35,NULL,NULL,0,NULL,1,250.00,250.00,0.00,0.0000,NULL,'2026-06-10 02:49:09','2026-06-10 02:49:09'),(136,3,73,NULL,34,NULL,NULL,0,NULL,1,320.00,320.00,0.00,0.0000,NULL,'2026-06-10 03:01:41','2026-06-10 03:01:41'),(137,3,73,NULL,27,NULL,NULL,0,NULL,1,35.00,35.00,0.00,0.0000,NULL,'2026-06-10 03:01:41','2026-06-10 03:01:41'),(138,3,73,NULL,23,6,NULL,0,NULL,1,40.00,40.00,0.00,0.0000,NULL,'2026-06-10 03:01:41','2026-06-10 03:01:41'),(139,3,73,NULL,36,NULL,NULL,0,NULL,1,180.00,180.00,0.00,0.0000,NULL,'2026-06-10 03:01:41','2026-06-10 03:01:41'),(140,3,75,NULL,41,NULL,NULL,0,NULL,1,300.00,300.00,0.00,0.0000,NULL,'2026-06-10 03:45:46','2026-06-10 03:45:46'),(141,3,75,NULL,25,NULL,NULL,0,NULL,1,500.00,500.00,0.00,0.0000,NULL,'2026-06-10 03:45:46','2026-06-10 03:45:46'),(142,3,75,NULL,26,NULL,NULL,0,NULL,1,20.00,20.00,0.00,0.0000,NULL,'2026-06-10 03:45:46','2026-06-10 03:45:46'),(143,3,76,NULL,29,NULL,NULL,0,NULL,1,850.00,850.00,0.00,0.0000,NULL,'2026-06-10 03:56:28','2026-06-10 03:56:28'),(144,3,76,NULL,31,NULL,NULL,0,NULL,1,550.00,550.00,0.00,0.0000,NULL,'2026-06-10 03:56:28','2026-06-10 03:56:28'),(145,3,76,NULL,32,NULL,NULL,0,NULL,1,450.00,450.00,0.00,0.0000,NULL,'2026-06-10 03:56:28','2026-06-10 03:56:28'),(146,3,77,'TXN_6a293722438f03.11858946_187993',25,NULL,'',0,NULL,1,500.00,500.00,NULL,NULL,NULL,'2026-06-10 04:06:26','2026-06-10 04:06:26'),(147,3,77,'TXN_6a293722438f03.11858946_187993',23,5,'',0,NULL,1,25.00,25.00,NULL,NULL,NULL,'2026-06-10 04:06:26','2026-06-10 04:06:26'),(148,1,78,'TXN_6a2937a5d5a367.70330261_427592',3,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(149,1,78,'TXN_6a2937a5d5a367.70330261_427592',6,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(150,1,78,'TXN_6a2937a5d5a367.70330261_427592',5,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 04:08:37','2026-06-10 04:08:37'),(151,3,79,'TXN_6a2937ed4990d5.57776457_161190',24,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(152,3,79,'TXN_6a2937ed4990d5.57776457_161190',27,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(153,3,79,'TXN_6a2937ed4990d5.57776457_161190',26,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 04:09:49','2026-06-10 04:09:49'),(154,1,80,'TXN_6a2939db6d29f6.23867707_380018',1,NULL,'',0,NULL,1,30.00,30.00,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(155,1,80,'TXN_6a2939db6d29f6.23867707_380018',5,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(156,1,80,'TXN_6a2939db6d29f6.23867707_380018',7,NULL,'',0,NULL,1,10.00,10.00,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(157,1,80,'TXN_6a2939db6d29f6.23867707_380018',8,NULL,'',0,NULL,1,850.00,850.00,NULL,NULL,NULL,'2026-06-10 04:18:03','2026-06-10 04:18:03'),(161,3,83,'TXN_6a2942df937b25.40371338_873911',25,NULL,'',0,NULL,1,500.00,500.00,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(162,3,83,'TXN_6a2942df937b25.40371338_873911',34,NULL,'',0,NULL,1,320.00,320.00,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(163,3,83,'TXN_6a2942df937b25.40371338_873911',23,6,'',0,NULL,1,40.00,40.00,NULL,NULL,NULL,'2026-06-10 04:56:31','2026-06-10 04:56:31'),(164,1,84,'TXN_6a2943da36b730.64646559_582909',6,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(165,1,84,'TXN_6a2943da36b730.64646559_582909',5,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(166,1,84,'TXN_6a2943da36b730.64646559_582909',3,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 05:00:42','2026-06-10 05:00:42'),(167,3,85,'TXN_6a294410287aa9.35896749_813509',24,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(168,3,85,'TXN_6a294410287aa9.35896749_813509',27,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(169,3,85,'TXN_6a294410287aa9.35896749_813509',26,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 05:01:36','2026-06-10 05:01:36'),(170,3,86,'TXN_6a2946933d0188.10575622_421011',25,NULL,'',0,NULL,1,500.00,500.00,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(171,3,86,'TXN_6a2946933d0188.10575622_421011',27,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(172,3,86,'TXN_6a2946933d0188.10575622_421011',26,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 05:12:19','2026-06-10 05:12:19'),(173,3,87,'TXN_6a2948f7a69497.94260701_268751',27,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(174,3,87,'TXN_6a2948f7a69497.94260701_268751',24,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(175,3,87,'TXN_6a2948f7a69497.94260701_268751',26,NULL,'',0,NULL,1,20.00,20.00,NULL,NULL,NULL,'2026-06-10 05:22:31','2026-06-10 05:22:31'),(176,3,88,'TXN_6a294b0c226a20.28502024_323223',29,NULL,'',0,NULL,1,850.00,850.00,NULL,NULL,NULL,'2026-06-10 05:31:24','2026-06-10 05:31:24'),(177,3,89,'TXN_6a294cd4e3bc53.28437236_310371',34,NULL,'',0,NULL,1,320.00,320.00,NULL,NULL,NULL,'2026-06-10 05:39:00','2026-06-10 05:39:00'),(178,1,89,'TXN_6a294d21a8a4b5.20909758_211799',3,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 05:40:17','2026-06-10 05:40:17'),(179,1,90,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-10 22:39:37','2026-06-10 22:39:37'),(180,1,91,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-10 22:41:27','2026-06-10 22:41:27'),(181,1,92,NULL,9,NULL,NULL,0,NULL,1,750.00,750.00,0.00,0.0000,NULL,'2026-06-10 22:45:40','2026-06-10 22:45:40'),(182,1,93,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-10 22:48:19','2026-06-10 22:48:19'),(183,1,94,NULL,18,NULL,NULL,0,NULL,1,80.00,80.00,0.00,0.0000,NULL,'2026-06-10 22:50:16','2026-06-10 22:50:16'),(184,1,95,NULL,7,NULL,NULL,0,NULL,1,10.00,10.00,0.00,0.0000,NULL,'2026-06-10 23:13:03','2026-06-10 23:13:03'),(185,1,95,NULL,14,NULL,NULL,0,NULL,1,250.00,250.00,0.00,0.0000,NULL,'2026-06-10 23:13:03','2026-06-10 23:13:03'),(186,3,96,'TXN_6a2a445d65cc03.51374602_541038',29,NULL,'',0,NULL,1,850.00,850.00,NULL,NULL,NULL,'2026-06-10 23:15:09','2026-06-10 23:15:09'),(187,3,97,'TXN_6a2a4546d06b14.53624515_544773',34,NULL,'',0,NULL,1,320.00,320.00,NULL,NULL,NULL,'2026-06-10 23:19:02','2026-06-10 23:19:02'),(188,3,98,NULL,33,NULL,NULL,0,NULL,1,680.00,680.00,0.00,0.0000,NULL,'2026-06-10 23:23:47','2026-06-10 23:23:47'),(189,3,99,'TXN_6a2a46cf6ed756.72299177_348605',41,NULL,'',0,NULL,1,300.00,300.00,NULL,NULL,NULL,'2026-06-10 23:25:35','2026-06-10 23:25:35'),(190,3,100,'TXN_6a2a4757459ed5.47220017_300461',27,NULL,'',0,NULL,1,35.00,35.00,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(191,3,100,'TXN_6a2a4757459ed5.47220017_300461',24,NULL,'',0,NULL,1,120.00,120.00,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(192,3,100,'TXN_6a2a4757459ed5.47220017_300461',22,NULL,'',0,NULL,1,30.00,30.00,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51'),(193,3,100,'TXN_6a2a4757459ed5.47220017_300461',23,5,'',0,NULL,1,25.00,25.00,NULL,NULL,NULL,'2026-06-10 23:27:51','2026-06-10 23:27:51');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_notification_settings`
--

DROP TABLE IF EXISTS `order_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_notification_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `hide_new_order_notification` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_notification_restaurant_role_unique` (`restaurant_id`,`role_id`),
  KEY `order_notification_settings_role_id_foreign` (`role_id`),
  CONSTRAINT `order_notification_settings_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_notification_settings_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_notification_settings`
--

LOCK TABLES `order_notification_settings` WRITE;
/*!40000 ALTER TABLE `order_notification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_number_settings`
--

DROP TABLE IF EXISTS `order_number_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_number_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `enable_feature` tinyint(1) NOT NULL DEFAULT '0',
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ORD',
  `digits` tinyint unsigned NOT NULL DEFAULT '3',
  `separator` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-',
  `include_date` tinyint(1) NOT NULL DEFAULT '0',
  `show_year` tinyint(1) NOT NULL DEFAULT '0',
  `show_month` tinyint(1) NOT NULL DEFAULT '0',
  `show_day` tinyint(1) NOT NULL DEFAULT '0',
  `show_time` tinyint(1) NOT NULL DEFAULT '0',
  `reset_daily` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_number_settings_branch_id_foreign` (`branch_id`),
  CONSTRAINT `order_number_settings_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_number_settings`
--

LOCK TABLES `order_number_settings` WRITE;
/*!40000 ALTER TABLE `order_number_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_number_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_places`
--

DROP TABLE IF EXISTS `order_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_places` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `printer_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_places_branch_id_foreign` (`branch_id`),
  KEY `order_places_printer_id_foreign` (`printer_id`),
  CONSTRAINT `order_places_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_places_printer_id_foreign` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_places`
--

LOCK TABLES `order_places` WRITE;
/*!40000 ALTER TABLE `order_places` DISABLE KEYS */;
INSERT INTO `order_places` VALUES (1,NULL,1,'Default POS Terminal','vegetarian',1,1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,NULL,2,'Default POS Terminal','vegetarian',1,1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,NULL,3,'Default POS Terminal','vegetarian',1,1,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `order_places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_taxes`
--

DROP TABLE IF EXISTS `order_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `tax_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_taxes_order_id_foreign` (`order_id`),
  KEY `order_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `order_taxes_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_taxes`
--

LOCK TABLES `order_taxes` WRITE;
/*!40000 ALTER TABLE `order_taxes` DISABLE KEYS */;
INSERT INTO `order_taxes` VALUES (22,13,7),(23,14,7),(24,15,7),(25,16,7),(26,17,7),(27,18,7),(28,19,7),(29,20,7),(30,21,7),(31,22,7),(32,23,7),(33,24,7),(34,25,7),(35,26,7),(36,27,7),(37,28,7),(38,29,7),(39,30,7),(40,31,7),(41,32,7),(43,34,7),(44,35,7),(45,36,7),(46,37,7),(47,38,7),(48,39,7),(49,40,7),(50,41,7),(51,42,7),(52,43,7),(53,44,7),(54,45,7),(55,46,7),(56,49,7),(57,50,7),(59,52,7),(60,53,7),(61,54,7),(62,55,7),(63,58,7),(64,60,7),(65,61,7),(66,62,7),(67,63,7),(68,57,7),(69,64,7),(70,65,7),(71,66,7),(72,67,7),(73,68,7),(74,69,7),(75,70,7),(76,71,7),(77,59,7),(78,48,7),(79,56,7),(80,72,8),(81,73,8),(82,75,8),(83,76,8),(84,77,8),(85,78,7),(86,79,8),(87,80,7),(90,83,8),(91,84,7),(92,85,8),(93,86,8),(94,87,8),(95,88,8),(96,89,8),(97,89,7),(98,90,7),(99,91,7),(100,92,7),(101,93,7),(102,94,7),(103,95,7),(104,96,8),(105,97,8),(106,98,8),(107,99,8),(108,100,8);
/*!40000 ALTER TABLE `order_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_types`
--

DROP TABLE IF EXISTS `order_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `order_type_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `enable_token_number` tinyint(1) NOT NULL DEFAULT '0',
  `show_order_number_on_board` tinyint(1) NOT NULL DEFAULT '0',
  `enable_from_customer_site` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_types_branch_id_foreign` (`branch_id`),
  CONSTRAINT `order_types_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_types`
--

LOCK TABLES `order_types` WRITE;
/*!40000 ALTER TABLE `order_types` DISABLE KEYS */;
INSERT INTO `order_types` VALUES (1,1,'Dine In','dine_in',1,1,1,1,1,'dine_in','2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,'Delivery','delivery',1,1,1,1,1,'delivery','2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,'Pickup','pickup',1,1,1,1,1,'pickup','2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,2,'Dine In','dine_in',1,1,1,1,1,'dine_in','2026-06-05 23:44:09','2026-06-05 23:44:09'),(5,2,'Delivery','delivery',1,1,1,1,1,'delivery','2026-06-05 23:44:09','2026-06-05 23:44:09'),(6,2,'Pickup','pickup',1,1,1,1,1,'pickup','2026-06-05 23:44:09','2026-06-05 23:44:09'),(7,3,'Dine In','dine_in',1,1,1,1,1,'dine_in','2026-06-10 00:34:49','2026-06-10 00:34:49'),(8,3,'Delivery','delivery',1,1,1,1,1,'delivery','2026-06-10 00:34:49','2026-06-10 00:34:49'),(9,3,'Pickup','pickup',1,1,1,1,1,'pickup','2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `order_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formatted_order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `table_id` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `number_of_pax` int DEFAULT NULL,
  `order_note` text COLLATE utf8mb4_unicode_ci,
  `waiter_id` bigint unsigned DEFAULT NULL,
  `waiter_response` enum('pending','accepted','declined') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `waiter_notification_sent_at` timestamp NULL DEFAULT NULL,
  `waiter_response_at` timestamp NULL DEFAULT NULL,
  `added_by` bigint unsigned DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancel_time` datetime DEFAULT NULL,
  `status` enum('draft','kot','billed','paid','canceled','payment_due','ready','out_for_delivery','delivered','pending_verification') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'kot',
  `placed_via` enum('pos','shop') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total` decimal(16,2) NOT NULL,
  `tip_amount` decimal(16,2) DEFAULT '0.00',
  `total_tax_amount` decimal(16,2) DEFAULT '0.00',
  `tax_base` decimal(16,2) DEFAULT NULL,
  `tax_mode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tip_note` text COLLATE utf8mb4_unicode_ci,
  `total` decimal(16,2) NOT NULL,
  `amount_paid` decimal(16,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order_type_id` bigint unsigned DEFAULT NULL,
  `delivery_app_id` bigint unsigned DEFAULT NULL,
  `custom_order_type_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `delivery_executive_id` bigint unsigned DEFAULT NULL,
  `route_sequence` smallint unsigned DEFAULT NULL,
  `delivery_proof` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_address` text COLLATE utf8mb4_unicode_ci,
  `delivery_time` datetime DEFAULT NULL,
  `estimated_delivery_time` datetime DEFAULT NULL,
  `split_type` enum('even','custom','items') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_value` decimal(16,2) DEFAULT NULL,
  `discount_amount` decimal(16,2) DEFAULT NULL,
  `discount_apply_on` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sub_total',
  `order_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'placed',
  `delivery_fee` decimal(8,2) NOT NULL DEFAULT '0.00',
  `customer_lat` decimal(10,7) DEFAULT NULL,
  `customer_lng` decimal(10,7) DEFAULT NULL,
  `is_within_radius` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_started_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `estimated_eta_min` int DEFAULT NULL,
  `estimated_eta_max` int DEFAULT NULL,
  `cancel_reason_id` bigint unsigned DEFAULT NULL,
  `cancel_reason_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reservation_id` bigint unsigned DEFAULT NULL,
  `loyalty_points_redeemed` int NOT NULL DEFAULT '0',
  `loyalty_discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stamp_discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_uuid_unique` (`uuid`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_delivery_executive_id_foreign` (`delivery_executive_id`),
  KEY `orders_waiter_id_foreign` (`waiter_id`),
  KEY `orders_cancel_reason_id_foreign` (`cancel_reason_id`),
  KEY `idx_branch_date` (`branch_id`,`date_time`),
  KEY `orders_reservation_id_foreign` (`reservation_id`),
  KEY `orders_added_by_foreign` (`added_by`),
  KEY `orders_cancelled_by_foreign` (`cancelled_by`),
  KEY `idx_orders_branch_table_status` (`branch_id`,`table_id`,`status`),
  KEY `idx_orders_table_branch_status` (`table_id`,`branch_id`,`status`),
  KEY `idx_orders_status_branch` (`status`,`branch_id`),
  KEY `idx_orders_order_type_branch` (`order_type_id`,`branch_id`),
  KEY `idx_orders_delivery_app` (`delivery_app_id`),
  CONSTRAINT `orders_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_cancel_reason_id_foreign` FOREIGN KEY (`cancel_reason_id`) REFERENCES `kot_cancel_reasons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_delivery_app_id_foreign` FOREIGN KEY (`delivery_app_id`) REFERENCES `delivery_platforms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_delivery_executive_id_foreign` FOREIGN KEY (`delivery_executive_id`) REFERENCES `delivery_executives` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_order_type_id_foreign` FOREIGN KEY (`order_type_id`) REFERENCES `order_types` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_reservation_id_foreign` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_waiter_id_foreign` FOREIGN KEY (`waiter_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'e1da9832-a7c8-4557-bf76-93c1967edeee',1,'1',NULL,'2026-06-06 08:28:09',NULL,NULL,1,NULL,NULL,'pending','2026-06-06 02:28:22',NULL,2,NULL,NULL,'paid','pos',30.00,0.00,1.50,30.00,'order',NULL,31.50,31.50,'2026-06-06 02:28:09','2026-06-06 02:28:22',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(2,'66bcdf0e-2ba7-4af8-bd45-6e815cc86786',1,'2',NULL,'2026-06-06 08:28:46',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',60.00,0.00,3.00,60.00,'order',NULL,63.00,63.00,'2026-06-06 02:28:46','2026-06-06 02:28:52',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(3,'ded124f1-a67f-42b4-9389-5161808547c7',1,'3',NULL,'2026-06-06 08:29:17',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',90.00,0.00,4.50,90.00,'order',NULL,94.50,94.50,'2026-06-06 02:29:17','2026-06-06 02:29:32',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(4,'f773b73b-490d-4e02-a65e-a041b2276dbc',1,'4',NULL,'2026-06-06 08:30:32',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',120.00,0.00,6.00,120.00,'order',NULL,126.00,126.00,'2026-06-06 02:30:32','2026-06-06 02:30:38',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(5,'a8d063c1-5f95-4bf0-81f0-94da75020cd7',1,'5',NULL,'2026-06-06 08:30:56',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',150.00,0.00,7.50,150.00,'order',NULL,157.50,157.50,'2026-06-06 02:30:56','2026-06-06 02:31:03',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(6,'0b0cbbae-f8f5-4e06-8714-eb307e7b9a48',1,'6',NULL,'2026-06-06 08:31:14',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',180.00,0.00,9.00,180.00,'order',NULL,189.00,189.00,'2026-06-06 02:31:14','2026-06-06 02:31:25',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(7,'c1a66fbc-a8c7-481b-ab15-6888cd7f3723',1,'7',NULL,'2026-06-06 08:31:43',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',210.00,0.00,10.50,210.00,'order',NULL,220.50,220.50,'2026-06-06 02:31:43','2026-06-06 02:31:48',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(8,'5030068d-55b6-492e-8e89-cac1cf015949',1,'8',NULL,'2026-06-06 08:32:01',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',240.00,0.00,12.00,240.00,'order',NULL,252.00,252.00,'2026-06-06 02:32:01','2026-06-06 02:32:06',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(9,'e1687f22-1d12-4132-928b-5ec227955202',1,'9',NULL,'2026-06-06 08:32:50',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',270.00,0.00,13.50,270.00,'order',NULL,283.50,283.50,'2026-06-06 02:32:50','2026-06-06 02:33:16',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(10,'af347145-3f4f-47b8-b268-6c26b83fe426',1,'9',NULL,'2026-06-06 11:26:22',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,8,NULL,NULL,'paid','pos',30.00,0.00,3.00,30.00,'order',NULL,34.50,34.50,'2026-06-06 05:26:22','2026-06-06 05:26:45',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(11,'d0736ef4-8a39-44d7-add5-44bc521cb638',1,'10',NULL,'2026-06-07 08:54:26',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',330.00,0.00,31.30,313.00,'order',NULL,359.95,359.95,'2026-06-07 02:54:26','2026-06-07 02:54:51',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',17.00,17.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(12,'1f056bcd-24e6-4e2e-a506-6cf1aa0d7968',1,'11',NULL,'2026-06-07 08:55:28',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',115.00,0.00,11.50,115.00,'order',NULL,132.25,132.25,'2026-06-07 02:55:28','2026-06-07 02:57:53',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(13,'659413b4-8b23-40fd-aecd-c297b7afd547',1,'12',NULL,'2026-06-09 06:03:35',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',300.00,0.00,25.00,250.00,'order',NULL,287.50,0.00,'2026-06-09 00:03:35','2026-06-09 00:03:38',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',50.00,50.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(14,'687f832e-c022-4469-8aea-10de47bb7573',1,'13',NULL,'2026-06-09 07:03:39',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 01:03:58',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,45.00,450.00,'order',NULL,517.50,517.50,'2026-06-09 01:03:39','2026-06-09 01:04:56',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',50.00,50.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(15,'724a491d-408f-4ad0-82cc-0c930e13ee0a',1,'14',NULL,'2026-06-09 07:06:43',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 01:06:56',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 01:06:43','2026-06-09 01:08:30',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(16,'0b568e3d-7e83-431f-a8b9-794908227722',1,'15',NULL,'2026-06-09 07:08:45',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',300.00,0.00,30.00,300.00,'order',NULL,345.00,0.00,'2026-06-09 01:08:45','2026-06-09 01:08:48',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(17,'77b7905f-e163-4cf0-9662-d669158bbcdc',1,'16',NULL,'2026-06-09 07:11:05',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 01:11:09',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 01:11:05','2026-06-09 01:11:35',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(18,'06dbf70d-62ab-47d0-8b94-616e8d56e446',1,'17',NULL,'2026-06-09 07:12:51',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 01:12:56',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 01:12:51','2026-06-09 01:13:35',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(19,'5599428c-3e23-4f55-a1c8-c4f27f7c5be9',1,'18',NULL,'2026-06-09 07:16:20',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 01:16:26',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 01:16:20','2026-06-09 01:16:38',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(20,'8581ca82-77ed-475a-9db3-63d57fe10cbb',1,'19',NULL,'2026-06-09 07:18:32',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',500.00,0.00,49.00,490.00,'order',NULL,563.50,563.50,'2026-06-09 01:18:32','2026-06-09 01:20:03',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',10.00,10.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(21,'f7bc6312-41bb-4e75-ba13-ff857e911328',1,'20',NULL,'2026-06-09 07:20:37',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',500.00,0.00,49.00,490.00,'order',NULL,563.50,564.00,'2026-06-09 01:20:37','2026-06-09 01:23:20',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom','fixed',10.00,10.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(22,'6357f169-2b07-4be1-a3ab-2e5c3ae93b69',1,'21',NULL,'2026-06-09 07:36:43',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',675.00,0.00,67.50,675.00,'order',NULL,776.25,0.00,'2026-06-09 01:36:43','2026-06-09 01:36:46',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(23,'5385f279-ea1a-4a7e-a627-730b004e87e9',1,'22',NULL,'2026-06-09 08:40:29',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 02:40:48',NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 02:40:29','2026-06-09 03:57:26',3,NULL,'Pickup','pickup','2026-06-09 14:39:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(24,'d4eb1c31-2697-4b6a-af30-a9350683f68d',1,'23',NULL,'2026-06-09 08:58:59',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,0.00,'2026-06-09 02:58:59','2026-06-09 02:59:02',3,NULL,'Pickup','pickup','2026-06-09 14:58:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(25,'34d7c468-22fc-4fa0-8c3b-e809fcdbc51d',1,'24',NULL,'2026-06-09 09:06:52',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',500.00,0.00,49.00,490.00,'order',NULL,563.50,0.00,'2026-06-09 03:06:52','2026-06-09 03:06:55',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',10.00,10.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(26,'b843abca-109d-47eb-9cb6-fe65d94c7db5',1,'25',NULL,'2026-06-09 09:10:09',NULL,1,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,0.00,'2026-06-09 03:10:09','2026-06-09 03:10:12',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(27,'a28db587-7395-43af-a66f-c1c5ed4d4911',1,'26',NULL,'2026-06-09 09:11:11',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',620.00,0.00,62.00,620.00,'order',NULL,713.00,713.00,'2026-06-09 03:11:11','2026-06-09 03:11:20',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(28,'f0bc7545-605b-4011-a5f9-4230c59cc278',1,'27',NULL,'2026-06-09 09:12:38',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 03:12:38','2026-06-09 03:13:29',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(29,'831abf82-cfa0-4ac7-85a3-ee1917a9c8fc',1,'28',NULL,'2026-06-09 09:17:07',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'payment_due','pos',2000.00,0.00,200.00,2000.00,'order',NULL,2300.00,2000.00,'2026-06-09 03:17:07','2026-06-09 03:18:10',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom',NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(30,'b93b4598-2e6f-4b96-8e69-992330db4c5f',1,'29',NULL,'2026-06-09 09:18:46',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',2000.00,0.00,200.00,2000.00,'order',NULL,2300.00,2300.00,'2026-06-09 03:18:46','2026-06-09 03:19:35',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(31,'b7fab757-2063-4a47-9839-8c77f30e762c',1,'30',NULL,'2026-06-09 09:22:04',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',2500.00,0.00,250.00,2500.00,'order',NULL,2875.00,2875.00,'2026-06-09 03:22:04','2026-06-09 03:22:42',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(32,'df8890c3-dd58-4c09-accc-5d03f42de71e',1,'31',NULL,'2026-06-09 09:23:42',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',2000.00,0.00,200.00,2000.00,'order',NULL,2300.00,2300.00,'2026-06-09 03:23:42','2026-06-09 03:24:21',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'even',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(34,'b1a89f53-58c7-4f6c-8224-ef89b37fc6f5',1,'32',NULL,'2026-06-09 09:32:57',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',1500.00,0.00,150.00,1500.00,'order',NULL,1725.00,0.00,'2026-06-09 03:32:57','2026-06-09 03:33:00',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(35,'fea97c4f-f877-4a32-a524-41329b5baa5e',1,'33',NULL,'2026-06-09 09:36:38',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',3205.00,0.00,320.50,3205.00,'order',NULL,3685.75,3685.75,'2026-06-09 03:36:38','2026-06-09 03:36:50',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(36,'ad8fb9cd-e61c-4e8a-93f8-c059f648cc6a',1,'34',NULL,'2026-06-09 09:55:52',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 03:55:52','2026-06-09 03:56:07',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(37,'018bfe3b-1838-4039-8e2c-d31106c0e974',1,'35',NULL,'2026-06-09 09:59:53',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,138.00,'2026-06-09 03:59:53','2026-06-09 04:00:53',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'even',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(38,'129ddfac-b8d8-4804-9fe7-88eda9758e8c',1,'36',NULL,'2026-06-09 10:00:59',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',500.00,0.00,50.00,500.00,'order',NULL,575.00,575.00,'2026-06-09 04:00:59','2026-06-09 04:01:17',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'even',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(39,'74b657d2-0af3-42fe-9508-a475069c8a97',1,'37',NULL,'2026-06-09 10:01:25',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',850.00,0.00,85.00,850.00,'order',NULL,977.50,0.00,'2026-06-09 04:01:25','2026-06-09 04:01:28',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(40,'3c7e85eb-2492-4394-8f34-7e2cd1cbcdfc',1,'38',NULL,'2026-06-09 10:03:06',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',1600.00,0.00,160.00,1600.00,'order',NULL,1840.00,1840.00,'2026-06-09 04:03:06','2026-06-09 04:03:12',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(41,'b6999456-b1fe-4f3e-8acd-fe0e0a349fe5',1,'39',NULL,'2026-06-09 10:03:18',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',300.00,0.00,30.00,300.00,'order',NULL,345.00,345.00,'2026-06-09 04:03:18','2026-06-09 04:03:24',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(42,'1a545510-a57d-41fe-b298-97a3d0601242',1,'40',NULL,'2026-06-09 10:03:30',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',10.00,0.00,1.00,10.00,'order',NULL,11.50,11.50,'2026-06-09 04:03:30','2026-06-09 04:03:41',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'even',NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(43,'589cf1a9-27b4-42af-b044-f22e924a094d',1,'41',NULL,'2026-06-09 10:03:51',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',515.00,0.00,51.50,515.00,'order',NULL,592.25,592.25,'2026-06-09 04:03:51','2026-06-09 04:04:00',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(44,'bf006f2a-7aad-47fc-bfcc-fc679711e4f2',1,'42',NULL,'2026-06-09 10:04:23',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'payment_due','pos',180.00,0.00,18.00,180.00,'order',NULL,207.00,138.00,'2026-06-09 04:04:23','2026-06-09 04:05:45',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'even',NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(45,'8fac72d1-e012-4210-8068-8579bbc84383',1,'43',NULL,'2026-06-09 10:05:51',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',850.00,0.00,85.00,850.00,'order',NULL,977.50,977.50,'2026-06-09 04:05:51','2026-06-09 04:06:48',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(46,'a1d2ad92-8991-47e7-8870-225a2c22735f',1,'44',NULL,'2026-06-09 10:08:06',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:09:00',NULL,2,NULL,NULL,'paid','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,138.00,'2026-06-09 04:08:06','2026-06-09 04:14:06',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','served',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(47,'d7b71725-5e6d-45c2-a296-afd93d3e6ca1',1,'45',NULL,'2026-06-09 10:09:13',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:09:21',NULL,2,NULL,NULL,'kot','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,0.00,'2026-06-09 04:09:13','2026-06-09 04:14:04',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','served',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(48,'4b2bfd29-4f37-4b08-b74f-631caaadedaf',1,'46',NULL,'2026-06-10 05:50:16',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:12:08',NULL,2,NULL,NULL,'billed','pos',1670.00,0.00,167.00,1670.00,'order',NULL,1920.50,0.00,'2026-06-09 04:12:01','2026-06-09 23:50:16',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','served',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(49,'8086b85c-04dc-4f1d-ab0f-c7ef608bb76f',1,'47',NULL,'2026-06-09 10:18:35',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:14:23',NULL,2,NULL,NULL,'kot','pos',355.00,0.00,35.50,355.00,'order',NULL,408.25,22.00,'2026-06-09 04:14:20','2026-06-09 04:20:05',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','served',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(50,'23e1c785-9e0f-4f7f-902f-c4a191ec4fd8',1,'48',NULL,'2026-06-09 10:22:17',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',1970.00,100.00,197.00,1970.00,'order','',2365.50,2365.50,'2026-06-09 04:22:17','2026-06-09 04:22:37',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(52,'e5caabe2-1aaf-435a-97bc-55a60e3797a4',1,'49',NULL,'2026-06-09 10:25:54',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',2100.00,0.00,210.00,2100.00,'order',NULL,2415.00,0.00,'2026-06-09 04:25:54','2026-06-09 04:25:57',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(53,'682272aa-765d-4ce0-b03e-085068a86536',1,'50',NULL,'2026-06-09 10:30:37',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',1780.00,0.00,178.00,1780.00,'order',NULL,2047.00,0.00,'2026-06-09 04:30:37','2026-06-09 04:30:40',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(54,'59580eb3-61bf-4a62-a880-776da2b8dbaa',1,'51',NULL,'2026-06-09 10:37:56',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,0.00,'2026-06-09 04:37:56','2026-06-09 04:51:27',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(55,'e31b923f-9b3f-4bf9-b628-0f9f7ae4921b',1,'52',NULL,'2026-06-09 10:40:59',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:38:36',NULL,2,NULL,NULL,'paid','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,138.00,'2026-06-09 04:38:33','2026-06-09 04:42:00',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(56,'b7e4af72-df48-404a-bf82-cd88619da6ed',1,'53',NULL,'2026-06-10 05:50:30',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:39:01',NULL,2,NULL,NULL,'paid','pos',120.00,0.00,12.00,120.00,'order',NULL,138.00,138.00,'2026-06-09 04:38:54','2026-06-09 23:51:01',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(57,'48f3847e-1fb8-4f85-afe6-ac55da724f00',1,'54',NULL,'2026-06-09 11:04:59',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:39:11',NULL,2,NULL,NULL,'billed','pos',680.00,0.00,68.00,680.00,'order',NULL,782.00,0.00,'2026-06-09 04:39:08','2026-06-09 05:05:00',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(58,'a7663e1e-5cc5-4753-a765-dcfdb8347e69',1,'55',NULL,'2026-06-09 10:42:10',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',90.00,0.00,9.00,90.00,'order',NULL,103.50,0.00,'2026-06-09 04:42:10','2026-06-09 04:42:13',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(59,'c50a3554-6008-44fc-88fc-26bdbca830ad',1,'56',NULL,'2026-06-10 04:31:21',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:46:52',NULL,2,NULL,NULL,'paid','pos',620.00,0.00,31.00,310.00,'order',NULL,356.50,356.50,'2026-06-09 04:46:45','2026-06-09 22:54:22',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'percent',50.00,310.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(60,'0f6bb0c8-7e8e-477e-a2b6-ffa22c7f2a39',1,'57',NULL,'2026-06-09 10:49:28',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 04:50:06',NULL,2,NULL,NULL,'paid','pos',60.00,0.00,6.00,60.00,'order',NULL,69.00,69.00,'2026-06-09 04:49:28','2026-06-09 04:57:31',3,NULL,'Pickup','pickup','2026-06-09 16:48:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','delivered',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(61,'7a33729f-967a-4b3c-8730-c25c481cda6f',1,'58',NULL,'2026-06-09 10:51:53',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',320.00,0.00,32.00,320.00,'order',NULL,368.00,368.00,'2026-06-09 04:51:53','2026-06-09 04:51:59',3,NULL,'Pickup','pickup','2026-06-09 16:51:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(62,'0aca43ce-4b45-47fa-adb1-d7ec7a5bbf12',1,'59',NULL,'2026-06-09 10:53:04',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',80.00,0.00,8.00,80.00,'order',NULL,92.00,92.00,'2026-06-09 04:53:04','2026-06-09 04:53:10',3,NULL,'Pickup','pickup','2026-06-09 16:48:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(63,'4eca15af-5330-483f-ba3c-7d23976a54e7',1,'60',NULL,'2026-06-09 10:54:30',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',45.00,0.00,4.50,45.00,'order',NULL,51.75,51.75,'2026-06-09 04:54:30','2026-06-09 04:54:35',3,NULL,'Pickup','pickup','2026-06-09 16:48:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(64,'72837d36-4e3b-42b3-a373-a148b3fa2ff1',1,'61',NULL,'2026-06-09 11:11:49',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',1170.00,0.00,117.00,1170.00,'order',NULL,1345.50,1345.50,'2026-06-09 05:11:49','2026-06-09 05:12:01',2,NULL,'Delivery','delivery',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(65,'cfb1497f-c32d-4ce0-bb1d-01cef7b97047',1,'62',NULL,'2026-06-09 11:15:40',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',850.00,0.00,85.00,850.00,'order',NULL,977.50,977.50,'2026-06-09 05:15:40','2026-06-09 05:15:46',2,NULL,'Delivery','delivery',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(66,'6b76426a-fc12-4e6d-bdca-421b6070dd3a',1,'63',NULL,'2026-06-09 11:17:31',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',300.00,0.00,25.00,250.00,'order',NULL,407.50,407.50,'2026-06-09 05:17:31','2026-06-09 05:17:42',2,NULL,'Delivery','delivery',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',50.00,50.00,'sub_total','completed',120.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(67,'89d6b0ae-ffcf-4d21-9880-b76f35c2e8d9',1,'64',NULL,'2026-06-09 11:19:32',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',180.00,0.00,18.00,180.00,'order',NULL,207.00,207.00,'2026-06-09 05:19:32','2026-06-09 05:19:41',2,NULL,'Delivery','delivery',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(68,'373d7392-6d8f-420c-b032-796d13760f97',1,'65',NULL,'2026-06-09 11:20:55',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',180.00,0.00,18.00,180.00,'order',NULL,207.00,0.00,'2026-06-09 05:20:55','2026-06-09 05:20:58',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(69,'f7cf271d-54bd-4d1e-a946-a8b00393c464',1,'66',NULL,'2026-06-09 11:22:00',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',330.00,0.00,33.00,330.00,'order',NULL,379.50,379.50,'2026-06-09 05:22:00','2026-06-09 05:22:11',2,NULL,'Delivery','delivery',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(70,'d05c0ef4-8241-4ca0-9da1-7a004dccbea6',1,'67',NULL,'2026-06-10 04:17:06',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 22:22:18',NULL,2,NULL,NULL,'paid','pos',1800.00,30.00,180.00,1800.00,'order','',2100.00,2100.00,'2026-06-09 22:17:06','2026-06-09 22:23:58',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','served',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(71,'0483a387-4cbd-4b03-9bb5-8782f9406168',1,'68',NULL,'2026-06-10 04:25:01',NULL,NULL,1,NULL,NULL,'pending','2026-06-09 22:23:03',NULL,2,NULL,NULL,'paid','pos',690.00,0.00,69.00,690.00,'order',NULL,793.50,793.50,'2026-06-09 22:22:57','2026-06-09 22:25:05',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(72,'46479420-cb52-4abd-8048-77ac0f336a74',3,'1',NULL,'2026-06-10 08:49:06',5,3,1,NULL,11,'accepted',NULL,'2026-06-10 02:49:09',11,NULL,NULL,'paid','pos',1250.00,0.00,120.00,1200.00,'order',NULL,1380.00,1380.00,'2026-06-10 02:49:06','2026-06-10 02:49:22',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fixed',50.00,50.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(73,'d3a3406d-30cf-4c24-88c3-b78ba58e6852',3,'2',NULL,'2026-06-10 09:01:41',5,NULL,1,NULL,11,'accepted',NULL,'2026-06-10 02:51:28',11,NULL,NULL,'paid','pos',575.00,0.00,57.50,575.00,'order',NULL,661.25,661.25,'2026-06-10 02:51:25','2026-06-10 03:01:46',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(75,'9a49d475-46d6-4d02-b8cd-fa3abbe1ef9a',3,'4',NULL,'2026-06-10 09:45:46',2,5,1,'VIP',11,'accepted','2026-06-10 03:39:27','2026-06-10 03:39:48',11,NULL,NULL,'paid','pos',820.00,0.00,82.00,820.00,'order',NULL,943.00,943.00,'2026-06-10 03:39:16','2026-06-10 03:45:56',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(76,'33cbfe26-4fdb-46b6-9581-68f919d8df92',3,'5',NULL,'2026-06-10 09:56:28',5,6,1,'Premium server required.',11,'accepted','2026-06-10 03:53:09','2026-06-10 03:53:22',10,NULL,NULL,'paid','pos',1850.00,0.00,172.05,1720.50,'order',NULL,1892.55,1892.55,'2026-06-10 03:53:05','2026-06-10 03:57:03',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'percent',7.00,129.50,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(77,'cb39eeec-cf01-47be-83b7-1ac472f8ad6b',3,'6',NULL,'2026-06-10 10:06:26',5,NULL,NULL,NULL,NULL,'pending','2026-06-10 04:07:02',NULL,NULL,NULL,NULL,'paid','shop',525.00,0.00,52.50,525.00,'order',NULL,603.75,603.75,'2026-06-10 04:06:26','2026-06-10 04:08:02',7,NULL,'Dine In','dine_in','2026-06-16 16:02:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(78,'66c680fa-6605-4174-be38-a8784f6f28dd',1,'69',NULL,'2026-06-10 10:08:37',NULL,NULL,NULL,NULL,NULL,'pending','2026-06-10 04:09:23',NULL,NULL,NULL,NULL,'kot','shop',175.00,0.00,17.50,175.00,'order',NULL,201.25,0.00,'2026-06-10 04:08:37','2026-06-10 04:09:23',1,NULL,'Dine In','dine_in','2026-06-16 16:08:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','placed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(79,'05767a43-b066-4ba7-8f73-0dcafbc0b7bd',3,'7',NULL,'2026-06-10 10:09:49',NULL,NULL,NULL,NULL,NULL,'pending','2026-06-10 04:09:50',NULL,NULL,NULL,NULL,'kot','shop',175.00,0.00,17.50,175.00,'order',NULL,201.25,0.00,'2026-06-10 04:09:49','2026-06-10 04:13:45',7,NULL,'Dine In','dine_in','2026-06-16 16:09:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','served',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(80,'e6261c95-ab7a-4341-8df8-a7a545a29008',1,'70',NULL,'2026-06-10 10:18:03',12,NULL,NULL,NULL,NULL,'pending','2026-06-10 04:18:18',NULL,NULL,NULL,NULL,'paid','shop',910.00,0.00,91.00,910.00,'order',NULL,1046.50,1046.50,'2026-06-10 04:18:03','2026-06-10 04:18:59',1,NULL,'Dine In','dine_in','2026-06-16 16:17:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(83,'f87f9498-84e7-4644-9e9e-fc7034fbfeb2',3,'8',NULL,'2026-06-10 10:57:22',NULL,NULL,1,'Customer 01',11,'accepted','2026-06-10 04:56:36','2026-06-10 04:57:58',2,NULL,NULL,'paid','shop',860.00,0.00,86.00,860.00,'order',NULL,989.00,989.00,'2026-06-10 04:56:31','2026-06-10 04:58:53',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(84,'75023e3a-7a84-47d4-84c0-6ede3bff5bc9',1,'71',NULL,'2026-06-10 11:00:42',NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,NULL,NULL,NULL,'kot','shop',175.00,0.00,17.50,175.00,'order',NULL,201.25,0.00,'2026-06-10 05:00:42','2026-06-10 05:00:42',1,NULL,'Dine In','dine_in','2026-06-16 17:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','placed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(85,'79795d91-4a83-4aa3-88bc-355f36569958',3,'9',NULL,'2026-06-10 11:04:00',NULL,NULL,1,'Customer 02',11,'accepted','2026-06-10 05:01:36','2026-06-10 05:02:38',10,NULL,NULL,'paid','shop',175.00,0.00,17.50,175.00,'order',NULL,201.25,201.25,'2026-06-10 05:01:36','2026-06-10 05:04:06',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(86,'ceec1b21-c226-4fe7-9557-aaf074b79dec',3,'10',NULL,'2026-06-10 11:12:19',5,21,NULL,NULL,11,'accepted','2026-06-10 05:12:28','2026-06-10 05:14:47',NULL,NULL,NULL,'kot','shop',555.00,0.00,55.50,555.00,'order',NULL,638.25,0.00,'2026-06-10 05:12:19','2026-06-10 05:16:42',7,NULL,'Dine In','dine_in','2026-06-16 17:11:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(87,'e2cdf4c3-efee-4e1c-8450-81a6e101efc5',3,'11',NULL,'2026-06-10 11:24:37',5,NULL,NULL,NULL,11,'accepted','2026-06-10 05:22:43','2026-06-10 05:23:25',NULL,NULL,NULL,'paid','shop',175.00,0.00,17.50,175.00,'order',NULL,192.50,192.50,'2026-06-10 05:22:31','2026-06-10 05:24:56',7,NULL,'Dine In','dine_in','2026-06-16 17:21:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(88,'47944120-269b-40b4-8eaf-16edb2b1eb63',3,'12',NULL,'2026-06-10 11:31:24',NULL,30,NULL,NULL,NULL,'pending','2026-06-10 05:31:50',NULL,NULL,NULL,NULL,'paid','shop',850.00,0.00,85.00,850.00,'order',NULL,977.50,977.50,'2026-06-10 05:31:24','2026-06-10 05:33:37',7,NULL,'Dine In','dine_in','2026-06-16 17:31:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(89,'00f0ce2e-572e-4ca2-b9db-1a024de90a86',3,'13',NULL,'2026-06-10 11:45:20',NULL,30,1,NULL,NULL,'pending','2026-06-10 05:39:14',NULL,10,NULL,NULL,'paid','shop',320.00,0.00,32.00,320.00,'order',NULL,368.00,368.00,'2026-06-10 05:39:00','2026-06-10 05:45:23',9,NULL,'Pickup','pickup','2026-06-16 17:38:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(90,'29d14957-3019-454d-8302-0d197b883132',1,'72',NULL,'2026-06-11 04:39:33',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',80.00,0.00,8.00,80.00,'order',NULL,92.00,0.00,'2026-06-10 22:39:33','2026-06-10 22:39:37',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(91,'ddf739cf-1b6d-4960-a199-8fc871d6ffb5',1,'73',NULL,'2026-06-11 04:41:23',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',750.00,0.00,75.00,750.00,'order',NULL,862.50,0.00,'2026-06-10 22:41:23','2026-06-10 22:41:27',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(92,'a2afe375-9afd-4b43-adb7-b4fc6c450f00',1,'74',NULL,'2026-06-11 04:45:37',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',750.00,0.00,75.00,750.00,'order',NULL,862.50,0.00,'2026-06-10 22:45:37','2026-06-10 22:45:40',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(93,'ca569593-31c5-4640-9632-246118c6d958',1,'75',NULL,'2026-06-11 04:48:16',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'paid','pos',80.00,0.00,8.00,80.00,'order',NULL,92.00,92.00,'2026-06-10 22:48:16','2026-06-10 22:49:25',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(94,'81964d8f-8ffc-46f1-ab39-a66792689624',1,'76',NULL,'2026-06-11 04:50:13',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',80.00,0.00,8.00,80.00,'order',NULL,92.00,0.00,'2026-06-10 22:50:13','2026-06-10 22:50:16',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(95,'a799f708-6258-42e5-9334-3df60f2c999e',1,'77',NULL,'2026-06-11 05:13:00',NULL,NULL,1,NULL,NULL,'pending',NULL,NULL,2,NULL,NULL,'billed','pos',260.00,0.00,26.00,260.00,'order',NULL,299.00,0.00,'2026-06-10 23:13:00','2026-06-10 23:13:03',1,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','confirmed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(96,'87b6bc8e-8b33-4a76-bf01-01c9a20be80f',3,'14',NULL,'2026-06-11 05:17:03',NULL,31,1,NULL,NULL,'pending','2026-06-10 23:15:20',NULL,10,NULL,NULL,'paid','shop',850.00,0.00,85.00,850.00,'order',NULL,977.50,977.50,'2026-06-10 23:15:09','2026-06-10 23:17:08',9,NULL,'Pickup','pickup','2026-06-17 11:12:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(97,'737b4e12-d829-4989-b564-bea2685f49d8',3,'15',NULL,'2026-06-11 05:20:09',NULL,31,1,NULL,NULL,'pending','2026-06-10 23:19:20',NULL,10,NULL,NULL,'paid','shop',320.00,0.00,32.00,320.00,'order',NULL,368.00,368.00,'2026-06-10 23:19:02','2026-06-10 23:20:17',9,NULL,'Pickup','pickup','2026-06-17 11:18:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(98,'3fc9b825-a41e-4547-b94c-ec3999685140',3,'16',NULL,'2026-06-11 05:23:46',NULL,31,1,NULL,NULL,'pending','2026-06-10 23:23:05',NULL,10,NULL,NULL,'paid','pos',680.00,0.00,61.20,612.00,'order',NULL,703.80,703.80,'2026-06-10 23:22:58','2026-06-10 23:23:57',9,NULL,'Pickup','pickup','2026-06-11 11:12:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'percent',10.00,68.00,'sub_total','completed',0.00,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(99,'ab4ef19c-c2a8-44b6-bc3e-a4d5dd455ad4',3,'17',NULL,'2026-06-11 05:26:28',NULL,31,1,NULL,NULL,'pending','2026-06-10 23:25:44',NULL,10,NULL,NULL,'paid','shop',300.00,0.00,30.00,300.00,'order',NULL,345.00,345.00,'2026-06-10 23:25:35','2026-06-10 23:26:34',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00),(100,'aec10893-71bb-4d4c-a106-092bcf4190ea',3,'18',NULL,'2026-06-11 05:28:48',NULL,31,1,NULL,NULL,'pending','2026-06-10 23:28:00',NULL,10,NULL,NULL,'paid','shop',210.00,0.00,21.00,210.00,'order',NULL,241.50,241.50,'2026-06-10 23:27:51','2026-06-10 23:28:51',7,NULL,'Dine In','dine_in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,'sub_total','completed',0.00,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,0.00);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otps`
--

DROP TABLE IF EXISTS `otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'login',
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otps_identifier_type_index` (`identifier`,`type`),
  KEY `otps_token_index` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otps`
--

LOCK TABLES `otps` WRITE;
/*!40000 ALTER TABLE `otps` DISABLE KEYS */;
INSERT INTO `otps` VALUES (1,'sm2saiful@gmail.com','759723','delivery_login','2026-06-09 05:38:36',0,'2026-06-09 05:28:09','2026-06-09 05:28:36');
/*!40000 ALTER TABLE `otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_modules`
--

DROP TABLE IF EXISTS `package_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `package_id` bigint unsigned DEFAULT NULL,
  `module_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_modules_package_id_foreign` (`package_id`),
  KEY `package_modules_module_id_foreign` (`module_id`),
  CONSTRAINT `package_modules_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `package_modules_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_modules`
--

LOCK TABLES `package_modules` WRITE;
/*!40000 ALTER TABLE `package_modules` DISABLE KEYS */;
INSERT INTO `package_modules` VALUES (1,1,10,NULL,NULL),(2,1,11,NULL,NULL),(3,1,12,NULL,NULL),(4,1,13,NULL,NULL),(5,1,14,NULL,NULL),(6,1,15,NULL,NULL),(7,1,16,NULL,NULL),(8,1,17,NULL,NULL),(9,1,18,NULL,NULL),(10,1,19,NULL,NULL),(11,1,20,NULL,NULL),(12,1,21,NULL,NULL),(13,1,22,NULL,NULL),(14,1,23,NULL,NULL),(15,1,24,NULL,NULL),(16,1,25,NULL,NULL),(17,2,10,NULL,NULL),(18,2,11,NULL,NULL),(19,2,12,NULL,NULL),(20,2,13,NULL,NULL),(21,2,14,NULL,NULL),(22,2,15,NULL,NULL),(23,2,16,NULL,NULL),(24,2,17,NULL,NULL),(25,2,18,NULL,NULL),(26,2,19,NULL,NULL),(27,2,20,NULL,NULL),(28,2,21,NULL,NULL),(29,2,22,NULL,NULL),(30,2,23,NULL,NULL),(31,2,24,NULL,NULL),(32,2,25,NULL,NULL),(33,3,10,NULL,NULL),(34,3,11,NULL,NULL),(35,3,12,NULL,NULL),(36,3,13,NULL,NULL),(37,3,14,NULL,NULL),(38,3,15,NULL,NULL),(39,3,16,NULL,NULL),(40,3,17,NULL,NULL),(41,3,18,NULL,NULL),(42,3,19,NULL,NULL),(43,3,20,NULL,NULL),(44,3,21,NULL,NULL),(45,3,22,NULL,NULL),(46,3,23,NULL,NULL),(47,3,24,NULL,NULL),(48,3,25,NULL,NULL),(49,4,10,NULL,NULL),(50,4,11,NULL,NULL),(51,4,12,NULL,NULL),(52,4,13,NULL,NULL),(53,4,14,NULL,NULL),(54,4,15,NULL,NULL),(55,4,16,NULL,NULL),(56,4,17,NULL,NULL),(57,4,18,NULL,NULL),(58,4,19,NULL,NULL),(59,4,20,NULL,NULL),(60,4,21,NULL,NULL),(61,4,22,NULL,NULL),(62,4,23,NULL,NULL),(63,4,24,NULL,NULL),(64,4,25,NULL,NULL),(65,5,10,NULL,NULL),(66,5,11,NULL,NULL),(67,5,12,NULL,NULL),(68,5,13,NULL,NULL),(69,5,14,NULL,NULL),(70,5,15,NULL,NULL),(71,5,16,NULL,NULL),(72,5,17,NULL,NULL),(73,5,18,NULL,NULL),(74,5,19,NULL,NULL),(75,5,20,NULL,NULL),(76,5,21,NULL,NULL),(77,5,22,NULL,NULL),(78,5,23,NULL,NULL),(79,5,24,NULL,NULL),(80,5,25,NULL,NULL);
/*!40000 ALTER TABLE `package_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `package_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `annual_price` decimal(16,2) DEFAULT NULL,
  `monthly_price` decimal(16,2) DEFAULT NULL,
  `monthly_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `annual_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `stripe_annual_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_monthly_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_annual_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_monthly_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_annual_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_monthly_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_annual_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_monthly_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xendit_annual_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xendit_monthly_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paddle_annual_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paddle_monthly_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paddle_lifetime_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_lifetime_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_lifetime_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_cycle` tinyint unsigned DEFAULT NULL,
  `sort_order` int unsigned DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `is_free` tinyint(1) NOT NULL DEFAULT '0',
  `is_recommended` tinyint(1) NOT NULL DEFAULT '0',
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'standard',
  `trial_status` tinyint(1) DEFAULT NULL,
  `trial_days` int DEFAULT NULL,
  `trial_notification_before_days` int DEFAULT NULL,
  `trial_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_features` longtext COLLATE utf8mb4_unicode_ci,
  `branch_limit` int DEFAULT '-1',
  `multipos_limit` int DEFAULT '-1',
  `menu_items_limit` int NOT NULL DEFAULT '-1',
  `order_limit` int NOT NULL DEFAULT '-1',
  `staff_limit` int NOT NULL DEFAULT '-1',
  `ai_monthly_token_limit` int NOT NULL DEFAULT '-1',
  `sms_count` int NOT NULL DEFAULT '0',
  `carry_forward_sms` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `packages_currency_id_foreign` (`currency_id`),
  CONSTRAINT `packages_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Default',0.00,'2026-06-05 23:44:06','2026-06-05 23:44:06',1,'Its a default package and cannot be deleted',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,1,0,1,0,'default',NULL,NULL,NULL,NULL,NULL,-1,-1,-1,-1,-1,-1,0,0),(2,'Subscription Package',0.00,'2026-06-05 23:44:06','2026-06-05 23:44:06',1,'This is a subscription package',100.00,10.00,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,2,0,0,1,'standard',NULL,NULL,NULL,NULL,NULL,-1,-1,-1,-1,-1,-1,0,0),(3,'Life Time',199.00,'2026-06-05 23:44:06','2026-06-10 03:27:20',1,'This is a lifetime access package',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3,0,0,1,'lifetime',NULL,NULL,NULL,NULL,'[\"Export Report\",\"Table Reservation\",\"Payment Gateway Integration\",\"Theme Setting\",\"Customer Display\",\"Change Branch\"]',3,-1,-1,-1,-1,-1,0,0),(4,'Private Package',0.00,'2026-06-05 23:44:06','2026-06-05 23:44:06',1,'This is a private package',50.00,5.00,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,4,1,0,0,'standard',NULL,NULL,NULL,NULL,NULL,-1,-1,-1,-1,-1,-1,0,0),(5,'Trial Package',0.00,'2026-06-05 23:44:07','2026-06-05 23:44:07',1,'This is a trial package',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1,0,'trial',1,30,5,'30 Days Free Trial','[\"Change Branch\",\"Export Report\",\"Table Reservation\",\"Payment Gateway Integration\",\"Theme Setting\",\"Customer Display\"]',-1,-1,-1,-1,-1,-1,0,0);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payfast_payments`
--

DROP TABLE IF EXISTS `payfast_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payfast_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payfast_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payfast_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `payfast_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payfast_payments`
--

LOCK TABLES `payfast_payments` WRITE;
/*!40000 ALTER TABLE `payfast_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payfast_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateway_credentials`
--

DROP TABLE IF EXISTS `payment_gateway_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateway_credentials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `razorpay_key` text COLLATE utf8mb4_unicode_ci,
  `razorpay_secret` text COLLATE utf8mb4_unicode_ci,
  `razorpay_status` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_key` text COLLATE utf8mb4_unicode_ci,
  `stripe_secret` text COLLATE utf8mb4_unicode_ci,
  `stripe_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_dine_in_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_delivery_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_pickup_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_cash_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_qr_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_offline_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `offline_payment_detail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_code_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_status` tinyint(1) NOT NULL DEFAULT '0',
  `flutterwave_mode` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_flutterwave_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_flutterwave_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_flutterwave_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_flutterwave_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_flutterwave_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_flutterwave_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_webhook_secret_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_status` tinyint(1) NOT NULL DEFAULT '0',
  `paypal_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `sandbox_paypal_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_paypal_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_merchant_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_passphrase` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `payfast_status` tinyint(1) NOT NULL DEFAULT '0',
  `test_payfast_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_payfast_merchant_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_payfast_passphrase` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_merchant_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_status` tinyint(1) NOT NULL DEFAULT '0',
  `paystack_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `test_paystack_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paystack_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paystack_merchant_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_payment_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'https://api.paystack.co',
  `xendit_status` tinyint(1) NOT NULL DEFAULT '0',
  `xendit_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `test_xendit_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_xendit_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_xendit_webhook_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_webhook_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epay_status` tinyint(1) NOT NULL DEFAULT '0',
  `epay_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `epay_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epay_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epay_terminal_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_epay_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_epay_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_epay_terminal_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mollie_status` tinyint(1) NOT NULL DEFAULT '0',
  `mollie_mode` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_mollie_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_mollie_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mollie_webhook_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tap_status` tinyint(1) NOT NULL DEFAULT '0',
  `tap_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `tap_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_tap_secret_key` text COLLATE utf8mb4_unicode_ci,
  `live_tap_public_key` text COLLATE utf8mb4_unicode_ci,
  `test_tap_secret_key` text COLLATE utf8mb4_unicode_ci,
  `test_tap_public_key` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `payment_gateway_credentials_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `payment_gateway_credentials_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateway_credentials`
--

LOCK TABLES `payment_gateway_credentials` WRITE;
/*!40000 ALTER TABLE `payment_gateway_credentials` DISABLE KEYS */;
INSERT INTO `payment_gateway_credentials` VALUES (1,1,NULL,NULL,0,NULL,NULL,0,'2026-06-05 23:44:08','2026-06-05 23:44:08',0,0,0,0,0,0,NULL,NULL,0,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,'sandbox',0,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,'https://api.paystack.co',0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,0,'test',NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_gateway_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `amount` decimal(16,2) NOT NULL,
  `is_due` tinyint(1) NOT NULL DEFAULT '0',
  `due_amount_received` decimal(16,2) DEFAULT NULL,
  `balance` decimal(16,2) DEFAULT '0.00',
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_order_id_foreign` (`order_id`),
  KEY `payments_branch_id_foreign` (`branch_id`),
  CONSTRAINT `payments_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,1,'cash',31.50,0,NULL,0.00,NULL,'2026-06-06 02:28:15','2026-06-06 02:28:15'),(2,1,2,'cash',63.00,0,NULL,0.00,NULL,'2026-06-06 02:28:52','2026-06-06 02:28:52'),(3,1,3,'cash',94.50,0,NULL,0.00,NULL,'2026-06-06 02:29:32','2026-06-06 02:29:32'),(4,1,4,'cash',126.00,0,NULL,0.00,NULL,'2026-06-06 02:30:38','2026-06-06 02:30:38'),(5,1,5,'cash',157.50,0,NULL,0.00,NULL,'2026-06-06 02:31:03','2026-06-06 02:31:03'),(6,1,6,'cash',189.00,0,NULL,0.00,NULL,'2026-06-06 02:31:25','2026-06-06 02:31:25'),(7,1,7,'cash',220.50,0,NULL,0.00,NULL,'2026-06-06 02:31:47','2026-06-06 02:31:47'),(8,1,8,'cash',252.00,0,NULL,0.00,NULL,'2026-06-06 02:32:06','2026-06-06 02:32:06'),(9,1,9,'cash',283.50,0,NULL,0.00,NULL,'2026-06-06 02:33:16','2026-06-06 02:33:16'),(10,1,10,'cash',34.50,0,NULL,0.00,NULL,'2026-06-06 05:26:45','2026-06-06 05:26:45'),(11,1,11,'cash',359.95,0,NULL,140.05,NULL,'2026-06-07 02:54:51','2026-06-07 02:54:51'),(12,1,12,'card',50.00,0,NULL,0.00,NULL,'2026-06-07 02:56:20','2026-06-07 02:56:20'),(14,1,12,'card',20.00,0,20.00,0.00,NULL,'2026-06-07 02:57:30','2026-06-07 02:57:30'),(16,1,12,'cash',62.25,0,62.25,0.00,NULL,'2026-06-07 02:57:53','2026-06-07 02:57:53'),(17,1,14,'cash',517.50,0,NULL,0.00,NULL,'2026-06-09 01:04:56','2026-06-09 01:04:56'),(18,1,15,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 01:07:00','2026-06-09 01:07:00'),(19,1,17,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 01:11:23','2026-06-09 01:11:23'),(20,1,18,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 01:13:03','2026-06-09 01:13:03'),(21,1,19,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 01:16:38','2026-06-09 01:16:38'),(22,1,20,'card',563.50,0,NULL,0.50,NULL,'2026-06-09 01:20:03','2026-06-09 01:20:03'),(23,1,21,'cash',200.00,0,NULL,0.00,NULL,'2026-06-09 01:23:20','2026-06-09 01:23:20'),(24,1,21,'cash',200.00,0,NULL,0.00,NULL,'2026-06-09 01:23:20','2026-06-09 01:23:20'),(25,1,21,'cash',164.00,0,NULL,0.50,NULL,'2026-06-09 01:23:20','2026-06-09 01:23:20'),(26,1,27,'cash',713.00,0,NULL,0.00,NULL,'2026-06-09 03:11:20','2026-06-09 03:11:20'),(27,1,28,'cash',200.00,0,NULL,0.00,NULL,'2026-06-09 03:13:29','2026-06-09 03:13:29'),(28,1,28,'cash',200.00,0,NULL,0.00,NULL,'2026-06-09 03:13:29','2026-06-09 03:13:29'),(29,1,28,'cash',175.00,0,NULL,0.00,NULL,'2026-06-09 03:13:29','2026-06-09 03:13:29'),(30,1,29,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:18:10','2026-06-09 03:18:10'),(31,1,29,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:18:10','2026-06-09 03:18:10'),(32,1,29,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:18:10','2026-06-09 03:18:10'),(33,1,29,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:18:10','2026-06-09 03:18:10'),(34,1,29,'due',300.00,1,NULL,0.00,NULL,'2026-06-09 03:18:10','2026-06-09 03:18:10'),(35,1,30,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:19:35','2026-06-09 03:19:35'),(36,1,30,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:19:35','2026-06-09 03:19:35'),(37,1,30,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:19:35','2026-06-09 03:19:35'),(38,1,30,'cash',800.00,0,NULL,0.00,NULL,'2026-06-09 03:19:35','2026-06-09 03:19:35'),(39,1,31,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:22:42','2026-06-09 03:22:42'),(40,1,31,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:22:42','2026-06-09 03:22:42'),(41,1,31,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 03:22:42','2026-06-09 03:22:42'),(42,1,31,'cash',1375.00,0,NULL,0.00,NULL,'2026-06-09 03:22:42','2026-06-09 03:22:42'),(43,1,32,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:24:21','2026-06-09 03:24:21'),(44,1,32,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:24:21','2026-06-09 03:24:21'),(45,1,32,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:24:21','2026-06-09 03:24:21'),(46,1,32,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:24:21','2026-06-09 03:24:21'),(47,1,35,'cash',3685.75,0,NULL,0.00,NULL,'2026-06-09 03:36:50','2026-06-09 03:36:50'),(48,1,36,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:56:07','2026-06-09 03:56:07'),(49,1,23,'cash',575.00,0,NULL,0.00,NULL,'2026-06-09 03:57:26','2026-06-09 03:57:26'),(50,1,37,'cash',69.00,0,NULL,0.00,NULL,'2026-06-09 04:00:53','2026-06-09 04:00:53'),(51,1,37,'cash',69.00,0,NULL,0.00,NULL,'2026-06-09 04:00:53','2026-06-09 04:00:53'),(52,1,38,'cash',287.50,0,NULL,0.00,NULL,'2026-06-09 04:01:17','2026-06-09 04:01:17'),(53,1,38,'cash',287.50,0,NULL,0.00,NULL,'2026-06-09 04:01:17','2026-06-09 04:01:17'),(54,1,40,'cash',1840.00,0,NULL,0.00,NULL,'2026-06-09 04:03:12','2026-06-09 04:03:12'),(55,1,41,'cash',345.00,0,NULL,0.00,NULL,'2026-06-09 04:03:24','2026-06-09 04:03:24'),(56,1,42,'cash',5.75,0,NULL,0.00,NULL,'2026-06-09 04:03:41','2026-06-09 04:03:41'),(57,1,42,'cash',5.75,0,NULL,0.00,NULL,'2026-06-09 04:03:41','2026-06-09 04:03:41'),(58,1,43,'cash',592.25,0,NULL,0.00,NULL,'2026-06-09 04:04:00','2026-06-09 04:04:00'),(60,1,44,'bank_transfer',69.00,0,NULL,0.00,NULL,'2026-06-09 04:05:45','2026-06-09 04:05:45'),(61,1,44,'cash',69.00,0,NULL,0.00,NULL,'2026-06-09 04:05:45','2026-06-09 04:05:45'),(62,1,44,'due',69.00,1,NULL,0.00,NULL,'2026-06-09 04:05:45','2026-06-09 04:05:45'),(63,1,45,'cash',500.00,0,NULL,0.00,NULL,'2026-06-09 04:06:24','2026-06-09 04:06:24'),(65,1,45,'upi',477.50,0,477.50,0.00,NULL,'2026-06-09 04:06:48','2026-06-09 04:06:48'),(66,1,46,'cash',138.00,0,NULL,0.00,NULL,'2026-06-09 04:08:15','2026-06-09 04:08:15'),(67,1,49,'cash',22.00,0,NULL,0.00,NULL,'2026-06-09 04:17:55','2026-06-09 04:17:55'),(68,1,50,'cash',2365.50,0,NULL,0.00,NULL,'2026-06-09 04:22:37','2026-06-09 04:22:37'),(69,1,55,'cash',138.00,0,NULL,0.00,NULL,'2026-06-09 04:42:00','2026-06-09 04:42:00'),(70,1,60,'cash',69.00,0,NULL,0.00,NULL,'2026-06-09 04:49:43','2026-06-09 04:49:43'),(71,1,61,'cash',368.00,0,NULL,0.00,NULL,'2026-06-09 04:51:59','2026-06-09 04:51:59'),(72,1,62,'cash',92.00,0,NULL,0.00,NULL,'2026-06-09 04:53:10','2026-06-09 04:53:10'),(73,1,63,'cash',51.75,0,NULL,0.00,NULL,'2026-06-09 04:54:35','2026-06-09 04:54:35'),(74,1,64,'cash',1345.50,0,NULL,0.00,NULL,'2026-06-09 05:12:01','2026-06-09 05:12:01'),(75,1,65,'cash',977.50,0,NULL,0.00,NULL,'2026-06-09 05:15:46','2026-06-09 05:15:46'),(76,1,66,'cash',407.50,0,NULL,0.00,NULL,'2026-06-09 05:17:42','2026-06-09 05:17:42'),(77,1,67,'cash',207.00,0,NULL,0.00,NULL,'2026-06-09 05:19:41','2026-06-09 05:19:41'),(78,1,69,'cash',379.50,0,NULL,0.00,NULL,'2026-06-09 05:22:11','2026-06-09 05:22:11'),(79,1,70,'cash',2100.00,0,NULL,0.00,NULL,'2026-06-09 22:21:58','2026-06-09 22:21:58'),(80,1,71,'cash',793.50,0,NULL,0.00,NULL,'2026-06-09 22:25:05','2026-06-09 22:25:05'),(81,1,59,'bank_transfer',356.50,0,NULL,0.00,NULL,'2026-06-09 22:54:22','2026-06-09 22:54:22'),(82,1,56,'bank_transfer',138.00,0,NULL,0.00,NULL,'2026-06-09 23:51:01','2026-06-09 23:51:01'),(83,3,72,'card',1380.00,0,NULL,0.00,NULL,'2026-06-10 02:49:21','2026-06-10 02:49:21'),(84,3,73,'cash',661.25,0,NULL,0.00,NULL,'2026-06-10 03:01:46','2026-06-10 03:01:46'),(85,3,75,'cash',943.00,0,NULL,0.00,NULL,'2026-06-10 03:45:56','2026-06-10 03:45:56'),(86,3,76,'cash',1892.55,0,NULL,0.00,NULL,'2026-06-10 03:57:03','2026-06-10 03:57:03'),(87,3,77,'bKash',603.75,0,NULL,0.00,NULL,'2026-06-10 04:06:34','2026-06-10 04:06:34'),(88,1,80,'bKash',1046.50,0,NULL,0.00,NULL,'2026-06-10 04:18:09','2026-06-10 04:18:09'),(89,3,83,'card',989.00,0,NULL,0.00,NULL,'2026-06-10 04:58:53','2026-06-10 04:58:53'),(90,3,85,'cash',201.25,0,NULL,0.00,NULL,'2026-06-10 05:04:06','2026-06-10 05:04:06'),(91,3,87,'card',192.50,0,NULL,0.00,NULL,'2026-06-10 05:24:56','2026-06-10 05:24:56'),(92,3,88,'Nagad',977.50,0,NULL,0.00,NULL,'2026-06-10 05:31:39','2026-06-10 05:31:39'),(93,3,89,'cash',368.00,0,NULL,0.00,NULL,'2026-06-10 05:45:23','2026-06-10 05:45:23'),(94,1,93,'card',92.00,0,NULL,0.00,NULL,'2026-06-10 22:49:25','2026-06-10 22:49:25'),(95,3,96,'cash',977.50,0,NULL,0.00,NULL,'2026-06-10 23:17:08','2026-06-10 23:17:08'),(96,3,97,'cash',368.00,0,NULL,0.00,NULL,'2026-06-10 23:20:17','2026-06-10 23:20:17'),(97,3,98,'card',703.80,0,NULL,0.00,NULL,'2026-06-10 23:23:57','2026-06-10 23:23:57'),(98,3,99,'cash',345.00,0,NULL,0.00,NULL,'2026-06-10 23:26:34','2026-06-10 23:26:34'),(99,3,100,'cash',241.50,0,NULL,0.00,NULL,'2026-06-10 23:28:51','2026-06-10 23:28:51');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_payments`
--

DROP TABLE IF EXISTS `paypal_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paypal_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `paypal_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paypal_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `paypal_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_payments`
--

LOCK TABLES `paypal_payments` WRITE;
/*!40000 ALTER TABLE `paypal_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paystack_payments`
--

DROP TABLE IF EXISTS `paystack_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paystack_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `paystack_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paystack_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `paystack_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paystack_payments`
--

LOCK TABLES `paystack_payments` WRITE;
/*!40000 ALTER TABLE `paystack_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `paystack_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`),
  KEY `permissions_module_id_foreign` (`module_id`),
  CONSTRAINT `permissions_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'App Update','web',1,'2026-06-05 23:44:05','2026-06-05 23:44:05'),(2,'Custom Modules','web',1,'2026-06-05 23:44:05','2026-06-05 23:44:05'),(3,'Create Restaurant','web',2,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(4,'Show Restaurant','web',2,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(5,'Update Restaurant','web',2,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(6,'Delete Restaurant','web',2,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(7,'Show Superadmin Payments','web',3,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(8,'Create Package','web',4,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(9,'Show Package','web',4,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(10,'Update Package','web',4,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(11,'Delete Package','web',4,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(12,'Show Billing','web',5,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(13,'Show Offline Request','web',6,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(14,'Create SuperAdmin','web',7,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(15,'Show SuperAdmin','web',7,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(16,'Update SuperAdmin','web',7,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(17,'Delete SuperAdmin','web',7,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(18,'Show Landing Site','web',8,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(19,'Manage Superadmin Settings','web',9,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(20,'Create Menu','web',10,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(21,'Show Menu','web',10,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(22,'Update Menu','web',10,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(23,'Delete Menu','web',10,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(24,'Create Menu Item','web',11,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(25,'Show Menu Item','web',11,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(26,'Update Menu Item','web',11,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(27,'Delete Menu Item','web',11,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(28,'Export Menu Item','web',11,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(29,'Create Item Category','web',12,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(30,'Show Item Category','web',12,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(31,'Update Item Category','web',12,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(32,'Delete Item Category','web',12,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(33,'Create Area','web',13,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(34,'Show Area','web',13,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(35,'Update Area','web',13,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(36,'Delete Area','web',13,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(37,'Create Table','web',14,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(38,'Show Table','web',14,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(39,'Update Table','web',14,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(40,'Delete Table','web',14,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(41,'Create Reservation','web',15,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(42,'Show Reservation','web',15,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(43,'Update Reservation','web',15,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(44,'Delete Reservation','web',15,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(45,'Manage KOT','web',16,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(46,'Create Order','web',17,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(47,'Show Order','web',17,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(48,'Update Order','web',17,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(49,'Delete Order','web',17,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(50,'Add Discount on POS','web',17,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(51,'Create Customer','web',18,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(52,'Show Customer','web',18,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(53,'Update Customer','web',18,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(54,'Delete Customer','web',18,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(55,'Create Staff Member','web',19,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(56,'Show Staff Member','web',19,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(57,'Update Staff Member','web',19,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(58,'Delete Staff Member','web',19,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(59,'Create Delivery Executive','web',21,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(60,'Show Delivery Executive','web',21,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(61,'Update Delivery Executive','web',21,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(62,'Delete Delivery Executive','web',21,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(63,'Show Payments','web',24,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(64,'Refund Payments','web',24,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(65,'Show Reports','web',20,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(66,'Manage Settings','web',25,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(67,'Show Restaurant Open/Close','web',25,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(68,'Manage Waiter Request','web',22,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(69,'Create Expense','web',23,'2026-06-05 23:44:07','2026-06-05 23:44:07'),(70,'Show Expense','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(71,'Update Expense','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(72,'Delete Expense','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(73,'Create Expense Category','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(74,'Show Expense Category','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(75,'Update Expense Category','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(76,'Delete Expense Category','web',23,'2026-06-05 23:44:08','2026-06-05 23:44:08');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `predefined_amounts`
--

DROP TABLE IF EXISTS `predefined_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `predefined_amounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `predefined_amounts_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `predefined_amounts_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predefined_amounts`
--

LOCK TABLES `predefined_amounts` WRITE;
/*!40000 ALTER TABLE `predefined_amounts` DISABLE KEYS */;
INSERT INTO `predefined_amounts` VALUES (1,1,50.00,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(2,1,100.00,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(3,1,500.00,'2026-06-05 23:44:08','2026-06-05 23:44:08'),(4,1,1000.00,'2026-06-05 23:44:08','2026-06-05 23:44:08');
/*!40000 ALTER TABLE `predefined_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_jobs`
--

DROP TABLE IF EXISTS `print_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `printer_id` bigint unsigned DEFAULT NULL,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `status` enum('done','failed','printing','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `error` text COLLATE utf8mb4_unicode_ci,
  `response_printer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_filename` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `printed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `print_jobs_printer_id_foreign` (`printer_id`),
  KEY `print_jobs_restaurant_id_foreign` (`restaurant_id`),
  KEY `print_jobs_branch_id_foreign` (`branch_id`),
  CONSTRAINT `print_jobs_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `print_jobs_printer_id_foreign` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `print_jobs_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_jobs`
--

LOCK TABLES `print_jobs` WRITE;
/*!40000 ALTER TABLE `print_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `print_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printers`
--

DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `printers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `printing_choice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `print_type` enum('image','pdf') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image',
  `kots` text COLLATE utf8mb4_unicode_ci,
  `orders` text COLLATE utf8mb4_unicode_ci,
  `print_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_qr_code` int DEFAULT NULL,
  `open_cash_drawer` enum('yes','no') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('network','windows','linux','default') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `printer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `printers_restaurant_id_foreign` (`restaurant_id`),
  KEY `printers_branch_id_foreign` (`branch_id`),
  CONSTRAINT `printers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `printers_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printers`
--

LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
INSERT INTO `printers` VALUES (1,1,1,'Default Printer','browserPopupPrint','image','[1]','[1]',NULL,NULL,NULL,NULL,NULL,1,1,NULL,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,2,'Default Printer','browserPopupPrint','image','[2]','[2]',NULL,NULL,NULL,NULL,NULL,1,1,NULL,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,3,'Default Printer','browserPopupPrint','image','[3]','[3]',NULL,NULL,NULL,NULL,NULL,1,1,NULL,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notifications`
--

DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `endpoint` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` text COLLATE utf8mb4_unicode_ci,
  `auth_token` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `push_notifications_endpoint_unique` (`endpoint`),
  KEY `push_notifications_restaurant_id_foreign` (`restaurant_id`),
  KEY `push_notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `push_notifications_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `push_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notifications`
--

LOCK TABLES `push_notifications` WRITE;
/*!40000 ALTER TABLE `push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pusher_settings`
--

DROP TABLE IF EXISTS `pusher_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pusher_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `beamer_status` tinyint(1) NOT NULL DEFAULT '0',
  `instance_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beam_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pusher_broadcast` tinyint(1) NOT NULL DEFAULT '0',
  `pusher_app_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pusher_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pusher_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pusher_cluster` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pusher_settings`
--

LOCK TABLES `pusher_settings` WRITE;
/*!40000 ALTER TABLE `pusher_settings` DISABLE KEYS */;
INSERT INTO `pusher_settings` VALUES (1,0,NULL,NULL,'2026-06-05 23:41:52','2026-06-05 23:41:52',0,NULL,NULL,NULL,NULL),(2,0,NULL,NULL,'2026-06-05 23:44:10','2026-06-05 23:44:10',0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pusher_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `razorpay_payments`
--

DROP TABLE IF EXISTS `razorpay_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `razorpay_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `payment_status` enum('pending','requested','declined','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_error_response` text COLLATE utf8mb4_unicode_ci,
  `razorpay_order_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `razorpay_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `razorpay_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `razorpay_payments`
--

LOCK TABLES `razorpay_payments` WRITE;
/*!40000 ALTER TABLE `razorpay_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `razorpay_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_settings`
--

DROP TABLE IF EXISTS `receipt_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `show_customer_name` tinyint(1) NOT NULL DEFAULT '0',
  `show_customer_address` tinyint(1) NOT NULL DEFAULT '0',
  `show_customer_phone` tinyint(1) NOT NULL DEFAULT '0',
  `show_table_number` tinyint(1) NOT NULL DEFAULT '0',
  `payment_qr_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_payment_qr_code` tinyint(1) NOT NULL DEFAULT '0',
  `show_waiter` tinyint(1) NOT NULL DEFAULT '0',
  `show_total_guest` tinyint(1) NOT NULL DEFAULT '0',
  `show_restaurant_logo` tinyint(1) NOT NULL DEFAULT '0',
  `show_restaurant_name` tinyint(1) NOT NULL DEFAULT '1',
  `show_branch_name` tinyint(1) NOT NULL DEFAULT '0',
  `show_branch_address` tinyint(1) NOT NULL DEFAULT '0',
  `show_cr_number` tinyint(1) NOT NULL DEFAULT '0',
  `show_vat_number` tinyint(1) NOT NULL DEFAULT '0',
  `show_tax` tinyint(1) NOT NULL DEFAULT '0',
  `show_payment_details` tinyint(1) NOT NULL DEFAULT '1',
  `show_payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `show_order_type` tinyint(1) DEFAULT '0',
  `receipt_languages` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receipt_settings_restaurant_id_foreign` (`restaurant_id`),
  KEY `receipt_settings_branch_id_foreign` (`branch_id`),
  CONSTRAINT `receipt_settings_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `receipt_settings_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_settings`
--

LOCK TABLES `receipt_settings` WRITE;
/*!40000 ALTER TABLE `receipt_settings` DISABLE KEYS */;
INSERT INTO `receipt_settings` VALUES (1,1,1,1,0,1,0,NULL,0,0,0,1,1,1,1,0,0,0,1,0,0,NULL,'2026-06-05 23:44:08','2026-06-09 06:07:53'),(2,1,2,0,0,0,0,NULL,0,0,0,0,1,0,0,0,0,0,1,0,0,NULL,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,3,1,0,1,0,NULL,0,0,0,1,1,1,0,1,1,1,1,0,0,NULL,'2026-06-10 00:34:49','2026-06-10 02:21:20');
/*!40000 ALTER TABLE `receipt_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_reasons`
--

DROP TABLE IF EXISTS `refund_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_reasons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refund_reasons_branch_id_foreign` (`branch_id`),
  CONSTRAINT `refund_reasons_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_reasons`
--

LOCK TABLES `refund_reasons` WRITE;
/*!40000 ALTER TABLE `refund_reasons` DISABLE KEYS */;
INSERT INTO `refund_reasons` VALUES (1,1,'The item was prepared but returned by the customer.','2026-06-05 23:44:12','2026-06-05 23:44:12'),(2,1,'The item was delivered but rejected.','2026-06-05 23:44:12','2026-06-05 23:44:12'),(3,1,'A mistake in the order.','2026-06-05 23:44:12','2026-06-05 23:44:12'),(4,1,'Product quality issue.','2026-06-05 23:44:12','2026-06-05 23:44:12'),(5,3,'The food was not Fresh.','2026-06-10 02:24:47','2026-06-10 02:24:47');
/*!40000 ALTER TABLE `refund_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refunds`
--

DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refunds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `payment_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `delivery_app_id` bigint unsigned DEFAULT NULL,
  `refund_reason_id` bigint unsigned DEFAULT NULL,
  `refund_type` enum('full','partial','waste') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full',
  `partial_refund_type` enum('half','fixed','custom') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(16,2) NOT NULL,
  `commission_adjustment` decimal(16,2) DEFAULT NULL,
  `status` enum('pending','processed','failed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `processed_by` bigint unsigned DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refunds_branch_id_foreign` (`branch_id`),
  KEY `refunds_payment_id_foreign` (`payment_id`),
  KEY `refunds_order_id_foreign` (`order_id`),
  KEY `refunds_delivery_app_id_foreign` (`delivery_app_id`),
  KEY `refunds_refund_reason_id_foreign` (`refund_reason_id`),
  KEY `refunds_processed_by_foreign` (`processed_by`),
  CONSTRAINT `refunds_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `refunds_delivery_app_id_foreign` FOREIGN KEY (`delivery_app_id`) REFERENCES `delivery_platforms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `refunds_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `refunds_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `refunds_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `refunds_refund_reason_id_foreign` FOREIGN KEY (`refund_reason_id`) REFERENCES `refund_reasons` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refunds`
--

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_settings`
--

DROP TABLE IF EXISTS `reservation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_slot_start` time NOT NULL,
  `time_slot_end` time NOT NULL,
  `time_slot_difference` int NOT NULL,
  `slot_type` enum('Breakfast','Lunch','Dinner') COLLATE utf8mb4_unicode_ci NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservation_settings_branch_id_foreign` (`branch_id`),
  CONSTRAINT `reservation_settings_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_settings`
--

LOCK TABLES `reservation_settings` WRITE;
/*!40000 ALTER TABLE `reservation_settings` DISABLE KEYS */;
INSERT INTO `reservation_settings` VALUES (1,1,'Monday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(2,1,'Monday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(3,1,'Monday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(4,1,'Tuesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(5,1,'Tuesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(6,1,'Tuesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(7,1,'Wednesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(8,1,'Wednesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(9,1,'Wednesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(10,1,'Thursday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(11,1,'Thursday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(12,1,'Thursday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(13,1,'Friday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(14,1,'Friday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(15,1,'Friday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(16,1,'Saturday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(17,1,'Saturday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(18,1,'Saturday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(19,1,'Sunday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(20,1,'Sunday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(21,1,'Sunday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(22,2,'Monday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(23,2,'Monday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(24,2,'Monday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(25,2,'Tuesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(26,2,'Tuesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(27,2,'Tuesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(28,2,'Wednesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(29,2,'Wednesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(30,2,'Wednesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(31,2,'Thursday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(32,2,'Thursday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(33,2,'Thursday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(34,2,'Friday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(35,2,'Friday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(36,2,'Friday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(37,2,'Saturday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(38,2,'Saturday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(39,2,'Saturday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(40,2,'Sunday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(41,2,'Sunday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(42,2,'Sunday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:09','2026-06-05 23:44:09'),(43,1,'Monday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(44,1,'Monday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(45,1,'Monday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(46,1,'Tuesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(47,1,'Tuesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(48,1,'Tuesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(49,1,'Wednesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(50,1,'Wednesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(51,1,'Wednesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(52,1,'Thursday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(53,1,'Thursday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(54,1,'Thursday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(55,1,'Friday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(56,1,'Friday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(57,1,'Friday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(58,1,'Saturday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(59,1,'Saturday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(60,1,'Saturday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(61,1,'Sunday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(62,1,'Sunday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(63,1,'Sunday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-05 23:44:12','2026-06-05 23:44:12'),(64,3,'Monday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(65,3,'Monday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(66,3,'Monday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(67,3,'Tuesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(68,3,'Tuesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(69,3,'Tuesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(70,3,'Wednesday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(71,3,'Wednesday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(72,3,'Wednesday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(73,3,'Thursday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(74,3,'Thursday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(75,3,'Thursday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(76,3,'Friday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(77,3,'Friday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(78,3,'Friday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(79,3,'Saturday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(80,3,'Saturday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(81,3,'Saturday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(82,3,'Sunday','08:00:00','11:00:00',30,'Breakfast',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(83,3,'Sunday','12:00:00','17:00:00',60,'Lunch',1,'2026-06-10 00:34:49','2026-06-10 00:34:49'),(84,3,'Sunday','18:00:00','22:00:00',60,'Dinner',1,'2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `reservation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `table_id` bigint unsigned DEFAULT NULL,
  `area_id` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `reservation_date_time` datetime NOT NULL,
  `party_size` int NOT NULL,
  `special_requests` text COLLATE utf8mb4_unicode_ci,
  `reservation_status` enum('Pending','Confirmed','Checked_In','Cancelled','No_Show') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Confirmed',
  `reservation_slot_type` enum('Breakfast','Lunch','Dinner') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slot_time_difference` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservations_table_id_foreign` (`table_id`),
  KEY `reservations_customer_id_foreign` (`customer_id`),
  KEY `reservations_branch_id_foreign` (`branch_id`),
  KEY `reservations_area_id_foreign` (`area_id`),
  CONSTRAINT `reservations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservations_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reservations_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `reservations_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (1,3,5,3,NULL,'2026-06-11 09:00:00',5,'Vip','Confirmed','Breakfast','2026-06-10 04:16:52','2026-06-10 04:19:04',NULL),(2,3,7,3,21,'2026-06-11 20:00:00',5,'ConFirm','Confirmed','Dinner','2026-06-10 05:09:45','2026-06-10 23:06:41',NULL),(3,3,9,4,31,'2026-06-11 21:00:00',4,'Sure','Confirmed','Dinner','2026-06-10 23:05:49','2026-06-10 23:06:23',NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_charges`
--

DROP TABLE IF EXISTS `restaurant_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_charges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `charge_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `charge_type` enum('percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `charge_value` decimal(16,2) DEFAULT NULL,
  `order_types` json NOT NULL COMMENT 'Supported order types: DineIn, Delivery, PickUp',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restaurant_charges_restaurant_id_foreign` (`restaurant_id`),
  KEY `restaurant_charges_charge_name_index` (`charge_name`),
  CONSTRAINT `restaurant_charges_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_charges`
--

LOCK TABLES `restaurant_charges` WRITE;
/*!40000 ALTER TABLE `restaurant_charges` DISABLE KEYS */;
INSERT INTO `restaurant_charges` VALUES (1,1,'VAT','percent',5.00,'[\"dine_in\", \"delivery\", \"pickup\"]',1,'2026-06-06 05:22:26','2026-06-06 05:22:26');
/*!40000 ALTER TABLE `restaurant_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_eu_allergen_settings`
--

DROP TABLE IF EXISTS `restaurant_eu_allergen_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_eu_allergen_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `allergen_keys` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `restaurant_eu_allergen_settings_restaurant_id_unique` (`restaurant_id`),
  CONSTRAINT `restaurant_eu_allergen_settings_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_eu_allergen_settings`
--

LOCK TABLES `restaurant_eu_allergen_settings` WRITE;
/*!40000 ALTER TABLE `restaurant_eu_allergen_settings` DISABLE KEYS */;
INSERT INTO `restaurant_eu_allergen_settings` VALUES (1,1,1,'[\"wheat\", \"crustacens\", \"eggs\", \"fish\", \"peanut\", \"soya\", \"milk\", \"treenut\", \"celery\", \"mustard\", \"sesame\", \"lupin\", \"molluscs\", \"sulphurdioxide\"]','2026-06-05 23:44:08','2026-06-09 06:02:19');
/*!40000 ALTER TABLE `restaurant_eu_allergen_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_payments`
--

DROP TABLE IF EXISTS `restaurant_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `status` enum('pending','paid','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_source` enum('official_site','app_sumo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'official_site',
  `razorpay_order_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_date_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stripe_payment_intent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_session_id` text COLLATE utf8mb4_unicode_ci,
  `package_id` bigint unsigned DEFAULT NULL,
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flutterwave_payment_ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mollie_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mollie_customer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mollie_subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restaurant_payments_restaurant_id_foreign` (`restaurant_id`),
  KEY `restaurant_payments_package_id_foreign` (`package_id`),
  CONSTRAINT `restaurant_payments_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `restaurant_payments_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_payments`
--

LOCK TABLES `restaurant_payments` WRITE;
/*!40000 ALTER TABLE `restaurant_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_taxes`
--

DROP TABLE IF EXISTS `restaurant_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned NOT NULL,
  `tax_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restaurant_taxes_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `restaurant_taxes_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_taxes`
--

LOCK TABLES `restaurant_taxes` WRITE;
/*!40000 ALTER TABLE `restaurant_taxes` DISABLE KEYS */;
INSERT INTO `restaurant_taxes` VALUES (1,1,'436252834961','TIN','2026-06-09 03:06:00','2026-06-09 03:06:00');
/*!40000 ALTER TABLE `restaurant_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'h:i A',
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'd/m/Y',
  `theme_hex` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme_rgb` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dark_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` bigint unsigned NOT NULL,
  `hide_new_orders` tinyint(1) NOT NULL DEFAULT '0',
  `hide_new_reservations` tinyint(1) NOT NULL DEFAULT '0',
  `hide_new_waiter_request` tinyint(1) NOT NULL DEFAULT '0',
  `currency_id` bigint unsigned DEFAULT NULL,
  `license_type` enum('free','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `customer_login_required` tinyint(1) NOT NULL DEFAULT '0',
  `about_us` longtext COLLATE utf8mb4_unicode_ci,
  `allow_customer_delivery_orders` tinyint(1) NOT NULL DEFAULT '1',
  `allow_customer_pickup_orders` tinyint(1) NOT NULL DEFAULT '1',
  `pickup_days_range` int DEFAULT '7',
  `allow_customer_orders` tinyint(1) NOT NULL DEFAULT '1',
  `allow_dine_in_orders` tinyint(1) NOT NULL DEFAULT '1',
  `show_veg` tinyint(1) NOT NULL DEFAULT '1',
  `show_halal` tinyint(1) NOT NULL DEFAULT '0',
  `package_id` bigint unsigned DEFAULT NULL,
  `package_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','license_expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `license_expire_on` datetime DEFAULT NULL,
  `trial_ends_at` datetime DEFAULT NULL,
  `license_updated_at` datetime DEFAULT NULL,
  `subscription_updated_at` datetime DEFAULT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_waiter_request_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `default_table_reservation_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Confirmed',
  `disable_slot_minutes` int NOT NULL DEFAULT '30',
  `approval_status` enum('Pending','Approved','Rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Approved',
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yelp_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_business_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wifi_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wifi_password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_wifi_icon` tinyint(1) NOT NULL DEFAULT '0',
  `table_required` tinyint(1) NOT NULL DEFAULT '0',
  `show_logo_text` tinyint(1) NOT NULL DEFAULT '1',
  `meta_keyword` text COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `upload_fav_icon_android_chrome_192` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_fav_icon_android_chrome_512` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_fav_icon_apple_touch_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_favicon_16` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_favicon_32` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_waiter_request_enabled_on_desktop` tinyint(1) NOT NULL DEFAULT '1',
  `is_waiter_request_enabled_on_mobile` tinyint(1) NOT NULL DEFAULT '1',
  `is_waiter_request_enabled_open_by_qr` tinyint(1) NOT NULL DEFAULT '0',
  `webmanifest` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_tip_shop` tinyint(1) NOT NULL DEFAULT '1',
  `enable_tip_pos` tinyint(1) NOT NULL DEFAULT '1',
  `is_pwa_install_alert_show` tinyint(1) NOT NULL DEFAULT '0',
  `auto_confirm_orders` tinyint(1) NOT NULL DEFAULT '0',
  `auto_confirm_orders_before_payment` tinyint(1) NOT NULL DEFAULT '0',
  `auto_confirm_orders_after_payment` tinyint(1) NOT NULL DEFAULT '0',
  `restrict_qr_order_by_location` tinyint(1) NOT NULL DEFAULT '0',
  `qr_order_radius_meters` int unsigned DEFAULT NULL,
  `show_order_type_options` tinyint(1) NOT NULL DEFAULT '1',
  `disable_order_type_popup` tinyint(1) NOT NULL DEFAULT '0',
  `restaurant_open_close_mode` enum('auto','manual') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `restaurant_manual_open_close_type` enum('time','toggle') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'time',
  `manual_open_time` time DEFAULT NULL,
  `manual_close_time` time DEFAULT NULL,
  `is_temporarily_closed` tinyint(1) NOT NULL DEFAULT '0',
  `default_order_type_id` bigint unsigned DEFAULT NULL,
  `hide_menu_item_image_on_pos` tinyint(1) NOT NULL DEFAULT '0',
  `hide_menu_item_image_on_customer_site` tinyint(1) NOT NULL DEFAULT '0',
  `menu_item_default_image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disable_menu_item_default_image` tinyint(1) NOT NULL DEFAULT '0',
  `tax_mode` enum('order','item') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'order',
  `tax_inclusive` tinyint(1) NOT NULL DEFAULT '0',
  `include_charges_in_tax_base` tinyint(1) NOT NULL DEFAULT '0',
  `customer_site_language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_admin_reservation` tinyint(1) NOT NULL DEFAULT '1',
  `enable_customer_reservation` tinyint(1) NOT NULL DEFAULT '1',
  `minimum_party_size` int NOT NULL DEFAULT '1',
  `table_lock_timeout_minutes` int NOT NULL DEFAULT '10',
  `mollie_customer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_mark_order_completed_on_paid` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `restaurant_settings_country_id_foreign` (`country_id`),
  KEY `restaurant_settings_currency_id_foreign` (`currency_id`),
  KEY `restaurants_package_id_foreign` (`package_id`),
  KEY `restaurants_default_order_type_id_foreign` (`default_order_type_id`),
  CONSTRAINT `restaurant_settings_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `restaurant_settings_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `restaurants_default_order_type_id_foreign` FOREIGN KEY (`default_order_type_id`) REFERENCES `order_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `restaurants_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` VALUES (1,'Restaurant','restaurant','45, MI Road, C Scheme, Jaipur, Rajasthan 302001, India','14698455822','880','demo.restaurant@example.com','Asia/Dhaka','h:i A','d/m/Y','#F97316','249, 115, 22','fcff797d7f67ab0071ef70ad5aa8dafd.jpeg',NULL,19,0,0,0,5,'free',1,'2026-06-05 23:44:08','2026-06-10 02:19:58',0,'<div>&nbsp;Welcome to <strong>Sultan Dine</strong>, the ultimate destination for authentic, premium <strong>Sultan Dine</strong>! We take pride in using traditional cooking methods, slow-cooking tender mutton and aromatic basmati rice to perfection with secret spices. Whether you\'re dining in with family or ordering a feast at home, we promise an unforgettable taste of tradition. Come visit us or order online today!&nbsp;</div>',1,1,7,1,1,1,0,3,'lifetime','active',NULL,NULL,'2026-06-06 05:44:08','2026-06-06 05:44:08',NULL,NULL,NULL,1,'Confirmed',30,'Approved',NULL,'https://www.facebook.com/','https://www.instagram.com/','https://www.twitter.com/',NULL,'https://business.google.com/',NULL,NULL,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,1,1,0,0,0,0,0,NULL,1,0,'auto','time',NULL,NULL,0,NULL,0,0,NULL,0,'order',0,0,'en',1,1,1,10,NULL,1);
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2),(40,2),(41,2),(42,2),(43,2),(44,2),(45,2),(46,2),(47,2),(48,2),(49,2),(50,2),(51,2),(52,2),(53,2),(54,2),(55,2),(56,2),(57,2),(58,2),(59,2),(60,2),(61,2),(62,2),(63,2),(64,2),(65,2),(66,2),(67,2),(68,2),(69,2),(70,2),(71,2),(72,2),(73,2),(74,2),(75,2),(76,2),(20,3),(21,3),(22,3),(23,3),(24,3),(25,3),(26,3),(27,3),(28,3),(29,3),(30,3),(31,3),(32,3),(33,3),(34,3),(35,3),(36,3),(37,3),(38,3),(39,3),(40,3),(41,3),(42,3),(43,3),(44,3),(45,3),(46,3),(47,3),(48,3),(49,3),(50,3),(51,3),(52,3),(53,3),(54,3),(55,3),(56,3),(57,3),(58,3),(59,3),(60,3),(61,3),(62,3),(63,3),(64,3),(65,3),(66,3),(67,3),(68,3),(69,3),(70,3),(71,3),(72,3),(73,3),(74,3),(75,3),(76,3),(38,4),(41,4),(42,4),(43,4),(44,4),(46,4),(47,4),(48,4),(49,4),(50,4),(51,4),(52,4),(53,4),(54,4),(60,4),(68,4),(21,5),(25,5),(26,5),(30,5),(31,5),(38,5),(42,5),(45,5);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`),
  KEY `roles_restaurant_id_foreign` (`restaurant_id`),
  CONSTRAINT `roles_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','Super Admin','web','2026-06-05 23:44:08','2026-06-05 23:44:08',NULL),(2,'Admin_1','Admin','web','2026-06-05 23:44:10','2026-06-05 23:44:10',1),(3,'Branch Head_1','Branch Head','web','2026-06-05 23:44:10','2026-06-05 23:44:10',1),(4,'Waiter_1','Waiter','web','2026-06-05 23:44:10','2026-06-05 23:44:10',1),(5,'Chef_1','Chef','web','2026-06-05 23:44:10','2026-06-05 23:44:10',1),(6,'demo 01','demo 01','web','2026-06-10 03:17:18','2026-06-10 03:17:18',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('nokJbEGmeKGl9gGxMBKmcMEnloLaqBmsBRbQV87v',2,'103.119.102.11','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','YToyMjp7czo2OiJfdG9rZW4iO3M6NDA6ImZDamtyalpPNFQ1Ujh0WWxUVkZVQ3ZWTHFOV0tpakVubXR0NTVZZHEiO3M6MjA6ImNoZWNrX21pZ3JhdGVfc3RhdHVzIjtzOjQ6Ikdvb2QiO3M6MTU6ImN1c3RvbWVyX2lzX3J0bCI7aTowO3M6MzE6Imdsb2JhbF9jdXJyZW5jeV9mb3JtYXRfc2V0dGluZzEiO086MjU6IkFwcFxNb2RlbHNcR2xvYmFsQ3VycmVuY3kiOjM0OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjE3OiJnbG9iYWxfY3VycmVuY2llcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjE1OntzOjI6ImlkIjtpOjE7czoxMzoiY3VycmVuY3lfbmFtZSI7czo3OiJEb2xsYXJzIjtzOjE1OiJjdXJyZW5jeV9zeW1ib2wiO3M6MToiJCI7czoxMzoiY3VycmVuY3lfY29kZSI7czozOiJVU0QiO3M6MTM6ImV4Y2hhbmdlX3JhdGUiO047czo5OiJ1c2RfcHJpY2UiO047czoxNzoiaXNfY3J5cHRvY3VycmVuY3kiO3M6Mjoibm8iO3M6MTc6ImN1cnJlbmN5X3Bvc2l0aW9uIjtzOjQ6ImxlZnQiO3M6MTM6Im5vX29mX2RlY2ltYWwiO2k6MjtzOjE4OiJ0aG91c2FuZF9zZXBhcmF0b3IiO3M6MToiLCI7czoxNzoiZGVjaW1hbF9zZXBhcmF0b3IiO3M6MToiLiI7czo2OiJzdGF0dXMiO3M6NjoiZW5hYmxlIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQxOjUyIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQxOjUyIjtzOjEwOiJkZWxldGVkX2F0IjtOO31zOjExOiIAKgBvcmlnaW5hbCI7YToxNTp7czoyOiJpZCI7aToxO3M6MTM6ImN1cnJlbmN5X25hbWUiO3M6NzoiRG9sbGFycyI7czoxNToiY3VycmVuY3lfc3ltYm9sIjtzOjE6IiQiO3M6MTM6ImN1cnJlbmN5X2NvZGUiO3M6MzoiVVNEIjtzOjEzOiJleGNoYW5nZV9yYXRlIjtOO3M6OToidXNkX3ByaWNlIjtOO3M6MTc6ImlzX2NyeXB0b2N1cnJlbmN5IjtzOjI6Im5vIjtzOjE3OiJjdXJyZW5jeV9wb3NpdGlvbiI7czo0OiJsZWZ0IjtzOjEzOiJub19vZl9kZWNpbWFsIjtpOjI7czoxODoidGhvdXNhbmRfc2VwYXJhdG9yIjtzOjE6IiwiO3M6MTc6ImRlY2ltYWxfc2VwYXJhdG9yIjtzOjE6Ii4iO3M6Njoic3RhdHVzIjtzOjY6ImVuYWJsZSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0MTo1MiI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0MTo1MiI7czoxMDoiZGVsZXRlZF9hdCI7Tjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6Mjp7czoxNzoiaXNfY3J5cHRvY3VycmVuY3kiO3M6NzoiYm9vbGVhbiI7czoxMDoiZGVsZXRlZF9hdCI7czo4OiJkYXRldGltZSI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjExOntpOjA7czoxMzoiY3VycmVuY3lfbmFtZSI7aToxO3M6MTU6ImN1cnJlbmN5X3N5bWJvbCI7aToyO3M6MTM6ImN1cnJlbmN5X2NvZGUiO2k6MztzOjEzOiJleGNoYW5nZV9yYXRlIjtpOjQ7czo5OiJ1c2RfcHJpY2UiO2k6NTtzOjE3OiJpc19jcnlwdG9jdXJyZW5jeSI7aTo2O3M6MTc6ImN1cnJlbmN5X3Bvc2l0aW9uIjtpOjc7czoxMzoibm9fb2ZfZGVjaW1hbCI7aTo4O3M6MTg6InRob3VzYW5kX3NlcGFyYXRvciI7aTo5O3M6MTc6ImRlY2ltYWxfc2VwYXJhdG9yIjtpOjEwO3M6Njoic3RhdHVzIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9czoxNjoiACoAZm9yY2VEZWxldGluZyI7YjowO31zOjQ6InVzZXIiO086MTU6IkFwcFxNb2RlbHNcVXNlciI6MzY6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToibXlzcWwiO3M6ODoiACoAdGFibGUiO3M6NToidXNlcnMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToyNDp7czoyOiJpZCI7aToyO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjk6ImJyYW5jaF9pZCI7TjtzOjQ6Im5hbWUiO3M6ODoiSm9obiBEb2UiO3M6NToiZW1haWwiO3M6MTc6ImFkbWluQGV4YW1wbGUuY29tIjtzOjEyOiJwaG9uZV9udW1iZXIiO047czoxMDoicGhvbmVfY29kZSI7TjtzOjI2OiJ0ZXJtc19hbmRfcHJpdmFjeV9hY2NlcHRlZCI7aTowO3M6MjU6Im1hcmtldGluZ19lbWFpbHNfYWNjZXB0ZWQiO2k6MDtzOjE3OiJlbWFpbF92ZXJpZmllZF9hdCI7TjtzOjg6InBhc3N3b3JkIjtzOjYwOiIkMnkkMTIkZE9pbk5jU0M1SjZIZmdBS3ByLlVvLmhRdVR1dm9aTW5zMENXN3EvR2FzTm92LlE5Lkp2bHkiO3M6MTc6InR3b19mYWN0b3Jfc2VjcmV0IjtOO3M6MjU6InR3b19mYWN0b3JfcmVjb3ZlcnlfY29kZXMiO047czoyMzoidHdvX2ZhY3Rvcl9jb25maXJtZWRfYXQiO047czoxNDoicmVtZW1iZXJfdG9rZW4iO3M6NjA6IkhBR3A5ZlRCaFNockRYdTFZYUN5NlZzclg4WnpwMWJOOGUzelBtRTQ2azhkY0Zkek9tcExVVFRpT21rTSI7czoxNToiY3VycmVudF90ZWFtX2lkIjtOO3M6MTg6InByb2ZpbGVfcGhvdG9fcGF0aCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjEwIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjEwIjtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo5OiJzdHJpcGVfaWQiO047czo3OiJwbV90eXBlIjtOO3M6MTI6InBtX2xhc3RfZm91ciI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO31zOjExOiIAKgBvcmlnaW5hbCI7YToyNDp7czoyOiJpZCI7aToyO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjk6ImJyYW5jaF9pZCI7TjtzOjQ6Im5hbWUiO3M6ODoiSm9obiBEb2UiO3M6NToiZW1haWwiO3M6MTc6ImFkbWluQGV4YW1wbGUuY29tIjtzOjEyOiJwaG9uZV9udW1iZXIiO047czoxMDoicGhvbmVfY29kZSI7TjtzOjI2OiJ0ZXJtc19hbmRfcHJpdmFjeV9hY2NlcHRlZCI7aTowO3M6MjU6Im1hcmtldGluZ19lbWFpbHNfYWNjZXB0ZWQiO2k6MDtzOjE3OiJlbWFpbF92ZXJpZmllZF9hdCI7TjtzOjg6InBhc3N3b3JkIjtzOjYwOiIkMnkkMTIkZE9pbk5jU0M1SjZIZmdBS3ByLlVvLmhRdVR1dm9aTW5zMENXN3EvR2FzTm92LlE5Lkp2bHkiO3M6MTc6InR3b19mYWN0b3Jfc2VjcmV0IjtOO3M6MjU6InR3b19mYWN0b3JfcmVjb3ZlcnlfY29kZXMiO047czoyMzoidHdvX2ZhY3Rvcl9jb25maXJtZWRfYXQiO047czoxNDoicmVtZW1iZXJfdG9rZW4iO3M6NjA6IkhBR3A5ZlRCaFNockRYdTFZYUN5NlZzclg4WnpwMWJOOGUzelBtRTQ2azhkY0Zkek9tcExVVFRpT21rTSI7czoxNToiY3VycmVudF90ZWFtX2lkIjtOO3M6MTg6InByb2ZpbGVfcGhvdG9fcGF0aCI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjEwIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjEwIjtzOjY6ImxvY2FsZSI7czoyOiJlbiI7czo5OiJzdHJpcGVfaWQiO047czo3OiJwbV90eXBlIjtOO3M6MTI6InBtX2xhc3RfZm91ciI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YTo2OntzOjE3OiJlbWFpbF92ZXJpZmllZF9hdCI7czo4OiJkYXRldGltZSI7czo4OiJwYXNzd29yZCI7czo2OiJoYXNoZWQiO3M6MTM6InJlc3RhdXJhbnRfaWQiO3M6NzoiaW50ZWdlciI7czo5OiJicmFuY2hfaWQiO3M6NzoiaW50ZWdlciI7czoyNjoidGVybXNfYW5kX3ByaXZhY3lfYWNjZXB0ZWQiO3M6NzoiYm9vbGVhbiI7czoyNToibWFya2V0aW5nX2VtYWlsc19hY2NlcHRlZCI7czo3OiJib29sZWFuIjt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjE6e2k6MDtzOjE3OiJwcm9maWxlX3Bob3RvX3VybCI7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6Mzp7czoxMDoicmVzdGF1cmFudCI7TzoyMToiQXBwXE1vZGVsc1xSZXN0YXVyYW50IjozOTp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czoxMToicmVzdGF1cmFudHMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo5OTp7czoyOiJpZCI7aToxO3M6NDoibmFtZSI7czoxMDoiUmVzdGF1cmFudCI7czo0OiJoYXNoIjtzOjEwOiJyZXN0YXVyYW50IjtzOjc6ImFkZHJlc3MiO3M6NTQ6IjQ1LCBNSSBSb2FkLCBDIFNjaGVtZSwgSmFpcHVyLCBSYWphc3RoYW4gMzAyMDAxLCBJbmRpYSI7czoxMjoicGhvbmVfbnVtYmVyIjtpOjE0Njk4NDU1ODIyO3M6MTA6InBob25lX2NvZGUiO2k6ODgwO3M6NToiZW1haWwiO3M6Mjc6ImRlbW8ucmVzdGF1cmFudEBleGFtcGxlLmNvbSI7czo4OiJ0aW1lem9uZSI7czoxMDoiQXNpYS9EaGFrYSI7czoxMToidGltZV9mb3JtYXQiO3M6NToiaDppIEEiO3M6MTE6ImRhdGVfZm9ybWF0IjtzOjU6ImQvbS9ZIjtzOjk6InRoZW1lX2hleCI7czo3OiIjRjk3MzE2IjtzOjk6InRoZW1lX3JnYiI7czoxMjoiMjQ5LCAxMTUsIDIyIjtzOjQ6ImxvZ28iO3M6Mzc6ImZjZmY3OTdkN2Y2N2FiMDA3MWVmNzBhZDVhYThkYWZkLmpwZWciO3M6OToiZGFya19sb2dvIjtOO3M6MTA6ImNvdW50cnlfaWQiO2k6MTk7czoxNToiaGlkZV9uZXdfb3JkZXJzIjtpOjA7czoyMToiaGlkZV9uZXdfcmVzZXJ2YXRpb25zIjtpOjA7czoyMzoiaGlkZV9uZXdfd2FpdGVyX3JlcXVlc3QiO2k6MDtzOjExOiJjdXJyZW5jeV9pZCI7aTo1O3M6MTI6ImxpY2Vuc2VfdHlwZSI7czo0OiJmcmVlIjtzOjk6ImlzX2FjdGl2ZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDg6MTk6NTgiO3M6MjM6ImN1c3RvbWVyX2xvZ2luX3JlcXVpcmVkIjtpOjA7czo4OiJhYm91dF91cyI7czo0MzE6IjxkaXY+Jm5ic3A7V2VsY29tZSB0byA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+LCB0aGUgdWx0aW1hdGUgZGVzdGluYXRpb24gZm9yIGF1dGhlbnRpYywgcHJlbWl1bSA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+ISBXZSB0YWtlIHByaWRlIGluIHVzaW5nIHRyYWRpdGlvbmFsIGNvb2tpbmcgbWV0aG9kcywgc2xvdy1jb29raW5nIHRlbmRlciBtdXR0b24gYW5kIGFyb21hdGljIGJhc21hdGkgcmljZSB0byBwZXJmZWN0aW9uIHdpdGggc2VjcmV0IHNwaWNlcy4gV2hldGhlciB5b3UncmUgZGluaW5nIGluIHdpdGggZmFtaWx5IG9yIG9yZGVyaW5nIGEgZmVhc3QgYXQgaG9tZSwgd2UgcHJvbWlzZSBhbiB1bmZvcmdldHRhYmxlIHRhc3RlIG9mIHRyYWRpdGlvbi4gQ29tZSB2aXNpdCB1cyBvciBvcmRlciBvbmxpbmUgdG9kYXkhJm5ic3A7PC9kaXY+IjtzOjMwOiJhbGxvd19jdXN0b21lcl9kZWxpdmVyeV9vcmRlcnMiO2k6MTtzOjI4OiJhbGxvd19jdXN0b21lcl9waWNrdXBfb3JkZXJzIjtpOjE7czoxNzoicGlja3VwX2RheXNfcmFuZ2UiO2k6NztzOjIxOiJhbGxvd19jdXN0b21lcl9vcmRlcnMiO2k6MTtzOjIwOiJhbGxvd19kaW5lX2luX29yZGVycyI7aToxO3M6ODoic2hvd192ZWciO2k6MTtzOjEwOiJzaG93X2hhbGFsIjtpOjA7czoxMDoicGFja2FnZV9pZCI7aTozO3M6MTI6InBhY2thZ2VfdHlwZSI7czo4OiJsaWZldGltZSI7czo2OiJzdGF0dXMiO3M6NjoiYWN0aXZlIjtzOjE3OiJsaWNlbnNlX2V4cGlyZV9vbiI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6OToic3RyaXBlX2lkIjtOO3M6NzoicG1fdHlwZSI7TjtzOjEyOiJwbV9sYXN0X2ZvdXIiO047czoyNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZCI7aToxO3M6MzI6ImRlZmF1bHRfdGFibGVfcmVzZXJ2YXRpb25fc3RhdHVzIjtzOjk6IkNvbmZpcm1lZCI7czoyMDoiZGlzYWJsZV9zbG90X21pbnV0ZXMiO2k6MzA7czoxNToiYXBwcm92YWxfc3RhdHVzIjtzOjg6IkFwcHJvdmVkIjtzOjE2OiJyZWplY3Rpb25fcmVhc29uIjtOO3M6MTM6ImZhY2Vib29rX2xpbmsiO3M6MjU6Imh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS8iO3M6MTQ6Imluc3RhZ3JhbV9saW5rIjtzOjI2OiJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tLyI7czoxMjoidHdpdHRlcl9saW5rIjtzOjI0OiJodHRwczovL3d3dy50d2l0dGVyLmNvbS8iO3M6OToieWVscF9saW5rIjtOO3M6MjA6Imdvb2dsZV9idXNpbmVzc19saW5rIjtzOjI4OiJodHRwczovL2J1c2luZXNzLmdvb2dsZS5jb20vIjtzOjk6IndpZmlfbmFtZSI7TjtzOjEzOiJ3aWZpX3Bhc3N3b3JkIjtOO3M6MTQ6InNob3dfd2lmaV9pY29uIjtpOjA7czoxNDoidGFibGVfcmVxdWlyZWQiO2k6MDtzOjE0OiJzaG93X2xvZ29fdGV4dCI7aToxO3M6MTI6Im1ldGFfa2V5d29yZCI7TjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtOO3M6MzQ6InVwbG9hZF9mYXZfaWNvbl9hbmRyb2lkX2Nocm9tZV8xOTIiO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzUxMiI7TjtzOjMyOiJ1cGxvYWRfZmF2X2ljb25fYXBwbGVfdG91Y2hfaWNvbiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8xNiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8zMiI7TjtzOjc6ImZhdmljb24iO047czozNjoiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9kZXNrdG9wIjtpOjE7czozNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9tb2JpbGUiO2k6MTtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29wZW5fYnlfcXIiO2k6MDtzOjExOiJ3ZWJtYW5pZmVzdCI7TjtzOjE1OiJlbmFibGVfdGlwX3Nob3AiO2k6MTtzOjE0OiJlbmFibGVfdGlwX3BvcyI7aToxO3M6MjU6ImlzX3B3YV9pbnN0YWxsX2FsZXJ0X3Nob3ciO2k6MDtzOjE5OiJhdXRvX2NvbmZpcm1fb3JkZXJzIjtpOjA7czozNDoiYXV0b19jb25maXJtX29yZGVyc19iZWZvcmVfcGF5bWVudCI7aTowO3M6MzM6ImF1dG9fY29uZmlybV9vcmRlcnNfYWZ0ZXJfcGF5bWVudCI7aTowO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtpOjA7czoyMjoicXJfb3JkZXJfcmFkaXVzX21ldGVycyI7TjtzOjIzOiJzaG93X29yZGVyX3R5cGVfb3B0aW9ucyI7aToxO3M6MjQ6ImRpc2FibGVfb3JkZXJfdHlwZV9wb3B1cCI7aTowO3M6MjY6InJlc3RhdXJhbnRfb3Blbl9jbG9zZV9tb2RlIjtzOjQ6ImF1dG8iO3M6MzM6InJlc3RhdXJhbnRfbWFudWFsX29wZW5fY2xvc2VfdHlwZSI7czo0OiJ0aW1lIjtzOjE2OiJtYW51YWxfb3Blbl90aW1lIjtOO3M6MTc6Im1hbnVhbF9jbG9zZV90aW1lIjtOO3M6MjE6ImlzX3RlbXBvcmFyaWx5X2Nsb3NlZCI7aTowO3M6MjE6ImRlZmF1bHRfb3JkZXJfdHlwZV9pZCI7TjtzOjI3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9wb3MiO2k6MDtzOjM3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9jdXN0b21lcl9zaXRlIjtpOjA7czoyODoibWVudV9pdGVtX2RlZmF1bHRfaW1hZ2VfcGF0aCI7TjtzOjMxOiJkaXNhYmxlX21lbnVfaXRlbV9kZWZhdWx0X2ltYWdlIjtpOjA7czo4OiJ0YXhfbW9kZSI7czo1OiJvcmRlciI7czoxMzoidGF4X2luY2x1c2l2ZSI7aTowO3M6Mjc6ImluY2x1ZGVfY2hhcmdlc19pbl90YXhfYmFzZSI7aTowO3M6MjI6ImN1c3RvbWVyX3NpdGVfbGFuZ3VhZ2UiO3M6MjoiZW4iO3M6MjQ6ImVuYWJsZV9hZG1pbl9yZXNlcnZhdGlvbiI7aToxO3M6Mjc6ImVuYWJsZV9jdXN0b21lcl9yZXNlcnZhdGlvbiI7aToxO3M6MTg6Im1pbmltdW1fcGFydHlfc2l6ZSI7aToxO3M6MjY6InRhYmxlX2xvY2tfdGltZW91dF9taW51dGVzIjtpOjEwO3M6MTg6Im1vbGxpZV9jdXN0b21lcl9pZCI7TjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO2k6MTt9czoxMToiACoAb3JpZ2luYWwiO2E6OTk6e3M6MjoiaWQiO2k6MTtzOjQ6Im5hbWUiO3M6MTA6IlJlc3RhdXJhbnQiO3M6NDoiaGFzaCI7czoxMDoicmVzdGF1cmFudCI7czo3OiJhZGRyZXNzIjtzOjU0OiI0NSwgTUkgUm9hZCwgQyBTY2hlbWUsIEphaXB1ciwgUmFqYXN0aGFuIDMwMjAwMSwgSW5kaWEiO3M6MTI6InBob25lX251bWJlciI7czoxMToiMTQ2OTg0NTU4MjIiO3M6MTA6InBob25lX2NvZGUiO3M6MzoiODgwIjtzOjU6ImVtYWlsIjtzOjI3OiJkZW1vLnJlc3RhdXJhbnRAZXhhbXBsZS5jb20iO3M6ODoidGltZXpvbmUiO3M6MTA6IkFzaWEvRGhha2EiO3M6MTE6InRpbWVfZm9ybWF0IjtzOjU6Img6aSBBIjtzOjExOiJkYXRlX2Zvcm1hdCI7czo1OiJkL20vWSI7czo5OiJ0aGVtZV9oZXgiO3M6NzoiI0Y5NzMxNiI7czo5OiJ0aGVtZV9yZ2IiO3M6MTI6IjI0OSwgMTE1LCAyMiI7czo0OiJsb2dvIjtzOjM3OiJmY2ZmNzk3ZDdmNjdhYjAwNzFlZjcwYWQ1YWE4ZGFmZC5qcGVnIjtzOjk6ImRhcmtfbG9nbyI7TjtzOjEwOiJjb3VudHJ5X2lkIjtpOjE5O3M6MTU6ImhpZGVfbmV3X29yZGVycyI7aTowO3M6MjE6ImhpZGVfbmV3X3Jlc2VydmF0aW9ucyI7aTowO3M6MjM6ImhpZGVfbmV3X3dhaXRlcl9yZXF1ZXN0IjtpOjA7czoxMToiY3VycmVuY3lfaWQiO2k6NTtzOjEyOiJsaWNlbnNlX3R5cGUiO3M6NDoiZnJlZSI7czo5OiJpc19hY3RpdmUiO2k6MTtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTEwIDA4OjE5OjU4IjtzOjIzOiJjdXN0b21lcl9sb2dpbl9yZXF1aXJlZCI7aTowO3M6ODoiYWJvdXRfdXMiO3M6NDMxOiI8ZGl2PiZuYnNwO1dlbGNvbWUgdG8gPHN0cm9uZz5TdWx0YW4gRGluZTwvc3Ryb25nPiwgdGhlIHVsdGltYXRlIGRlc3RpbmF0aW9uIGZvciBhdXRoZW50aWMsIHByZW1pdW0gPHN0cm9uZz5TdWx0YW4gRGluZTwvc3Ryb25nPiEgV2UgdGFrZSBwcmlkZSBpbiB1c2luZyB0cmFkaXRpb25hbCBjb29raW5nIG1ldGhvZHMsIHNsb3ctY29va2luZyB0ZW5kZXIgbXV0dG9uIGFuZCBhcm9tYXRpYyBiYXNtYXRpIHJpY2UgdG8gcGVyZmVjdGlvbiB3aXRoIHNlY3JldCBzcGljZXMuIFdoZXRoZXIgeW91J3JlIGRpbmluZyBpbiB3aXRoIGZhbWlseSBvciBvcmRlcmluZyBhIGZlYXN0IGF0IGhvbWUsIHdlIHByb21pc2UgYW4gdW5mb3JnZXR0YWJsZSB0YXN0ZSBvZiB0cmFkaXRpb24uIENvbWUgdmlzaXQgdXMgb3Igb3JkZXIgb25saW5lIHRvZGF5ISZuYnNwOzwvZGl2PiI7czozMDoiYWxsb3dfY3VzdG9tZXJfZGVsaXZlcnlfb3JkZXJzIjtpOjE7czoyODoiYWxsb3dfY3VzdG9tZXJfcGlja3VwX29yZGVycyI7aToxO3M6MTc6InBpY2t1cF9kYXlzX3JhbmdlIjtpOjc7czoyMToiYWxsb3dfY3VzdG9tZXJfb3JkZXJzIjtpOjE7czoyMDoiYWxsb3dfZGluZV9pbl9vcmRlcnMiO2k6MTtzOjg6InNob3dfdmVnIjtpOjE7czoxMDoic2hvd19oYWxhbCI7aTowO3M6MTA6InBhY2thZ2VfaWQiO2k6MztzOjEyOiJwYWNrYWdlX3R5cGUiO3M6ODoibGlmZXRpbWUiO3M6Njoic3RhdHVzIjtzOjY6ImFjdGl2ZSI7czoxNzoibGljZW5zZV9leHBpcmVfb24iO047czoxMzoidHJpYWxfZW5kc19hdCI7TjtzOjE4OiJsaWNlbnNlX3VwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MjM6InN1YnNjcmlwdGlvbl91cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjk6InN0cmlwZV9pZCI7TjtzOjc6InBtX3R5cGUiO047czoxMjoicG1fbGFzdF9mb3VyIjtOO3M6MjU6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWQiO2k6MTtzOjMyOiJkZWZhdWx0X3RhYmxlX3Jlc2VydmF0aW9uX3N0YXR1cyI7czo5OiJDb25maXJtZWQiO3M6MjA6ImRpc2FibGVfc2xvdF9taW51dGVzIjtpOjMwO3M6MTU6ImFwcHJvdmFsX3N0YXR1cyI7czo4OiJBcHByb3ZlZCI7czoxNjoicmVqZWN0aW9uX3JlYXNvbiI7TjtzOjEzOiJmYWNlYm9va19saW5rIjtzOjI1OiJodHRwczovL3d3dy5mYWNlYm9vay5jb20vIjtzOjE0OiJpbnN0YWdyYW1fbGluayI7czoyNjoiaHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS8iO3M6MTI6InR3aXR0ZXJfbGluayI7czoyNDoiaHR0cHM6Ly93d3cudHdpdHRlci5jb20vIjtzOjk6InllbHBfbGluayI7TjtzOjIwOiJnb29nbGVfYnVzaW5lc3NfbGluayI7czoyODoiaHR0cHM6Ly9idXNpbmVzcy5nb29nbGUuY29tLyI7czo5OiJ3aWZpX25hbWUiO047czoxMzoid2lmaV9wYXNzd29yZCI7TjtzOjE0OiJzaG93X3dpZmlfaWNvbiI7aTowO3M6MTQ6InRhYmxlX3JlcXVpcmVkIjtpOjA7czoxNDoic2hvd19sb2dvX3RleHQiO2k6MTtzOjEyOiJtZXRhX2tleXdvcmQiO047czoxNjoibWV0YV9kZXNjcmlwdGlvbiI7TjtzOjM0OiJ1cGxvYWRfZmF2X2ljb25fYW5kcm9pZF9jaHJvbWVfMTkyIjtOO3M6MzQ6InVwbG9hZF9mYXZfaWNvbl9hbmRyb2lkX2Nocm9tZV81MTIiO047czozMjoidXBsb2FkX2Zhdl9pY29uX2FwcGxlX3RvdWNoX2ljb24iO047czoxNzoidXBsb2FkX2Zhdmljb25fMTYiO047czoxNzoidXBsb2FkX2Zhdmljb25fMzIiO047czo3OiJmYXZpY29uIjtOO3M6MzY6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWRfb25fZGVza3RvcCI7aToxO3M6MzU6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWRfb25fbW9iaWxlIjtpOjE7czozNjoiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vcGVuX2J5X3FyIjtpOjA7czoxMToid2VibWFuaWZlc3QiO047czoxNToiZW5hYmxlX3RpcF9zaG9wIjtpOjE7czoxNDoiZW5hYmxlX3RpcF9wb3MiO2k6MTtzOjI1OiJpc19wd2FfaW5zdGFsbF9hbGVydF9zaG93IjtpOjA7czoxOToiYXV0b19jb25maXJtX29yZGVycyI7aTowO3M6MzQ6ImF1dG9fY29uZmlybV9vcmRlcnNfYmVmb3JlX3BheW1lbnQiO2k6MDtzOjMzOiJhdXRvX2NvbmZpcm1fb3JkZXJzX2FmdGVyX3BheW1lbnQiO2k6MDtzOjI5OiJyZXN0cmljdF9xcl9vcmRlcl9ieV9sb2NhdGlvbiI7aTowO3M6MjI6InFyX29yZGVyX3JhZGl1c19tZXRlcnMiO047czoyMzoic2hvd19vcmRlcl90eXBlX29wdGlvbnMiO2k6MTtzOjI0OiJkaXNhYmxlX29yZGVyX3R5cGVfcG9wdXAiO2k6MDtzOjI2OiJyZXN0YXVyYW50X29wZW5fY2xvc2VfbW9kZSI7czo0OiJhdXRvIjtzOjMzOiJyZXN0YXVyYW50X21hbnVhbF9vcGVuX2Nsb3NlX3R5cGUiO3M6NDoidGltZSI7czoxNjoibWFudWFsX29wZW5fdGltZSI7TjtzOjE3OiJtYW51YWxfY2xvc2VfdGltZSI7TjtzOjIxOiJpc190ZW1wb3JhcmlseV9jbG9zZWQiO2k6MDtzOjIxOiJkZWZhdWx0X29yZGVyX3R5cGVfaWQiO047czoyNzoiaGlkZV9tZW51X2l0ZW1faW1hZ2Vfb25fcG9zIjtpOjA7czozNzoiaGlkZV9tZW51X2l0ZW1faW1hZ2Vfb25fY3VzdG9tZXJfc2l0ZSI7aTowO3M6Mjg6Im1lbnVfaXRlbV9kZWZhdWx0X2ltYWdlX3BhdGgiO047czozMToiZGlzYWJsZV9tZW51X2l0ZW1fZGVmYXVsdF9pbWFnZSI7aTowO3M6ODoidGF4X21vZGUiO3M6NToib3JkZXIiO3M6MTM6InRheF9pbmNsdXNpdmUiO2k6MDtzOjI3OiJpbmNsdWRlX2NoYXJnZXNfaW5fdGF4X2Jhc2UiO2k6MDtzOjIyOiJjdXN0b21lcl9zaXRlX2xhbmd1YWdlIjtzOjI6ImVuIjtzOjI0OiJlbmFibGVfYWRtaW5fcmVzZXJ2YXRpb24iO2k6MTtzOjI3OiJlbmFibGVfY3VzdG9tZXJfcmVzZXJ2YXRpb24iO2k6MTtzOjE4OiJtaW5pbXVtX3BhcnR5X3NpemUiO2k6MTtzOjI2OiJ0YWJsZV9sb2NrX3RpbWVvdXRfbWludXRlcyI7aToxMDtzOjE4OiJtb2xsaWVfY3VzdG9tZXJfaWQiO047czozMzoiYXV0b19tYXJrX29yZGVyX2NvbXBsZXRlZF9vbl9wYWlkIjtpOjE7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjE4OntzOjE3OiJsaWNlbnNlX2V4cGlyZV9vbiI7czo4OiJkYXRldGltZSI7czoxNToidHJpYWxfZXhwaXJlX29uIjtzOjg6ImRhdGV0aW1lIjtzOjE4OiJsaWNlbnNlX3VwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MjM6InN1YnNjcmlwdGlvbl91cGRhdGVkX2F0IjtzOjg6ImRhdGV0aW1lIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjg6ImRhdGV0aW1lIjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjg6ImRhdGV0aW1lIjtzOjIzOiJjdXN0b21fZGVsaXZlcnlfb3B0aW9ucyI7czo1OiJhcnJheSI7czo5OiJpc19hY3RpdmUiO3M6NzoiYm9vbGVhbiI7czoyNDoiZW5hYmxlX2FkbWluX3Jlc2VydmF0aW9uIjtzOjc6ImJvb2xlYW4iO3M6Mjc6ImVuYWJsZV9jdXN0b21lcl9yZXNlcnZhdGlvbiI7czo3OiJib29sZWFuIjtzOjI5OiJyZXN0cmljdF9xcl9vcmRlcl9ieV9sb2NhdGlvbiI7czo3OiJib29sZWFuIjtzOjEwOiJhaV9lbmFibGVkIjtzOjc6ImJvb2xlYW4iO3M6MTY6ImFpX2FsbG93ZWRfcm9sZXMiO3M6NToiYXJyYXkiO3M6MTk6ImFpX21vbnRobHlfcmVzZXRfYXQiO3M6NDoiZGF0ZSI7czoyMToiaXNfdGVtcG9yYXJpbHlfY2xvc2VkIjtzOjc6ImJvb2xlYW4iO3M6MzM6InJlc3RhdXJhbnRfbWFudWFsX29wZW5fY2xvc2VfdHlwZSI7czo2OiJzdHJpbmciO3M6MzE6ImRpc2FibGVfbWVudV9pdGVtX2RlZmF1bHRfaW1hZ2UiO3M6NzoiYm9vbGVhbiI7czozMzoiYXV0b19tYXJrX29yZGVyX2NvbXBsZXRlZF9vbl9wYWlkIjtzOjc6ImJvb2xlYW4iO31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6Mjp7aTowO3M6ODoibG9nb191cmwiO2k6MTtzOjEzOiJkYXJrX2xvZ29fdXJsIjt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToxOntzOjg6ImJyYW5jaGVzIjtPOjM5OiJJbGx1bWluYXRlXERhdGFiYXNlXEVsb3F1ZW50XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Mzp7aTowO086MTc6IkFwcFxNb2RlbHNcQnJhbmNoIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czo4OiJicmFuY2hlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjIzOntzOjI6ImlkIjtpOjE7czoxMToidW5pcXVlX2hhc2giO3M6MjA6IjExNzA0NGYzZmIwYmI3OTM4NjkzIjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czo0OiJuYW1lIjtzOjEwOiJLYWNjaGkgVmFpIjtzOjE4OiJjbG9uZWRfYnJhbmNoX25hbWUiO047czoxNjoiY2xvbmVkX2JyYW5jaF9pZCI7TjtzOjEzOiJpc19tZW51X2Nsb25lIjtpOjA7czoyNDoiaXNfaXRlbV9jYXRlZ29yaWVzX2Nsb25lIjtpOjA7czoxOToiaXNfbWVudV9pdGVtc19jbG9uZSI7aTowO3M6MjM6ImlzX2l0ZW1fbW9kaWZpZXJzX2Nsb25lIjtpOjA7czoyOToiaXNfY2xvbmVfcmVzZXJ2YXRpb25fc2V0dGluZ3MiO2k6MDtzOjI2OiJpc19jbG9uZV9kZWxpdmVyeV9zZXR0aW5ncyI7aTowO3M6MjA6ImlzX2Nsb25lX2tvdF9zZXR0aW5nIjtpOjA7czoyNToiaXNfbW9kaWZpZXJzX2dyb3Vwc19jbG9uZSI7aTowO3M6NzoiYWRkcmVzcyI7czoyMToiRGhhbm1vbmRpLCBEaGFrYS0xMjA1IjtzOjk6ImNyX251bWJlciI7TjtzOjEwOiJ2YXRfbnVtYmVyIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTEgMDU6MTM6MDAiO3M6MzoibGF0IjtzOjEwOiIyNi45MTI0MzM2IjtzOjM6ImxuZyI7czoxMDoiNzUuNzg3MjcxOSI7czoxMjoiY291bnRfb3JkZXJzIjtpOjIzO3M6MTI6InRvdGFsX29yZGVycyI7aTotMTt9czoxMToiACoAb3JpZ2luYWwiO2E6MjM6e3M6MjoiaWQiO2k6MTtzOjExOiJ1bmlxdWVfaGFzaCI7czoyMDoiMTE3MDQ0ZjNmYjBiYjc5Mzg2OTMiO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjQ6Im5hbWUiO3M6MTA6IkthY2NoaSBWYWkiO3M6MTg6ImNsb25lZF9icmFuY2hfbmFtZSI7TjtzOjE2OiJjbG9uZWRfYnJhbmNoX2lkIjtOO3M6MTM6ImlzX21lbnVfY2xvbmUiO2k6MDtzOjI0OiJpc19pdGVtX2NhdGVnb3JpZXNfY2xvbmUiO2k6MDtzOjE5OiJpc19tZW51X2l0ZW1zX2Nsb25lIjtpOjA7czoyMzoiaXNfaXRlbV9tb2RpZmllcnNfY2xvbmUiO2k6MDtzOjI5OiJpc19jbG9uZV9yZXNlcnZhdGlvbl9zZXR0aW5ncyI7aTowO3M6MjY6ImlzX2Nsb25lX2RlbGl2ZXJ5X3NldHRpbmdzIjtpOjA7czoyMDoiaXNfY2xvbmVfa290X3NldHRpbmciO2k6MDtzOjI1OiJpc19tb2RpZmllcnNfZ3JvdXBzX2Nsb25lIjtpOjA7czo3OiJhZGRyZXNzIjtzOjIxOiJEaGFubW9uZGksIERoYWthLTEyMDUiO3M6OToiY3JfbnVtYmVyIjtOO3M6MTA6InZhdF9udW1iZXIiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMSAwNToxMzowMCI7czozOiJsYXQiO3M6MTA6IjI2LjkxMjQzMzYiO3M6MzoibG5nIjtzOjEwOiI3NS43ODcyNzE5IjtzOjEyOiJjb3VudF9vcmRlcnMiO2k6MjM7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YToyOntzOjM6ImxhdCI7czo1OiJmbG9hdCI7czozOiJsbmciO3M6NToiZmxvYXQiO31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YToxMTp7aTowO3M6NDoibmFtZSI7aToxO3M6NzoiYWRkcmVzcyI7aToyO3M6OToiY3JfbnVtYmVyIjtpOjM7czoxMDoidmF0X251bWJlciI7aTo0O3M6NToicGhvbmUiO2k6NTtzOjU6ImVtYWlsIjtpOjY7czoxMzoicmVzdGF1cmFudF9pZCI7aTo3O3M6OToiaXNfYWN0aXZlIjtpOjg7czoxMToidW5pcXVlX2hhc2giO2k6OTtzOjM6ImxhdCI7aToxMDtzOjM6ImxuZyI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO319aToxO086MTc6IkFwcFxNb2RlbHNcQnJhbmNoIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czo4OiJicmFuY2hlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjIzOntzOjI6ImlkIjtpOjI7czoxMToidW5pcXVlX2hhc2giO3M6MjA6IjQ5ZDMxNWJjN2E5ODkwNDcyMzA4IjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czo0OiJuYW1lIjtzOjU6IkRlbGhpIjtzOjE4OiJjbG9uZWRfYnJhbmNoX25hbWUiO047czoxNjoiY2xvbmVkX2JyYW5jaF9pZCI7TjtzOjEzOiJpc19tZW51X2Nsb25lIjtpOjA7czoyNDoiaXNfaXRlbV9jYXRlZ29yaWVzX2Nsb25lIjtpOjA7czoxOToiaXNfbWVudV9pdGVtc19jbG9uZSI7aTowO3M6MjM6ImlzX2l0ZW1fbW9kaWZpZXJzX2Nsb25lIjtpOjA7czoyOToiaXNfY2xvbmVfcmVzZXJ2YXRpb25fc2V0dGluZ3MiO2k6MDtzOjI2OiJpc19jbG9uZV9kZWxpdmVyeV9zZXR0aW5ncyI7aTowO3M6MjA6ImlzX2Nsb25lX2tvdF9zZXR0aW5nIjtpOjA7czoyNToiaXNfbW9kaWZpZXJzX2dyb3Vwc19jbG9uZSI7aTowO3M6NzoiYWRkcmVzcyI7czo1MToiMTIsIENvbm5hdWdodCBQbGFjZSwgTmV3IERlbGhpLCBEZWxoaSAxMTAwMDEsIEluZGlhIjtzOjk6ImNyX251bWJlciI7TjtzOjEwOiJ2YXRfbnVtYmVyIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDkiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDkiO3M6MzoibGF0IjtzOjEwOiIyOC42Mjg0NTQxIjtzOjM6ImxuZyI7czoxMDoiNzcuMjA2OTgxNiI7czoxMjoiY291bnRfb3JkZXJzIjtpOjA7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjExOiIAKgBvcmlnaW5hbCI7YToyMzp7czoyOiJpZCI7aToyO3M6MTE6InVuaXF1ZV9oYXNoIjtzOjIwOiI0OWQzMTViYzdhOTg5MDQ3MjMwOCI7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6NDoibmFtZSI7czo1OiJEZWxoaSI7czoxODoiY2xvbmVkX2JyYW5jaF9uYW1lIjtOO3M6MTY6ImNsb25lZF9icmFuY2hfaWQiO047czoxMzoiaXNfbWVudV9jbG9uZSI7aTowO3M6MjQ6ImlzX2l0ZW1fY2F0ZWdvcmllc19jbG9uZSI7aTowO3M6MTk6ImlzX21lbnVfaXRlbXNfY2xvbmUiO2k6MDtzOjIzOiJpc19pdGVtX21vZGlmaWVyc19jbG9uZSI7aTowO3M6Mjk6ImlzX2Nsb25lX3Jlc2VydmF0aW9uX3NldHRpbmdzIjtpOjA7czoyNjoiaXNfY2xvbmVfZGVsaXZlcnlfc2V0dGluZ3MiO2k6MDtzOjIwOiJpc19jbG9uZV9rb3Rfc2V0dGluZyI7aTowO3M6MjU6ImlzX21vZGlmaWVyc19ncm91cHNfY2xvbmUiO2k6MDtzOjc6ImFkZHJlc3MiO3M6NTE6IjEyLCBDb25uYXVnaHQgUGxhY2UsIE5ldyBEZWxoaSwgRGVsaGkgMTEwMDAxLCBJbmRpYSI7czo5OiJjcl9udW1iZXIiO047czoxMDoidmF0X251bWJlciI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA5IjtzOjM6ImxhdCI7czoxMDoiMjguNjI4NDU0MSI7czozOiJsbmciO3M6MTA6Ijc3LjIwNjk4MTYiO3M6MTI6ImNvdW50X29yZGVycyI7aTowO3M6MTI6InRvdGFsX29yZGVycyI7aTotMTt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6Mjp7czozOiJsYXQiO3M6NToiZmxvYXQiO3M6MzoibG5nIjtzOjU6ImZsb2F0Ijt9czoxNzoiACoAY2xhc3NDYXN0Q2FjaGUiO2E6MDp7fXM6MjE6IgAqAGF0dHJpYnV0ZUNhc3RDYWNoZSI7YTowOnt9czoxMzoiACoAZGF0ZUZvcm1hdCI7TjtzOjEwOiIAKgBhcHBlbmRzIjthOjA6e31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MTE6e2k6MDtzOjQ6Im5hbWUiO2k6MTtzOjc6ImFkZHJlc3MiO2k6MjtzOjk6ImNyX251bWJlciI7aTozO3M6MTA6InZhdF9udW1iZXIiO2k6NDtzOjU6InBob25lIjtpOjU7czo1OiJlbWFpbCI7aTo2O3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6NztzOjk6ImlzX2FjdGl2ZSI7aTo4O3M6MTE6InVuaXF1ZV9oYXNoIjtpOjk7czozOiJsYXQiO2k6MTA7czozOiJsbmciO31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjI6ImlkIjt9fWk6MjtPOjE3OiJBcHBcTW9kZWxzXEJyYW5jaCI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToibXlzcWwiO3M6ODoiACoAdGFibGUiO3M6ODoiYnJhbmNoZXMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToyMzp7czoyOiJpZCI7aTozO3M6MTE6InVuaXF1ZV9oYXNoIjtzOjIwOiIwYzcwOWJjOTRlNWQ1MTY3ZDAxOCI7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6NDoibmFtZSI7czoxMToiU3VsdGFuIERpbmUiO3M6MTg6ImNsb25lZF9icmFuY2hfbmFtZSI7TjtzOjE2OiJjbG9uZWRfYnJhbmNoX2lkIjtOO3M6MTM6ImlzX21lbnVfY2xvbmUiO2k6MDtzOjI0OiJpc19pdGVtX2NhdGVnb3JpZXNfY2xvbmUiO2k6MDtzOjE5OiJpc19tZW51X2l0ZW1zX2Nsb25lIjtpOjA7czoyMzoiaXNfaXRlbV9tb2RpZmllcnNfY2xvbmUiO2k6MDtzOjI5OiJpc19jbG9uZV9yZXNlcnZhdGlvbl9zZXR0aW5ncyI7aTowO3M6MjY6ImlzX2Nsb25lX2RlbGl2ZXJ5X3NldHRpbmdzIjtpOjA7czoyMDoiaXNfY2xvbmVfa290X3NldHRpbmciO2k6MDtzOjI1OiJpc19tb2RpZmllcnNfZ3JvdXBzX2Nsb25lIjtpOjA7czo3OiJhZGRyZXNzIjtzOjQ5OiJNaXJwdXIgMTAgUm9hZCwgRGhha2EsIERoYWthIERpdmlzaW9uLCBCYW5nbGFkZXNoIjtzOjk6ImNyX251bWJlciI7czoyMToiVFJBRC9ETkNDLzA0MTg1Mi8yMDI2IjtzOjEwOiJ2YXRfbnVtYmVyIjtzOjIwOiJlLVRJTiA6IDUxODQ5MzAyNzQ2MSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMCAwNjozNDo0OSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMSAwNToyNzo1MSI7czozOiJsYXQiO3M6MTA6IjIzLjgwMDc1MjUiO3M6MzoibG5nIjtzOjEwOiI5MC4zNTY1Nzc5IjtzOjEyOiJjb3VudF9vcmRlcnMiO2k6MjA7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjExOiIAKgBvcmlnaW5hbCI7YToyMzp7czoyOiJpZCI7aTozO3M6MTE6InVuaXF1ZV9oYXNoIjtzOjIwOiIwYzcwOWJjOTRlNWQ1MTY3ZDAxOCI7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6NDoibmFtZSI7czoxMToiU3VsdGFuIERpbmUiO3M6MTg6ImNsb25lZF9icmFuY2hfbmFtZSI7TjtzOjE2OiJjbG9uZWRfYnJhbmNoX2lkIjtOO3M6MTM6ImlzX21lbnVfY2xvbmUiO2k6MDtzOjI0OiJpc19pdGVtX2NhdGVnb3JpZXNfY2xvbmUiO2k6MDtzOjE5OiJpc19tZW51X2l0ZW1zX2Nsb25lIjtpOjA7czoyMzoiaXNfaXRlbV9tb2RpZmllcnNfY2xvbmUiO2k6MDtzOjI5OiJpc19jbG9uZV9yZXNlcnZhdGlvbl9zZXR0aW5ncyI7aTowO3M6MjY6ImlzX2Nsb25lX2RlbGl2ZXJ5X3NldHRpbmdzIjtpOjA7czoyMDoiaXNfY2xvbmVfa290X3NldHRpbmciO2k6MDtzOjI1OiJpc19tb2RpZmllcnNfZ3JvdXBzX2Nsb25lIjtpOjA7czo3OiJhZGRyZXNzIjtzOjQ5OiJNaXJwdXIgMTAgUm9hZCwgRGhha2EsIERoYWthIERpdmlzaW9uLCBCYW5nbGFkZXNoIjtzOjk6ImNyX251bWJlciI7czoyMToiVFJBRC9ETkNDLzA0MTg1Mi8yMDI2IjtzOjEwOiJ2YXRfbnVtYmVyIjtzOjIwOiJlLVRJTiA6IDUxODQ5MzAyNzQ2MSI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMCAwNjozNDo0OSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMSAwNToyNzo1MSI7czozOiJsYXQiO3M6MTA6IjIzLjgwMDc1MjUiO3M6MzoibG5nIjtzOjEwOiI5MC4zNTY1Nzc5IjtzOjEyOiJjb3VudF9vcmRlcnMiO2k6MjA7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YToyOntzOjM6ImxhdCI7czo1OiJmbG9hdCI7czozOiJsbmciO3M6NToiZmxvYXQiO31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YToxMTp7aTowO3M6NDoibmFtZSI7aToxO3M6NzoiYWRkcmVzcyI7aToyO3M6OToiY3JfbnVtYmVyIjtpOjM7czoxMDoidmF0X251bWJlciI7aTo0O3M6NToicGhvbmUiO2k6NTtzOjU6ImVtYWlsIjtpOjY7czoxMzoicmVzdGF1cmFudF9pZCI7aTo3O3M6OToiaXNfYWN0aXZlIjtpOjg7czoxMToidW5pcXVlX2hhc2giO2k6OTtzOjM6ImxhdCI7aToxMDtzOjM6ImxuZyI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO319fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTowOnt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fXM6MTc6ImN1c3RvbWVySXBBZGRyZXNzIjtOO3M6MjQ6ImVzdGltYXRpb25CaWxsaW5nQWRkcmVzcyI7YTowOnt9czoxMzoiY29sbGVjdFRheElkcyI7YjowO3M6ODoiY291cG9uSWQiO047czoxNToicHJvbW90aW9uQ29kZUlkIjtOO3M6MTk6ImFsbG93UHJvbW90aW9uQ29kZXMiO2I6MDt9czo2OiJicmFuY2giO047czo1OiJyb2xlcyI7TzozOToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjE6e2k6MDtPOjI5OiJTcGF0aWVcUGVybWlzc2lvblxNb2RlbHNcUm9sZSI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToibXlzcWwiO3M6ODoiACoAdGFibGUiO3M6NToicm9sZXMiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YTo3OntzOjI6ImlkIjtpOjI7czo0OiJuYW1lIjtzOjc6IkFkbWluXzEiO3M6MTI6ImRpc3BsYXlfbmFtZSI7czo1OiJBZG1pbiI7czoxMDoiZ3VhcmRfbmFtZSI7czozOiJ3ZWIiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MTAiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MTAiO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTt9czoxMToiACoAb3JpZ2luYWwiO2E6MTA6e3M6MjoiaWQiO2k6MjtzOjQ6Im5hbWUiO3M6NzoiQWRtaW5fMSI7czoxMjoiZGlzcGxheV9uYW1lIjtzOjU6IkFkbWluIjtzOjEwOiJndWFyZF9uYW1lIjtzOjM6IndlYiI7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDoxMCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDoxMCI7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6MTQ6InBpdm90X21vZGVsX2lkIjtpOjI7czoxMzoicGl2b3Rfcm9sZV9pZCI7aToyO3M6MTY6InBpdm90X21vZGVsX3R5cGUiO3M6MTU6IkFwcFxNb2RlbHNcVXNlciI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MTp7czo1OiJwaXZvdCI7Tzo0OToiSWxsdW1pbmF0ZVxEYXRhYmFzZVxFbG9xdWVudFxSZWxhdGlvbnNcTW9ycGhQaXZvdCI6Mzk6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToibXlzcWwiO3M6ODoiACoAdGFibGUiO3M6MTU6Im1vZGVsX2hhc19yb2xlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjowO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjM6e3M6MTA6Im1vZGVsX3R5cGUiO3M6MTU6IkFwcFxNb2RlbHNcVXNlciI7czo4OiJtb2RlbF9pZCI7aToyO3M6Nzoicm9sZV9pZCI7aToyO31zOjExOiIAKgBvcmlnaW5hbCI7YTozOntzOjEwOiJtb2RlbF90eXBlIjtzOjE1OiJBcHBcTW9kZWxzXFVzZXIiO3M6ODoibW9kZWxfaWQiO2k6MjtzOjc6InJvbGVfaWQiO2k6Mjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MDtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjA6e31zOjEwOiIAKgBndWFyZGVkIjthOjA6e31zOjExOiJwaXZvdFBhcmVudCI7TzoxNToiQXBwXE1vZGVsc1xVc2VyIjozNjp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czo1OiJ1c2VycyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjowO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjA6e31zOjExOiIAKgBvcmlnaW5hbCI7YTowOnt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6Njp7czoxNzoiZW1haWxfdmVyaWZpZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6ODoicGFzc3dvcmQiO3M6NjoiaGFzaGVkIjtzOjEzOiJyZXN0YXVyYW50X2lkIjtzOjc6ImludGVnZXIiO3M6OToiYnJhbmNoX2lkIjtzOjc6ImludGVnZXIiO3M6MjY6InRlcm1zX2FuZF9wcml2YWN5X2FjY2VwdGVkIjtzOjc6ImJvb2xlYW4iO3M6MjU6Im1hcmtldGluZ19lbWFpbHNfYWNjZXB0ZWQiO3M6NzoiYm9vbGVhbiI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToxOntpOjA7czoxNzoicHJvZmlsZV9waG90b191cmwiO31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTo0OntpOjA7czo4OiJwYXNzd29yZCI7aToxO3M6MTQ6InJlbWVtYmVyX3Rva2VuIjtpOjI7czoyNToidHdvX2ZhY3Rvcl9yZWNvdmVyeV9jb2RlcyI7aTozO3M6MTc6InR3b19mYWN0b3Jfc2VjcmV0Ijt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MTA6e2k6MDtzOjQ6Im5hbWUiO2k6MTtzOjU6ImVtYWlsIjtpOjI7czo4OiJwYXNzd29yZCI7aTozO3M6OToiYnJhbmNoX2lkIjtpOjQ7czoxMzoicmVzdGF1cmFudF9pZCI7aTo1O3M6NjoibG9jYWxlIjtpOjY7czoxMjoicGhvbmVfbnVtYmVyIjtpOjc7czoxMDoicGhvbmVfY29kZSI7aTo4O3M6MjY6InRlcm1zX2FuZF9wcml2YWN5X2FjY2VwdGVkIjtpOjk7czoyNToibWFya2V0aW5nX2VtYWlsc19hY2NlcHRlZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAGF1dGhQYXNzd29yZE5hbWUiO3M6ODoicGFzc3dvcmQiO3M6MjA6IgAqAHJlbWVtYmVyVG9rZW5OYW1lIjtzOjE0OiJyZW1lbWJlcl90b2tlbiI7czoxNDoiACoAYWNjZXNzVG9rZW4iO047fXM6MTI6InBpdm90UmVsYXRlZCI7TzoyOToiU3BhdGllXFBlcm1pc3Npb25cTW9kZWxzXFJvbGUiOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjU6InJvbGVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjA7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTp7czoxMDoiZ3VhcmRfbmFtZSI7czozOiJ3ZWIiO31zOjExOiIAKgBvcmlnaW5hbCI7YTowOnt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjA6e31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjI6ImlkIjt9fXM6MTM6IgAqAGZvcmVpZ25LZXkiO3M6ODoibW9kZWxfaWQiO3M6MTM6IgAqAHJlbGF0ZWRLZXkiO3M6Nzoicm9sZV9pZCI7czoxMjoiACoAbW9ycGhUeXBlIjtzOjEwOiJtb2RlbF90eXBlIjtzOjEzOiIAKgBtb3JwaENsYXNzIjtzOjE1OiJBcHBcTW9kZWxzXFVzZXIiO319czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjA6e31zOjEwOiIAKgBndWFyZGVkIjthOjE6e2k6MDtzOjI6ImlkIjt9fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTo0OntpOjA7czo4OiJwYXNzd29yZCI7aToxO3M6MTQ6InJlbWVtYmVyX3Rva2VuIjtpOjI7czoyNToidHdvX2ZhY3Rvcl9yZWNvdmVyeV9jb2RlcyI7aTozO3M6MTc6InR3b19mYWN0b3Jfc2VjcmV0Ijt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MTA6e2k6MDtzOjQ6Im5hbWUiO2k6MTtzOjU6ImVtYWlsIjtpOjI7czo4OiJwYXNzd29yZCI7aTozO3M6OToiYnJhbmNoX2lkIjtpOjQ7czoxMzoicmVzdGF1cmFudF9pZCI7aTo1O3M6NjoibG9jYWxlIjtpOjY7czoxMjoicGhvbmVfbnVtYmVyIjtpOjc7czoxMDoicGhvbmVfY29kZSI7aTo4O3M6MjY6InRlcm1zX2FuZF9wcml2YWN5X2FjY2VwdGVkIjtpOjk7czoyNToibWFya2V0aW5nX2VtYWlsc19hY2NlcHRlZCI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fXM6MTk6IgAqAGF1dGhQYXNzd29yZE5hbWUiO3M6ODoicGFzc3dvcmQiO3M6MjA6IgAqAHJlbWVtYmVyVG9rZW5OYW1lIjtzOjE0OiJyZW1lbWJlcl90b2tlbiI7czoxNDoiACoAYWNjZXNzVG9rZW4iO047fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjgyOiJodHRwczovL3RhYmxldHJhY2suZGF0YXNvbHV0aW9uLmNvbS5iZC9tYW5pZmVzdC5qc29uP2hhc2g9cmVzdGF1cmFudCZ1cmw9ZGFzaGJvYXJkIjtzOjU6InJvdXRlIjtzOjg6Im1hbmlmZXN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MjtzOjEwOiJyZXN0YXVyYW50IjtPOjIxOiJBcHBcTW9kZWxzXFJlc3RhdXJhbnQiOjM5OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjExOiJyZXN0YXVyYW50cyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjk5OntzOjI6ImlkIjtpOjE7czo0OiJuYW1lIjtzOjEwOiJSZXN0YXVyYW50IjtzOjQ6Imhhc2giO3M6MTA6InJlc3RhdXJhbnQiO3M6NzoiYWRkcmVzcyI7czo1NDoiNDUsIE1JIFJvYWQsIEMgU2NoZW1lLCBKYWlwdXIsIFJhamFzdGhhbiAzMDIwMDEsIEluZGlhIjtzOjEyOiJwaG9uZV9udW1iZXIiO2k6MTQ2OTg0NTU4MjI7czoxMDoicGhvbmVfY29kZSI7aTo4ODA7czo1OiJlbWFpbCI7czoyNzoiZGVtby5yZXN0YXVyYW50QGV4YW1wbGUuY29tIjtzOjg6InRpbWV6b25lIjtzOjEwOiJBc2lhL0RoYWthIjtzOjExOiJ0aW1lX2Zvcm1hdCI7czo1OiJoOmkgQSI7czoxMToiZGF0ZV9mb3JtYXQiO3M6NToiZC9tL1kiO3M6OToidGhlbWVfaGV4IjtzOjc6IiNGOTczMTYiO3M6OToidGhlbWVfcmdiIjtzOjEyOiIyNDksIDExNSwgMjIiO3M6NDoibG9nbyI7czozNzoiZmNmZjc5N2Q3ZjY3YWIwMDcxZWY3MGFkNWFhOGRhZmQuanBlZyI7czo5OiJkYXJrX2xvZ28iO047czoxMDoiY291bnRyeV9pZCI7aToxOTtzOjE1OiJoaWRlX25ld19vcmRlcnMiO2k6MDtzOjIxOiJoaWRlX25ld19yZXNlcnZhdGlvbnMiO2k6MDtzOjIzOiJoaWRlX25ld193YWl0ZXJfcmVxdWVzdCI7aTowO3M6MTE6ImN1cnJlbmN5X2lkIjtpOjU7czoxMjoibGljZW5zZV90eXBlIjtzOjQ6ImZyZWUiO3M6OToiaXNfYWN0aXZlIjtpOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMCAwODoxOTo1OCI7czoyMzoiY3VzdG9tZXJfbG9naW5fcmVxdWlyZWQiO2k6MDtzOjg6ImFib3V0X3VzIjtzOjQzMToiPGRpdj4mbmJzcDtXZWxjb21lIHRvIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4sIHRoZSB1bHRpbWF0ZSBkZXN0aW5hdGlvbiBmb3IgYXV0aGVudGljLCBwcmVtaXVtIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4hIFdlIHRha2UgcHJpZGUgaW4gdXNpbmcgdHJhZGl0aW9uYWwgY29va2luZyBtZXRob2RzLCBzbG93LWNvb2tpbmcgdGVuZGVyIG11dHRvbiBhbmQgYXJvbWF0aWMgYmFzbWF0aSByaWNlIHRvIHBlcmZlY3Rpb24gd2l0aCBzZWNyZXQgc3BpY2VzLiBXaGV0aGVyIHlvdSdyZSBkaW5pbmcgaW4gd2l0aCBmYW1pbHkgb3Igb3JkZXJpbmcgYSBmZWFzdCBhdCBob21lLCB3ZSBwcm9taXNlIGFuIHVuZm9yZ2V0dGFibGUgdGFzdGUgb2YgdHJhZGl0aW9uLiBDb21lIHZpc2l0IHVzIG9yIG9yZGVyIG9ubGluZSB0b2RheSEmbmJzcDs8L2Rpdj4iO3M6MzA6ImFsbG93X2N1c3RvbWVyX2RlbGl2ZXJ5X29yZGVycyI7aToxO3M6Mjg6ImFsbG93X2N1c3RvbWVyX3BpY2t1cF9vcmRlcnMiO2k6MTtzOjE3OiJwaWNrdXBfZGF5c19yYW5nZSI7aTo3O3M6MjE6ImFsbG93X2N1c3RvbWVyX29yZGVycyI7aToxO3M6MjA6ImFsbG93X2RpbmVfaW5fb3JkZXJzIjtpOjE7czo4OiJzaG93X3ZlZyI7aToxO3M6MTA6InNob3dfaGFsYWwiO2k6MDtzOjEwOiJwYWNrYWdlX2lkIjtpOjM7czoxMjoicGFja2FnZV90eXBlIjtzOjg6ImxpZmV0aW1lIjtzOjY6InN0YXR1cyI7czo2OiJhY3RpdmUiO3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtOO3M6MTM6InRyaWFsX2VuZHNfYXQiO047czoxODoibGljZW5zZV91cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjIzOiJzdWJzY3JpcHRpb25fdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czo5OiJzdHJpcGVfaWQiO047czo3OiJwbV90eXBlIjtOO3M6MTI6InBtX2xhc3RfZm91ciI7TjtzOjI1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkIjtpOjE7czozMjoiZGVmYXVsdF90YWJsZV9yZXNlcnZhdGlvbl9zdGF0dXMiO3M6OToiQ29uZmlybWVkIjtzOjIwOiJkaXNhYmxlX3Nsb3RfbWludXRlcyI7aTozMDtzOjE1OiJhcHByb3ZhbF9zdGF0dXMiO3M6ODoiQXBwcm92ZWQiO3M6MTY6InJlamVjdGlvbl9yZWFzb24iO047czoxMzoiZmFjZWJvb2tfbGluayI7czoyNToiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tLyI7czoxNDoiaW5zdGFncmFtX2xpbmsiO3M6MjY6Imh0dHBzOi8vd3d3Lmluc3RhZ3JhbS5jb20vIjtzOjEyOiJ0d2l0dGVyX2xpbmsiO3M6MjQ6Imh0dHBzOi8vd3d3LnR3aXR0ZXIuY29tLyI7czo5OiJ5ZWxwX2xpbmsiO047czoyMDoiZ29vZ2xlX2J1c2luZXNzX2xpbmsiO3M6Mjg6Imh0dHBzOi8vYnVzaW5lc3MuZ29vZ2xlLmNvbS8iO3M6OToid2lmaV9uYW1lIjtOO3M6MTM6IndpZmlfcGFzc3dvcmQiO047czoxNDoic2hvd193aWZpX2ljb24iO2k6MDtzOjE0OiJ0YWJsZV9yZXF1aXJlZCI7aTowO3M6MTQ6InNob3dfbG9nb190ZXh0IjtpOjE7czoxMjoibWV0YV9rZXl3b3JkIjtOO3M6MTY6Im1ldGFfZGVzY3JpcHRpb24iO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzE5MiI7TjtzOjM0OiJ1cGxvYWRfZmF2X2ljb25fYW5kcm9pZF9jaHJvbWVfNTEyIjtOO3M6MzI6InVwbG9hZF9mYXZfaWNvbl9hcHBsZV90b3VjaF9pY29uIjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzE2IjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzMyIjtOO3M6NzoiZmF2aWNvbiI7TjtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX2Rlc2t0b3AiO2k6MTtzOjM1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX21vYmlsZSI7aToxO3M6MzY6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWRfb3Blbl9ieV9xciI7aTowO3M6MTE6IndlYm1hbmlmZXN0IjtOO3M6MTU6ImVuYWJsZV90aXBfc2hvcCI7aToxO3M6MTQ6ImVuYWJsZV90aXBfcG9zIjtpOjE7czoyNToiaXNfcHdhX2luc3RhbGxfYWxlcnRfc2hvdyI7aTowO3M6MTk6ImF1dG9fY29uZmlybV9vcmRlcnMiO2k6MDtzOjM0OiJhdXRvX2NvbmZpcm1fb3JkZXJzX2JlZm9yZV9wYXltZW50IjtpOjA7czozMzoiYXV0b19jb25maXJtX29yZGVyc19hZnRlcl9wYXltZW50IjtpOjA7czoyOToicmVzdHJpY3RfcXJfb3JkZXJfYnlfbG9jYXRpb24iO2k6MDtzOjIyOiJxcl9vcmRlcl9yYWRpdXNfbWV0ZXJzIjtOO3M6MjM6InNob3dfb3JkZXJfdHlwZV9vcHRpb25zIjtpOjE7czoyNDoiZGlzYWJsZV9vcmRlcl90eXBlX3BvcHVwIjtpOjA7czoyNjoicmVzdGF1cmFudF9vcGVuX2Nsb3NlX21vZGUiO3M6NDoiYXV0byI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjQ6InRpbWUiO3M6MTY6Im1hbnVhbF9vcGVuX3RpbWUiO047czoxNzoibWFudWFsX2Nsb3NlX3RpbWUiO047czoyMToiaXNfdGVtcG9yYXJpbHlfY2xvc2VkIjtpOjA7czoyMToiZGVmYXVsdF9vcmRlcl90eXBlX2lkIjtOO3M6Mjc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX3BvcyI7aTowO3M6Mzc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX2N1c3RvbWVyX3NpdGUiO2k6MDtzOjI4OiJtZW51X2l0ZW1fZGVmYXVsdF9pbWFnZV9wYXRoIjtOO3M6MzE6ImRpc2FibGVfbWVudV9pdGVtX2RlZmF1bHRfaW1hZ2UiO2k6MDtzOjg6InRheF9tb2RlIjtzOjU6Im9yZGVyIjtzOjEzOiJ0YXhfaW5jbHVzaXZlIjtpOjA7czoyNzoiaW5jbHVkZV9jaGFyZ2VzX2luX3RheF9iYXNlIjtpOjA7czoyMjoiY3VzdG9tZXJfc2l0ZV9sYW5ndWFnZSI7czoyOiJlbiI7czoyNDoiZW5hYmxlX2FkbWluX3Jlc2VydmF0aW9uIjtpOjE7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtpOjE7czoxODoibWluaW11bV9wYXJ0eV9zaXplIjtpOjE7czoyNjoidGFibGVfbG9ja190aW1lb3V0X21pbnV0ZXMiO2k6MTA7czoxODoibW9sbGllX2N1c3RvbWVyX2lkIjtOO3M6MzM6ImF1dG9fbWFya19vcmRlcl9jb21wbGV0ZWRfb25fcGFpZCI7aToxO31zOjExOiIAKgBvcmlnaW5hbCI7YTo5OTp7czoyOiJpZCI7aToxO3M6NDoibmFtZSI7czoxMDoiUmVzdGF1cmFudCI7czo0OiJoYXNoIjtzOjEwOiJyZXN0YXVyYW50IjtzOjc6ImFkZHJlc3MiO3M6NTQ6IjQ1LCBNSSBSb2FkLCBDIFNjaGVtZSwgSmFpcHVyLCBSYWphc3RoYW4gMzAyMDAxLCBJbmRpYSI7czoxMjoicGhvbmVfbnVtYmVyIjtzOjExOiIxNDY5ODQ1NTgyMiI7czoxMDoicGhvbmVfY29kZSI7czozOiI4ODAiO3M6NToiZW1haWwiO3M6Mjc6ImRlbW8ucmVzdGF1cmFudEBleGFtcGxlLmNvbSI7czo4OiJ0aW1lem9uZSI7czoxMDoiQXNpYS9EaGFrYSI7czoxMToidGltZV9mb3JtYXQiO3M6NToiaDppIEEiO3M6MTE6ImRhdGVfZm9ybWF0IjtzOjU6ImQvbS9ZIjtzOjk6InRoZW1lX2hleCI7czo3OiIjRjk3MzE2IjtzOjk6InRoZW1lX3JnYiI7czoxMjoiMjQ5LCAxMTUsIDIyIjtzOjQ6ImxvZ28iO3M6Mzc6ImZjZmY3OTdkN2Y2N2FiMDA3MWVmNzBhZDVhYThkYWZkLmpwZWciO3M6OToiZGFya19sb2dvIjtOO3M6MTA6ImNvdW50cnlfaWQiO2k6MTk7czoxNToiaGlkZV9uZXdfb3JkZXJzIjtpOjA7czoyMToiaGlkZV9uZXdfcmVzZXJ2YXRpb25zIjtpOjA7czoyMzoiaGlkZV9uZXdfd2FpdGVyX3JlcXVlc3QiO2k6MDtzOjExOiJjdXJyZW5jeV9pZCI7aTo1O3M6MTI6ImxpY2Vuc2VfdHlwZSI7czo0OiJmcmVlIjtzOjk6ImlzX2FjdGl2ZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDg6MTk6NTgiO3M6MjM6ImN1c3RvbWVyX2xvZ2luX3JlcXVpcmVkIjtpOjA7czo4OiJhYm91dF91cyI7czo0MzE6IjxkaXY+Jm5ic3A7V2VsY29tZSB0byA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+LCB0aGUgdWx0aW1hdGUgZGVzdGluYXRpb24gZm9yIGF1dGhlbnRpYywgcHJlbWl1bSA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+ISBXZSB0YWtlIHByaWRlIGluIHVzaW5nIHRyYWRpdGlvbmFsIGNvb2tpbmcgbWV0aG9kcywgc2xvdy1jb29raW5nIHRlbmRlciBtdXR0b24gYW5kIGFyb21hdGljIGJhc21hdGkgcmljZSB0byBwZXJmZWN0aW9uIHdpdGggc2VjcmV0IHNwaWNlcy4gV2hldGhlciB5b3UncmUgZGluaW5nIGluIHdpdGggZmFtaWx5IG9yIG9yZGVyaW5nIGEgZmVhc3QgYXQgaG9tZSwgd2UgcHJvbWlzZSBhbiB1bmZvcmdldHRhYmxlIHRhc3RlIG9mIHRyYWRpdGlvbi4gQ29tZSB2aXNpdCB1cyBvciBvcmRlciBvbmxpbmUgdG9kYXkhJm5ic3A7PC9kaXY+IjtzOjMwOiJhbGxvd19jdXN0b21lcl9kZWxpdmVyeV9vcmRlcnMiO2k6MTtzOjI4OiJhbGxvd19jdXN0b21lcl9waWNrdXBfb3JkZXJzIjtpOjE7czoxNzoicGlja3VwX2RheXNfcmFuZ2UiO2k6NztzOjIxOiJhbGxvd19jdXN0b21lcl9vcmRlcnMiO2k6MTtzOjIwOiJhbGxvd19kaW5lX2luX29yZGVycyI7aToxO3M6ODoic2hvd192ZWciO2k6MTtzOjEwOiJzaG93X2hhbGFsIjtpOjA7czoxMDoicGFja2FnZV9pZCI7aTozO3M6MTI6InBhY2thZ2VfdHlwZSI7czo4OiJsaWZldGltZSI7czo2OiJzdGF0dXMiO3M6NjoiYWN0aXZlIjtzOjE3OiJsaWNlbnNlX2V4cGlyZV9vbiI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6OToic3RyaXBlX2lkIjtOO3M6NzoicG1fdHlwZSI7TjtzOjEyOiJwbV9sYXN0X2ZvdXIiO047czoyNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZCI7aToxO3M6MzI6ImRlZmF1bHRfdGFibGVfcmVzZXJ2YXRpb25fc3RhdHVzIjtzOjk6IkNvbmZpcm1lZCI7czoyMDoiZGlzYWJsZV9zbG90X21pbnV0ZXMiO2k6MzA7czoxNToiYXBwcm92YWxfc3RhdHVzIjtzOjg6IkFwcHJvdmVkIjtzOjE2OiJyZWplY3Rpb25fcmVhc29uIjtOO3M6MTM6ImZhY2Vib29rX2xpbmsiO3M6MjU6Imh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS8iO3M6MTQ6Imluc3RhZ3JhbV9saW5rIjtzOjI2OiJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tLyI7czoxMjoidHdpdHRlcl9saW5rIjtzOjI0OiJodHRwczovL3d3dy50d2l0dGVyLmNvbS8iO3M6OToieWVscF9saW5rIjtOO3M6MjA6Imdvb2dsZV9idXNpbmVzc19saW5rIjtzOjI4OiJodHRwczovL2J1c2luZXNzLmdvb2dsZS5jb20vIjtzOjk6IndpZmlfbmFtZSI7TjtzOjEzOiJ3aWZpX3Bhc3N3b3JkIjtOO3M6MTQ6InNob3dfd2lmaV9pY29uIjtpOjA7czoxNDoidGFibGVfcmVxdWlyZWQiO2k6MDtzOjE0OiJzaG93X2xvZ29fdGV4dCI7aToxO3M6MTI6Im1ldGFfa2V5d29yZCI7TjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtOO3M6MzQ6InVwbG9hZF9mYXZfaWNvbl9hbmRyb2lkX2Nocm9tZV8xOTIiO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzUxMiI7TjtzOjMyOiJ1cGxvYWRfZmF2X2ljb25fYXBwbGVfdG91Y2hfaWNvbiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8xNiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8zMiI7TjtzOjc6ImZhdmljb24iO047czozNjoiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9kZXNrdG9wIjtpOjE7czozNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9tb2JpbGUiO2k6MTtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29wZW5fYnlfcXIiO2k6MDtzOjExOiJ3ZWJtYW5pZmVzdCI7TjtzOjE1OiJlbmFibGVfdGlwX3Nob3AiO2k6MTtzOjE0OiJlbmFibGVfdGlwX3BvcyI7aToxO3M6MjU6ImlzX3B3YV9pbnN0YWxsX2FsZXJ0X3Nob3ciO2k6MDtzOjE5OiJhdXRvX2NvbmZpcm1fb3JkZXJzIjtpOjA7czozNDoiYXV0b19jb25maXJtX29yZGVyc19iZWZvcmVfcGF5bWVudCI7aTowO3M6MzM6ImF1dG9fY29uZmlybV9vcmRlcnNfYWZ0ZXJfcGF5bWVudCI7aTowO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtpOjA7czoyMjoicXJfb3JkZXJfcmFkaXVzX21ldGVycyI7TjtzOjIzOiJzaG93X29yZGVyX3R5cGVfb3B0aW9ucyI7aToxO3M6MjQ6ImRpc2FibGVfb3JkZXJfdHlwZV9wb3B1cCI7aTowO3M6MjY6InJlc3RhdXJhbnRfb3Blbl9jbG9zZV9tb2RlIjtzOjQ6ImF1dG8iO3M6MzM6InJlc3RhdXJhbnRfbWFudWFsX29wZW5fY2xvc2VfdHlwZSI7czo0OiJ0aW1lIjtzOjE2OiJtYW51YWxfb3Blbl90aW1lIjtOO3M6MTc6Im1hbnVhbF9jbG9zZV90aW1lIjtOO3M6MjE6ImlzX3RlbXBvcmFyaWx5X2Nsb3NlZCI7aTowO3M6MjE6ImRlZmF1bHRfb3JkZXJfdHlwZV9pZCI7TjtzOjI3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9wb3MiO2k6MDtzOjM3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9jdXN0b21lcl9zaXRlIjtpOjA7czoyODoibWVudV9pdGVtX2RlZmF1bHRfaW1hZ2VfcGF0aCI7TjtzOjMxOiJkaXNhYmxlX21lbnVfaXRlbV9kZWZhdWx0X2ltYWdlIjtpOjA7czo4OiJ0YXhfbW9kZSI7czo1OiJvcmRlciI7czoxMzoidGF4X2luY2x1c2l2ZSI7aTowO3M6Mjc6ImluY2x1ZGVfY2hhcmdlc19pbl90YXhfYmFzZSI7aTowO3M6MjI6ImN1c3RvbWVyX3NpdGVfbGFuZ3VhZ2UiO3M6MjoiZW4iO3M6MjQ6ImVuYWJsZV9hZG1pbl9yZXNlcnZhdGlvbiI7aToxO3M6Mjc6ImVuYWJsZV9jdXN0b21lcl9yZXNlcnZhdGlvbiI7aToxO3M6MTg6Im1pbmltdW1fcGFydHlfc2l6ZSI7aToxO3M6MjY6InRhYmxlX2xvY2tfdGltZW91dF9taW51dGVzIjtpOjEwO3M6MTg6Im1vbGxpZV9jdXN0b21lcl9pZCI7TjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO2k6MTt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MTg6e3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtzOjg6ImRhdGV0aW1lIjtzOjE1OiJ0cmlhbF9leHBpcmVfb24iO3M6ODoiZGF0ZXRpbWUiO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czo4OiJkYXRldGltZSI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MjM6ImN1c3RvbV9kZWxpdmVyeV9vcHRpb25zIjtzOjU6ImFycmF5IjtzOjk6ImlzX2FjdGl2ZSI7czo3OiJib29sZWFuIjtzOjI0OiJlbmFibGVfYWRtaW5fcmVzZXJ2YXRpb24iO3M6NzoiYm9vbGVhbiI7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtzOjc6ImJvb2xlYW4iO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtzOjc6ImJvb2xlYW4iO3M6MTA6ImFpX2VuYWJsZWQiO3M6NzoiYm9vbGVhbiI7czoxNjoiYWlfYWxsb3dlZF9yb2xlcyI7czo1OiJhcnJheSI7czoxOToiYWlfbW9udGhseV9yZXNldF9hdCI7czo0OiJkYXRlIjtzOjIxOiJpc190ZW1wb3JhcmlseV9jbG9zZWQiO3M6NzoiYm9vbGVhbiI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjY6InN0cmluZyI7czozMToiZGlzYWJsZV9tZW51X2l0ZW1fZGVmYXVsdF9pbWFnZSI7czo3OiJib29sZWFuIjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO3M6NzoiYm9vbGVhbiI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToyOntpOjA7czo4OiJsb2dvX3VybCI7aToxO3M6MTM6ImRhcmtfbG9nb191cmwiO31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjQ6e3M6ODoiYnJhbmNoZXMiO086Mzk6IklsbHVtaW5hdGVcRGF0YWJhc2VcRWxvcXVlbnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntpOjA7TzoxNzoiQXBwXE1vZGVsc1xCcmFuY2giOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjg6ImJyYW5jaGVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MjM6e3M6MjoiaWQiO2k6MTtzOjExOiJ1bmlxdWVfaGFzaCI7czoyMDoiMTE3MDQ0ZjNmYjBiYjc5Mzg2OTMiO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjQ6Im5hbWUiO3M6MTA6IkthY2NoaSBWYWkiO3M6MTg6ImNsb25lZF9icmFuY2hfbmFtZSI7TjtzOjE2OiJjbG9uZWRfYnJhbmNoX2lkIjtOO3M6MTM6ImlzX21lbnVfY2xvbmUiO2k6MDtzOjI0OiJpc19pdGVtX2NhdGVnb3JpZXNfY2xvbmUiO2k6MDtzOjE5OiJpc19tZW51X2l0ZW1zX2Nsb25lIjtpOjA7czoyMzoiaXNfaXRlbV9tb2RpZmllcnNfY2xvbmUiO2k6MDtzOjI5OiJpc19jbG9uZV9yZXNlcnZhdGlvbl9zZXR0aW5ncyI7aTowO3M6MjY6ImlzX2Nsb25lX2RlbGl2ZXJ5X3NldHRpbmdzIjtpOjA7czoyMDoiaXNfY2xvbmVfa290X3NldHRpbmciO2k6MDtzOjI1OiJpc19tb2RpZmllcnNfZ3JvdXBzX2Nsb25lIjtpOjA7czo3OiJhZGRyZXNzIjtzOjIxOiJEaGFubW9uZGksIERoYWthLTEyMDUiO3M6OToiY3JfbnVtYmVyIjtOO3M6MTA6InZhdF9udW1iZXIiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMSAwNToxMzowMCI7czozOiJsYXQiO3M6MTA6IjI2LjkxMjQzMzYiO3M6MzoibG5nIjtzOjEwOiI3NS43ODcyNzE5IjtzOjEyOiJjb3VudF9vcmRlcnMiO2k6MjM7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjExOiIAKgBvcmlnaW5hbCI7YToyMzp7czoyOiJpZCI7aToxO3M6MTE6InVuaXF1ZV9oYXNoIjtzOjIwOiIxMTcwNDRmM2ZiMGJiNzkzODY5MyI7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6NDoibmFtZSI7czoxMDoiS2FjY2hpIFZhaSI7czoxODoiY2xvbmVkX2JyYW5jaF9uYW1lIjtOO3M6MTY6ImNsb25lZF9icmFuY2hfaWQiO047czoxMzoiaXNfbWVudV9jbG9uZSI7aTowO3M6MjQ6ImlzX2l0ZW1fY2F0ZWdvcmllc19jbG9uZSI7aTowO3M6MTk6ImlzX21lbnVfaXRlbXNfY2xvbmUiO2k6MDtzOjIzOiJpc19pdGVtX21vZGlmaWVyc19jbG9uZSI7aTowO3M6Mjk6ImlzX2Nsb25lX3Jlc2VydmF0aW9uX3NldHRpbmdzIjtpOjA7czoyNjoiaXNfY2xvbmVfZGVsaXZlcnlfc2V0dGluZ3MiO2k6MDtzOjIwOiJpc19jbG9uZV9rb3Rfc2V0dGluZyI7aTowO3M6MjU6ImlzX21vZGlmaWVyc19ncm91cHNfY2xvbmUiO2k6MDtzOjc6ImFkZHJlc3MiO3M6MjE6IkRoYW5tb25kaSwgRGhha2EtMTIwNSI7czo5OiJjcl9udW1iZXIiO047czoxMDoidmF0X251bWJlciI7TjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTExIDA1OjEzOjAwIjtzOjM6ImxhdCI7czoxMDoiMjYuOTEyNDMzNiI7czozOiJsbmciO3M6MTA6Ijc1Ljc4NzI3MTkiO3M6MTI6ImNvdW50X29yZGVycyI7aToyMztzOjEyOiJ0b3RhbF9vcmRlcnMiO2k6LTE7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjI6e3M6MzoibGF0IjtzOjU6ImZsb2F0IjtzOjM6ImxuZyI7czo1OiJmbG9hdCI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTozOntzOjEwOiJyZXN0YXVyYW50IjtPOjIxOiJBcHBcTW9kZWxzXFJlc3RhdXJhbnQiOjM5OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjExOiJyZXN0YXVyYW50cyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjk5OntzOjI6ImlkIjtpOjE7czo0OiJuYW1lIjtzOjEwOiJSZXN0YXVyYW50IjtzOjQ6Imhhc2giO3M6MTA6InJlc3RhdXJhbnQiO3M6NzoiYWRkcmVzcyI7czo1NDoiNDUsIE1JIFJvYWQsIEMgU2NoZW1lLCBKYWlwdXIsIFJhamFzdGhhbiAzMDIwMDEsIEluZGlhIjtzOjEyOiJwaG9uZV9udW1iZXIiO2k6MTQ2OTg0NTU4MjI7czoxMDoicGhvbmVfY29kZSI7aTo4ODA7czo1OiJlbWFpbCI7czoyNzoiZGVtby5yZXN0YXVyYW50QGV4YW1wbGUuY29tIjtzOjg6InRpbWV6b25lIjtzOjEwOiJBc2lhL0RoYWthIjtzOjExOiJ0aW1lX2Zvcm1hdCI7czo1OiJoOmkgQSI7czoxMToiZGF0ZV9mb3JtYXQiO3M6NToiZC9tL1kiO3M6OToidGhlbWVfaGV4IjtzOjc6IiNGOTczMTYiO3M6OToidGhlbWVfcmdiIjtzOjEyOiIyNDksIDExNSwgMjIiO3M6NDoibG9nbyI7czozNzoiZmNmZjc5N2Q3ZjY3YWIwMDcxZWY3MGFkNWFhOGRhZmQuanBlZyI7czo5OiJkYXJrX2xvZ28iO047czoxMDoiY291bnRyeV9pZCI7aToxOTtzOjE1OiJoaWRlX25ld19vcmRlcnMiO2k6MDtzOjIxOiJoaWRlX25ld19yZXNlcnZhdGlvbnMiO2k6MDtzOjIzOiJoaWRlX25ld193YWl0ZXJfcmVxdWVzdCI7aTowO3M6MTE6ImN1cnJlbmN5X2lkIjtpOjU7czoxMjoibGljZW5zZV90eXBlIjtzOjQ6ImZyZWUiO3M6OToiaXNfYWN0aXZlIjtpOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMCAwODoxOTo1OCI7czoyMzoiY3VzdG9tZXJfbG9naW5fcmVxdWlyZWQiO2k6MDtzOjg6ImFib3V0X3VzIjtzOjQzMToiPGRpdj4mbmJzcDtXZWxjb21lIHRvIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4sIHRoZSB1bHRpbWF0ZSBkZXN0aW5hdGlvbiBmb3IgYXV0aGVudGljLCBwcmVtaXVtIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4hIFdlIHRha2UgcHJpZGUgaW4gdXNpbmcgdHJhZGl0aW9uYWwgY29va2luZyBtZXRob2RzLCBzbG93LWNvb2tpbmcgdGVuZGVyIG11dHRvbiBhbmQgYXJvbWF0aWMgYmFzbWF0aSByaWNlIHRvIHBlcmZlY3Rpb24gd2l0aCBzZWNyZXQgc3BpY2VzLiBXaGV0aGVyIHlvdSdyZSBkaW5pbmcgaW4gd2l0aCBmYW1pbHkgb3Igb3JkZXJpbmcgYSBmZWFzdCBhdCBob21lLCB3ZSBwcm9taXNlIGFuIHVuZm9yZ2V0dGFibGUgdGFzdGUgb2YgdHJhZGl0aW9uLiBDb21lIHZpc2l0IHVzIG9yIG9yZGVyIG9ubGluZSB0b2RheSEmbmJzcDs8L2Rpdj4iO3M6MzA6ImFsbG93X2N1c3RvbWVyX2RlbGl2ZXJ5X29yZGVycyI7aToxO3M6Mjg6ImFsbG93X2N1c3RvbWVyX3BpY2t1cF9vcmRlcnMiO2k6MTtzOjE3OiJwaWNrdXBfZGF5c19yYW5nZSI7aTo3O3M6MjE6ImFsbG93X2N1c3RvbWVyX29yZGVycyI7aToxO3M6MjA6ImFsbG93X2RpbmVfaW5fb3JkZXJzIjtpOjE7czo4OiJzaG93X3ZlZyI7aToxO3M6MTA6InNob3dfaGFsYWwiO2k6MDtzOjEwOiJwYWNrYWdlX2lkIjtpOjM7czoxMjoicGFja2FnZV90eXBlIjtzOjg6ImxpZmV0aW1lIjtzOjY6InN0YXR1cyI7czo2OiJhY3RpdmUiO3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtOO3M6MTM6InRyaWFsX2VuZHNfYXQiO047czoxODoibGljZW5zZV91cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjIzOiJzdWJzY3JpcHRpb25fdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czo5OiJzdHJpcGVfaWQiO047czo3OiJwbV90eXBlIjtOO3M6MTI6InBtX2xhc3RfZm91ciI7TjtzOjI1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkIjtpOjE7czozMjoiZGVmYXVsdF90YWJsZV9yZXNlcnZhdGlvbl9zdGF0dXMiO3M6OToiQ29uZmlybWVkIjtzOjIwOiJkaXNhYmxlX3Nsb3RfbWludXRlcyI7aTozMDtzOjE1OiJhcHByb3ZhbF9zdGF0dXMiO3M6ODoiQXBwcm92ZWQiO3M6MTY6InJlamVjdGlvbl9yZWFzb24iO047czoxMzoiZmFjZWJvb2tfbGluayI7czoyNToiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tLyI7czoxNDoiaW5zdGFncmFtX2xpbmsiO3M6MjY6Imh0dHBzOi8vd3d3Lmluc3RhZ3JhbS5jb20vIjtzOjEyOiJ0d2l0dGVyX2xpbmsiO3M6MjQ6Imh0dHBzOi8vd3d3LnR3aXR0ZXIuY29tLyI7czo5OiJ5ZWxwX2xpbmsiO047czoyMDoiZ29vZ2xlX2J1c2luZXNzX2xpbmsiO3M6Mjg6Imh0dHBzOi8vYnVzaW5lc3MuZ29vZ2xlLmNvbS8iO3M6OToid2lmaV9uYW1lIjtOO3M6MTM6IndpZmlfcGFzc3dvcmQiO047czoxNDoic2hvd193aWZpX2ljb24iO2k6MDtzOjE0OiJ0YWJsZV9yZXF1aXJlZCI7aTowO3M6MTQ6InNob3dfbG9nb190ZXh0IjtpOjE7czoxMjoibWV0YV9rZXl3b3JkIjtOO3M6MTY6Im1ldGFfZGVzY3JpcHRpb24iO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzE5MiI7TjtzOjM0OiJ1cGxvYWRfZmF2X2ljb25fYW5kcm9pZF9jaHJvbWVfNTEyIjtOO3M6MzI6InVwbG9hZF9mYXZfaWNvbl9hcHBsZV90b3VjaF9pY29uIjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzE2IjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzMyIjtOO3M6NzoiZmF2aWNvbiI7TjtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX2Rlc2t0b3AiO2k6MTtzOjM1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX21vYmlsZSI7aToxO3M6MzY6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWRfb3Blbl9ieV9xciI7aTowO3M6MTE6IndlYm1hbmlmZXN0IjtOO3M6MTU6ImVuYWJsZV90aXBfc2hvcCI7aToxO3M6MTQ6ImVuYWJsZV90aXBfcG9zIjtpOjE7czoyNToiaXNfcHdhX2luc3RhbGxfYWxlcnRfc2hvdyI7aTowO3M6MTk6ImF1dG9fY29uZmlybV9vcmRlcnMiO2k6MDtzOjM0OiJhdXRvX2NvbmZpcm1fb3JkZXJzX2JlZm9yZV9wYXltZW50IjtpOjA7czozMzoiYXV0b19jb25maXJtX29yZGVyc19hZnRlcl9wYXltZW50IjtpOjA7czoyOToicmVzdHJpY3RfcXJfb3JkZXJfYnlfbG9jYXRpb24iO2k6MDtzOjIyOiJxcl9vcmRlcl9yYWRpdXNfbWV0ZXJzIjtOO3M6MjM6InNob3dfb3JkZXJfdHlwZV9vcHRpb25zIjtpOjE7czoyNDoiZGlzYWJsZV9vcmRlcl90eXBlX3BvcHVwIjtpOjA7czoyNjoicmVzdGF1cmFudF9vcGVuX2Nsb3NlX21vZGUiO3M6NDoiYXV0byI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjQ6InRpbWUiO3M6MTY6Im1hbnVhbF9vcGVuX3RpbWUiO047czoxNzoibWFudWFsX2Nsb3NlX3RpbWUiO047czoyMToiaXNfdGVtcG9yYXJpbHlfY2xvc2VkIjtpOjA7czoyMToiZGVmYXVsdF9vcmRlcl90eXBlX2lkIjtOO3M6Mjc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX3BvcyI7aTowO3M6Mzc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX2N1c3RvbWVyX3NpdGUiO2k6MDtzOjI4OiJtZW51X2l0ZW1fZGVmYXVsdF9pbWFnZV9wYXRoIjtOO3M6MzE6ImRpc2FibGVfbWVudV9pdGVtX2RlZmF1bHRfaW1hZ2UiO2k6MDtzOjg6InRheF9tb2RlIjtzOjU6Im9yZGVyIjtzOjEzOiJ0YXhfaW5jbHVzaXZlIjtpOjA7czoyNzoiaW5jbHVkZV9jaGFyZ2VzX2luX3RheF9iYXNlIjtpOjA7czoyMjoiY3VzdG9tZXJfc2l0ZV9sYW5ndWFnZSI7czoyOiJlbiI7czoyNDoiZW5hYmxlX2FkbWluX3Jlc2VydmF0aW9uIjtpOjE7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtpOjE7czoxODoibWluaW11bV9wYXJ0eV9zaXplIjtpOjE7czoyNjoidGFibGVfbG9ja190aW1lb3V0X21pbnV0ZXMiO2k6MTA7czoxODoibW9sbGllX2N1c3RvbWVyX2lkIjtOO3M6MzM6ImF1dG9fbWFya19vcmRlcl9jb21wbGV0ZWRfb25fcGFpZCI7aToxO31zOjExOiIAKgBvcmlnaW5hbCI7YTo5OTp7czoyOiJpZCI7aToxO3M6NDoibmFtZSI7czoxMDoiUmVzdGF1cmFudCI7czo0OiJoYXNoIjtzOjEwOiJyZXN0YXVyYW50IjtzOjc6ImFkZHJlc3MiO3M6NTQ6IjQ1LCBNSSBSb2FkLCBDIFNjaGVtZSwgSmFpcHVyLCBSYWphc3RoYW4gMzAyMDAxLCBJbmRpYSI7czoxMjoicGhvbmVfbnVtYmVyIjtzOjExOiIxNDY5ODQ1NTgyMiI7czoxMDoicGhvbmVfY29kZSI7czozOiI4ODAiO3M6NToiZW1haWwiO3M6Mjc6ImRlbW8ucmVzdGF1cmFudEBleGFtcGxlLmNvbSI7czo4OiJ0aW1lem9uZSI7czoxMDoiQXNpYS9EaGFrYSI7czoxMToidGltZV9mb3JtYXQiO3M6NToiaDppIEEiO3M6MTE6ImRhdGVfZm9ybWF0IjtzOjU6ImQvbS9ZIjtzOjk6InRoZW1lX2hleCI7czo3OiIjRjk3MzE2IjtzOjk6InRoZW1lX3JnYiI7czoxMjoiMjQ5LCAxMTUsIDIyIjtzOjQ6ImxvZ28iO3M6Mzc6ImZjZmY3OTdkN2Y2N2FiMDA3MWVmNzBhZDVhYThkYWZkLmpwZWciO3M6OToiZGFya19sb2dvIjtOO3M6MTA6ImNvdW50cnlfaWQiO2k6MTk7czoxNToiaGlkZV9uZXdfb3JkZXJzIjtpOjA7czoyMToiaGlkZV9uZXdfcmVzZXJ2YXRpb25zIjtpOjA7czoyMzoiaGlkZV9uZXdfd2FpdGVyX3JlcXVlc3QiO2k6MDtzOjExOiJjdXJyZW5jeV9pZCI7aTo1O3M6MTI6ImxpY2Vuc2VfdHlwZSI7czo0OiJmcmVlIjtzOjk6ImlzX2FjdGl2ZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDg6MTk6NTgiO3M6MjM6ImN1c3RvbWVyX2xvZ2luX3JlcXVpcmVkIjtpOjA7czo4OiJhYm91dF91cyI7czo0MzE6IjxkaXY+Jm5ic3A7V2VsY29tZSB0byA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+LCB0aGUgdWx0aW1hdGUgZGVzdGluYXRpb24gZm9yIGF1dGhlbnRpYywgcHJlbWl1bSA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+ISBXZSB0YWtlIHByaWRlIGluIHVzaW5nIHRyYWRpdGlvbmFsIGNvb2tpbmcgbWV0aG9kcywgc2xvdy1jb29raW5nIHRlbmRlciBtdXR0b24gYW5kIGFyb21hdGljIGJhc21hdGkgcmljZSB0byBwZXJmZWN0aW9uIHdpdGggc2VjcmV0IHNwaWNlcy4gV2hldGhlciB5b3UncmUgZGluaW5nIGluIHdpdGggZmFtaWx5IG9yIG9yZGVyaW5nIGEgZmVhc3QgYXQgaG9tZSwgd2UgcHJvbWlzZSBhbiB1bmZvcmdldHRhYmxlIHRhc3RlIG9mIHRyYWRpdGlvbi4gQ29tZSB2aXNpdCB1cyBvciBvcmRlciBvbmxpbmUgdG9kYXkhJm5ic3A7PC9kaXY+IjtzOjMwOiJhbGxvd19jdXN0b21lcl9kZWxpdmVyeV9vcmRlcnMiO2k6MTtzOjI4OiJhbGxvd19jdXN0b21lcl9waWNrdXBfb3JkZXJzIjtpOjE7czoxNzoicGlja3VwX2RheXNfcmFuZ2UiO2k6NztzOjIxOiJhbGxvd19jdXN0b21lcl9vcmRlcnMiO2k6MTtzOjIwOiJhbGxvd19kaW5lX2luX29yZGVycyI7aToxO3M6ODoic2hvd192ZWciO2k6MTtzOjEwOiJzaG93X2hhbGFsIjtpOjA7czoxMDoicGFja2FnZV9pZCI7aTozO3M6MTI6InBhY2thZ2VfdHlwZSI7czo4OiJsaWZldGltZSI7czo2OiJzdGF0dXMiO3M6NjoiYWN0aXZlIjtzOjE3OiJsaWNlbnNlX2V4cGlyZV9vbiI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6OToic3RyaXBlX2lkIjtOO3M6NzoicG1fdHlwZSI7TjtzOjEyOiJwbV9sYXN0X2ZvdXIiO047czoyNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZCI7aToxO3M6MzI6ImRlZmF1bHRfdGFibGVfcmVzZXJ2YXRpb25fc3RhdHVzIjtzOjk6IkNvbmZpcm1lZCI7czoyMDoiZGlzYWJsZV9zbG90X21pbnV0ZXMiO2k6MzA7czoxNToiYXBwcm92YWxfc3RhdHVzIjtzOjg6IkFwcHJvdmVkIjtzOjE2OiJyZWplY3Rpb25fcmVhc29uIjtOO3M6MTM6ImZhY2Vib29rX2xpbmsiO3M6MjU6Imh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS8iO3M6MTQ6Imluc3RhZ3JhbV9saW5rIjtzOjI2OiJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tLyI7czoxMjoidHdpdHRlcl9saW5rIjtzOjI0OiJodHRwczovL3d3dy50d2l0dGVyLmNvbS8iO3M6OToieWVscF9saW5rIjtOO3M6MjA6Imdvb2dsZV9idXNpbmVzc19saW5rIjtzOjI4OiJodHRwczovL2J1c2luZXNzLmdvb2dsZS5jb20vIjtzOjk6IndpZmlfbmFtZSI7TjtzOjEzOiJ3aWZpX3Bhc3N3b3JkIjtOO3M6MTQ6InNob3dfd2lmaV9pY29uIjtpOjA7czoxNDoidGFibGVfcmVxdWlyZWQiO2k6MDtzOjE0OiJzaG93X2xvZ29fdGV4dCI7aToxO3M6MTI6Im1ldGFfa2V5d29yZCI7TjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtOO3M6MzQ6InVwbG9hZF9mYXZfaWNvbl9hbmRyb2lkX2Nocm9tZV8xOTIiO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzUxMiI7TjtzOjMyOiJ1cGxvYWRfZmF2X2ljb25fYXBwbGVfdG91Y2hfaWNvbiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8xNiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8zMiI7TjtzOjc6ImZhdmljb24iO047czozNjoiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9kZXNrdG9wIjtpOjE7czozNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9tb2JpbGUiO2k6MTtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29wZW5fYnlfcXIiO2k6MDtzOjExOiJ3ZWJtYW5pZmVzdCI7TjtzOjE1OiJlbmFibGVfdGlwX3Nob3AiO2k6MTtzOjE0OiJlbmFibGVfdGlwX3BvcyI7aToxO3M6MjU6ImlzX3B3YV9pbnN0YWxsX2FsZXJ0X3Nob3ciO2k6MDtzOjE5OiJhdXRvX2NvbmZpcm1fb3JkZXJzIjtpOjA7czozNDoiYXV0b19jb25maXJtX29yZGVyc19iZWZvcmVfcGF5bWVudCI7aTowO3M6MzM6ImF1dG9fY29uZmlybV9vcmRlcnNfYWZ0ZXJfcGF5bWVudCI7aTowO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtpOjA7czoyMjoicXJfb3JkZXJfcmFkaXVzX21ldGVycyI7TjtzOjIzOiJzaG93X29yZGVyX3R5cGVfb3B0aW9ucyI7aToxO3M6MjQ6ImRpc2FibGVfb3JkZXJfdHlwZV9wb3B1cCI7aTowO3M6MjY6InJlc3RhdXJhbnRfb3Blbl9jbG9zZV9tb2RlIjtzOjQ6ImF1dG8iO3M6MzM6InJlc3RhdXJhbnRfbWFudWFsX29wZW5fY2xvc2VfdHlwZSI7czo0OiJ0aW1lIjtzOjE2OiJtYW51YWxfb3Blbl90aW1lIjtOO3M6MTc6Im1hbnVhbF9jbG9zZV90aW1lIjtOO3M6MjE6ImlzX3RlbXBvcmFyaWx5X2Nsb3NlZCI7aTowO3M6MjE6ImRlZmF1bHRfb3JkZXJfdHlwZV9pZCI7TjtzOjI3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9wb3MiO2k6MDtzOjM3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9jdXN0b21lcl9zaXRlIjtpOjA7czoyODoibWVudV9pdGVtX2RlZmF1bHRfaW1hZ2VfcGF0aCI7TjtzOjMxOiJkaXNhYmxlX21lbnVfaXRlbV9kZWZhdWx0X2ltYWdlIjtpOjA7czo4OiJ0YXhfbW9kZSI7czo1OiJvcmRlciI7czoxMzoidGF4X2luY2x1c2l2ZSI7aTowO3M6Mjc6ImluY2x1ZGVfY2hhcmdlc19pbl90YXhfYmFzZSI7aTowO3M6MjI6ImN1c3RvbWVyX3NpdGVfbGFuZ3VhZ2UiO3M6MjoiZW4iO3M6MjQ6ImVuYWJsZV9hZG1pbl9yZXNlcnZhdGlvbiI7aToxO3M6Mjc6ImVuYWJsZV9jdXN0b21lcl9yZXNlcnZhdGlvbiI7aToxO3M6MTg6Im1pbmltdW1fcGFydHlfc2l6ZSI7aToxO3M6MjY6InRhYmxlX2xvY2tfdGltZW91dF9taW51dGVzIjtpOjEwO3M6MTg6Im1vbGxpZV9jdXN0b21lcl9pZCI7TjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO2k6MTt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MTg6e3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtzOjg6ImRhdGV0aW1lIjtzOjE1OiJ0cmlhbF9leHBpcmVfb24iO3M6ODoiZGF0ZXRpbWUiO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czo4OiJkYXRldGltZSI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MjM6ImN1c3RvbV9kZWxpdmVyeV9vcHRpb25zIjtzOjU6ImFycmF5IjtzOjk6ImlzX2FjdGl2ZSI7czo3OiJib29sZWFuIjtzOjI0OiJlbmFibGVfYWRtaW5fcmVzZXJ2YXRpb24iO3M6NzoiYm9vbGVhbiI7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtzOjc6ImJvb2xlYW4iO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtzOjc6ImJvb2xlYW4iO3M6MTA6ImFpX2VuYWJsZWQiO3M6NzoiYm9vbGVhbiI7czoxNjoiYWlfYWxsb3dlZF9yb2xlcyI7czo1OiJhcnJheSI7czoxOToiYWlfbW9udGhseV9yZXNldF9hdCI7czo0OiJkYXRlIjtzOjIxOiJpc190ZW1wb3JhcmlseV9jbG9zZWQiO3M6NzoiYm9vbGVhbiI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjY6InN0cmluZyI7czozMToiZGlzYWJsZV9tZW51X2l0ZW1fZGVmYXVsdF9pbWFnZSI7czo3OiJib29sZWFuIjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO3M6NzoiYm9vbGVhbiI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToyOntpOjA7czo4OiJsb2dvX3VybCI7aToxO3M6MTM6ImRhcmtfbG9nb191cmwiO31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MDp7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO31zOjE3OiJjdXN0b21lcklwQWRkcmVzcyI7TjtzOjI0OiJlc3RpbWF0aW9uQmlsbGluZ0FkZHJlc3MiO2E6MDp7fXM6MTM6ImNvbGxlY3RUYXhJZHMiO2I6MDtzOjg6ImNvdXBvbklkIjtOO3M6MTU6InByb21vdGlvbkNvZGVJZCI7TjtzOjE5OiJhbGxvd1Byb21vdGlvbkNvZGVzIjtiOjA7fXM6MTU6ImRlbGl2ZXJ5U2V0dGluZyI7TjtzOjE0OiJyZWNlaXB0U2V0dGluZyI7TzoyNToiQXBwXE1vZGVsc1xSZWNlaXB0U2V0dGluZyI6MzM6e3M6MTM6IgAqAGNvbm5lY3Rpb24iO3M6NToibXlzcWwiO3M6ODoiACoAdGFibGUiO3M6MTY6InJlY2VpcHRfc2V0dGluZ3MiO3M6MTM6IgAqAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTA6IgAqAGtleVR5cGUiO3M6MzoiaW50IjtzOjEyOiJpbmNyZW1lbnRpbmciO2I6MTtzOjc6IgAqAHdpdGgiO2E6MDp7fXM6MTI6IgAqAHdpdGhDb3VudCI7YTowOnt9czoxOToicHJldmVudHNMYXp5TG9hZGluZyI7YjowO3M6MTA6IgAqAHBlclBhZ2UiO2k6MTU7czo2OiJleGlzdHMiO2I6MTtzOjE4OiJ3YXNSZWNlbnRseUNyZWF0ZWQiO2I6MDtzOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7czoxMzoiACoAYXR0cmlidXRlcyI7YToyNDp7czoyOiJpZCI7aToxO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjk6ImJyYW5jaF9pZCI7aToxO3M6MTg6InNob3dfY3VzdG9tZXJfbmFtZSI7aToxO3M6MjE6InNob3dfY3VzdG9tZXJfYWRkcmVzcyI7aTowO3M6MTk6InNob3dfY3VzdG9tZXJfcGhvbmUiO2k6MTtzOjE3OiJzaG93X3RhYmxlX251bWJlciI7aTowO3M6MTU6InBheW1lbnRfcXJfY29kZSI7TjtzOjIwOiJzaG93X3BheW1lbnRfcXJfY29kZSI7aTowO3M6MTE6InNob3dfd2FpdGVyIjtpOjA7czoxNjoic2hvd190b3RhbF9ndWVzdCI7aTowO3M6MjA6InNob3dfcmVzdGF1cmFudF9sb2dvIjtpOjE7czoyMDoic2hvd19yZXN0YXVyYW50X25hbWUiO2k6MTtzOjE2OiJzaG93X2JyYW5jaF9uYW1lIjtpOjE7czoxOToic2hvd19icmFuY2hfYWRkcmVzcyI7aToxO3M6MTQ6InNob3dfY3JfbnVtYmVyIjtpOjA7czoxNToic2hvd192YXRfbnVtYmVyIjtpOjA7czo4OiJzaG93X3RheCI7aTowO3M6MjA6InNob3dfcGF5bWVudF9kZXRhaWxzIjtpOjE7czoxOToic2hvd19wYXltZW50X3N0YXR1cyI7aTowO3M6MTU6InNob3dfb3JkZXJfdHlwZSI7aTowO3M6MTc6InJlY2VpcHRfbGFuZ3VhZ2VzIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDkgMTI6MDc6NTMiO31zOjExOiIAKgBvcmlnaW5hbCI7YToyNDp7czoyOiJpZCI7aToxO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjk6ImJyYW5jaF9pZCI7aToxO3M6MTg6InNob3dfY3VzdG9tZXJfbmFtZSI7aToxO3M6MjE6InNob3dfY3VzdG9tZXJfYWRkcmVzcyI7aTowO3M6MTk6InNob3dfY3VzdG9tZXJfcGhvbmUiO2k6MTtzOjE3OiJzaG93X3RhYmxlX251bWJlciI7aTowO3M6MTU6InBheW1lbnRfcXJfY29kZSI7TjtzOjIwOiJzaG93X3BheW1lbnRfcXJfY29kZSI7aTowO3M6MTE6InNob3dfd2FpdGVyIjtpOjA7czoxNjoic2hvd190b3RhbF9ndWVzdCI7aTowO3M6MjA6InNob3dfcmVzdGF1cmFudF9sb2dvIjtpOjE7czoyMDoic2hvd19yZXN0YXVyYW50X25hbWUiO2k6MTtzOjE2OiJzaG93X2JyYW5jaF9uYW1lIjtpOjE7czoxOToic2hvd19icmFuY2hfYWRkcmVzcyI7aToxO3M6MTQ6InNob3dfY3JfbnVtYmVyIjtpOjA7czoxNToic2hvd192YXRfbnVtYmVyIjtpOjA7czo4OiJzaG93X3RheCI7aTowO3M6MjA6InNob3dfcGF5bWVudF9kZXRhaWxzIjtpOjE7czoxOToic2hvd19wYXltZW50X3N0YXR1cyI7aTowO3M6MTU6InNob3dfb3JkZXJfdHlwZSI7aTowO3M6MTc6InJlY2VpcHRfbGFuZ3VhZ2VzIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDkgMTI6MDc6NTMiO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YToxOntzOjE3OiJyZWNlaXB0X2xhbmd1YWdlcyI7czo1OiJhcnJheSI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToxOntpOjA7czoxOToicGF5bWVudF9xcl9jb2RlX3VybCI7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTowOnt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fX19czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjExOntpOjA7czo0OiJuYW1lIjtpOjE7czo3OiJhZGRyZXNzIjtpOjI7czo5OiJjcl9udW1iZXIiO2k6MztzOjEwOiJ2YXRfbnVtYmVyIjtpOjQ7czo1OiJwaG9uZSI7aTo1O3M6NToiZW1haWwiO2k6NjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjc7czo5OiJpc19hY3RpdmUiO2k6ODtzOjExOiJ1bmlxdWVfaGFzaCI7aTo5O3M6MzoibGF0IjtpOjEwO3M6MzoibG5nIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fX1pOjE7TzoxNzoiQXBwXE1vZGVsc1xCcmFuY2giOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjg6ImJyYW5jaGVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MjM6e3M6MjoiaWQiO2k6MjtzOjExOiJ1bmlxdWVfaGFzaCI7czoyMDoiNDlkMzE1YmM3YTk4OTA0NzIzMDgiO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjQ6Im5hbWUiO3M6NToiRGVsaGkiO3M6MTg6ImNsb25lZF9icmFuY2hfbmFtZSI7TjtzOjE2OiJjbG9uZWRfYnJhbmNoX2lkIjtOO3M6MTM6ImlzX21lbnVfY2xvbmUiO2k6MDtzOjI0OiJpc19pdGVtX2NhdGVnb3JpZXNfY2xvbmUiO2k6MDtzOjE5OiJpc19tZW51X2l0ZW1zX2Nsb25lIjtpOjA7czoyMzoiaXNfaXRlbV9tb2RpZmllcnNfY2xvbmUiO2k6MDtzOjI5OiJpc19jbG9uZV9yZXNlcnZhdGlvbl9zZXR0aW5ncyI7aTowO3M6MjY6ImlzX2Nsb25lX2RlbGl2ZXJ5X3NldHRpbmdzIjtpOjA7czoyMDoiaXNfY2xvbmVfa290X3NldHRpbmciO2k6MDtzOjI1OiJpc19tb2RpZmllcnNfZ3JvdXBzX2Nsb25lIjtpOjA7czo3OiJhZGRyZXNzIjtzOjUxOiIxMiwgQ29ubmF1Z2h0IFBsYWNlLCBOZXcgRGVsaGksIERlbGhpIDExMDAwMSwgSW5kaWEiO3M6OToiY3JfbnVtYmVyIjtOO3M6MTA6InZhdF9udW1iZXIiO047czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOSI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOSI7czozOiJsYXQiO3M6MTA6IjI4LjYyODQ1NDEiO3M6MzoibG5nIjtzOjEwOiI3Ny4yMDY5ODE2IjtzOjEyOiJjb3VudF9vcmRlcnMiO2k6MDtzOjEyOiJ0b3RhbF9vcmRlcnMiO2k6LTE7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjIzOntzOjI6ImlkIjtpOjI7czoxMToidW5pcXVlX2hhc2giO3M6MjA6IjQ5ZDMxNWJjN2E5ODkwNDcyMzA4IjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czo0OiJuYW1lIjtzOjU6IkRlbGhpIjtzOjE4OiJjbG9uZWRfYnJhbmNoX25hbWUiO047czoxNjoiY2xvbmVkX2JyYW5jaF9pZCI7TjtzOjEzOiJpc19tZW51X2Nsb25lIjtpOjA7czoyNDoiaXNfaXRlbV9jYXRlZ29yaWVzX2Nsb25lIjtpOjA7czoxOToiaXNfbWVudV9pdGVtc19jbG9uZSI7aTowO3M6MjM6ImlzX2l0ZW1fbW9kaWZpZXJzX2Nsb25lIjtpOjA7czoyOToiaXNfY2xvbmVfcmVzZXJ2YXRpb25fc2V0dGluZ3MiO2k6MDtzOjI2OiJpc19jbG9uZV9kZWxpdmVyeV9zZXR0aW5ncyI7aTowO3M6MjA6ImlzX2Nsb25lX2tvdF9zZXR0aW5nIjtpOjA7czoyNToiaXNfbW9kaWZpZXJzX2dyb3Vwc19jbG9uZSI7aTowO3M6NzoiYWRkcmVzcyI7czo1MToiMTIsIENvbm5hdWdodCBQbGFjZSwgTmV3IERlbGhpLCBEZWxoaSAxMTAwMDEsIEluZGlhIjtzOjk6ImNyX251bWJlciI7TjtzOjEwOiJ2YXRfbnVtYmVyIjtOO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDkiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDkiO3M6MzoibGF0IjtzOjEwOiIyOC42Mjg0NTQxIjtzOjM6ImxuZyI7czoxMDoiNzcuMjA2OTgxNiI7czoxMjoiY291bnRfb3JkZXJzIjtpOjA7czoxMjoidG90YWxfb3JkZXJzIjtpOi0xO31zOjEwOiIAKgBjaGFuZ2VzIjthOjA6e31zOjExOiIAKgBwcmV2aW91cyI7YTowOnt9czo4OiIAKgBjYXN0cyI7YToyOntzOjM6ImxhdCI7czo1OiJmbG9hdCI7czozOiJsbmciO3M6NToiZmxvYXQiO31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YToxMTp7aTowO3M6NDoibmFtZSI7aToxO3M6NzoiYWRkcmVzcyI7aToyO3M6OToiY3JfbnVtYmVyIjtpOjM7czoxMDoidmF0X251bWJlciI7aTo0O3M6NToicGhvbmUiO2k6NTtzOjU6ImVtYWlsIjtpOjY7czoxMzoicmVzdGF1cmFudF9pZCI7aTo3O3M6OToiaXNfYWN0aXZlIjtpOjg7czoxMToidW5pcXVlX2hhc2giO2k6OTtzOjM6ImxhdCI7aToxMDtzOjM6ImxuZyI7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO319aToyO086MTc6IkFwcFxNb2RlbHNcQnJhbmNoIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czo4OiJicmFuY2hlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjIzOntzOjI6ImlkIjtpOjM7czoxMToidW5pcXVlX2hhc2giO3M6MjA6IjBjNzA5YmM5NGU1ZDUxNjdkMDE4IjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czo0OiJuYW1lIjtzOjExOiJTdWx0YW4gRGluZSI7czoxODoiY2xvbmVkX2JyYW5jaF9uYW1lIjtOO3M6MTY6ImNsb25lZF9icmFuY2hfaWQiO047czoxMzoiaXNfbWVudV9jbG9uZSI7aTowO3M6MjQ6ImlzX2l0ZW1fY2F0ZWdvcmllc19jbG9uZSI7aTowO3M6MTk6ImlzX21lbnVfaXRlbXNfY2xvbmUiO2k6MDtzOjIzOiJpc19pdGVtX21vZGlmaWVyc19jbG9uZSI7aTowO3M6Mjk6ImlzX2Nsb25lX3Jlc2VydmF0aW9uX3NldHRpbmdzIjtpOjA7czoyNjoiaXNfY2xvbmVfZGVsaXZlcnlfc2V0dGluZ3MiO2k6MDtzOjIwOiJpc19jbG9uZV9rb3Rfc2V0dGluZyI7aTowO3M6MjU6ImlzX21vZGlmaWVyc19ncm91cHNfY2xvbmUiO2k6MDtzOjc6ImFkZHJlc3MiO3M6NDk6Ik1pcnB1ciAxMCBSb2FkLCBEaGFrYSwgRGhha2EgRGl2aXNpb24sIEJhbmdsYWRlc2giO3M6OToiY3JfbnVtYmVyIjtzOjIxOiJUUkFEL0ROQ0MvMDQxODUyLzIwMjYiO3M6MTA6InZhdF9udW1iZXIiO3M6MjA6ImUtVElOIDogNTE4NDkzMDI3NDYxIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTEwIDA2OjM0OjQ5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTExIDA1OjI3OjUxIjtzOjM6ImxhdCI7czoxMDoiMjMuODAwNzUyNSI7czozOiJsbmciO3M6MTA6IjkwLjM1NjU3NzkiO3M6MTI6ImNvdW50X29yZGVycyI7aToyMDtzOjEyOiJ0b3RhbF9vcmRlcnMiO2k6LTE7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjIzOntzOjI6ImlkIjtpOjM7czoxMToidW5pcXVlX2hhc2giO3M6MjA6IjBjNzA5YmM5NGU1ZDUxNjdkMDE4IjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czo0OiJuYW1lIjtzOjExOiJTdWx0YW4gRGluZSI7czoxODoiY2xvbmVkX2JyYW5jaF9uYW1lIjtOO3M6MTY6ImNsb25lZF9icmFuY2hfaWQiO047czoxMzoiaXNfbWVudV9jbG9uZSI7aTowO3M6MjQ6ImlzX2l0ZW1fY2F0ZWdvcmllc19jbG9uZSI7aTowO3M6MTk6ImlzX21lbnVfaXRlbXNfY2xvbmUiO2k6MDtzOjIzOiJpc19pdGVtX21vZGlmaWVyc19jbG9uZSI7aTowO3M6Mjk6ImlzX2Nsb25lX3Jlc2VydmF0aW9uX3NldHRpbmdzIjtpOjA7czoyNjoiaXNfY2xvbmVfZGVsaXZlcnlfc2V0dGluZ3MiO2k6MDtzOjIwOiJpc19jbG9uZV9rb3Rfc2V0dGluZyI7aTowO3M6MjU6ImlzX21vZGlmaWVyc19ncm91cHNfY2xvbmUiO2k6MDtzOjc6ImFkZHJlc3MiO3M6NDk6Ik1pcnB1ciAxMCBSb2FkLCBEaGFrYSwgRGhha2EgRGl2aXNpb24sIEJhbmdsYWRlc2giO3M6OToiY3JfbnVtYmVyIjtzOjIxOiJUUkFEL0ROQ0MvMDQxODUyLzIwMjYiO3M6MTA6InZhdF9udW1iZXIiO3M6MjA6ImUtVElOIDogNTE4NDkzMDI3NDYxIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTEwIDA2OjM0OjQ5IjtzOjEwOiJ1cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTExIDA1OjI3OjUxIjtzOjM6ImxhdCI7czoxMDoiMjMuODAwNzUyNSI7czozOiJsbmciO3M6MTA6IjkwLjM1NjU3NzkiO3M6MTI6ImNvdW50X29yZGVycyI7aToyMDtzOjEyOiJ0b3RhbF9vcmRlcnMiO2k6LTE7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjI6e3M6MzoibGF0IjtzOjU6ImZsb2F0IjtzOjM6ImxuZyI7czo1OiJmbG9hdCI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YTowOnt9czoxMDoiACoAdG91Y2hlcyI7YTowOnt9czoyNzoiACoAcmVsYXRpb25BdXRvbG9hZENhbGxiYWNrIjtOO3M6MjY6IgAqAHJlbGF0aW9uQXV0b2xvYWRDb250ZXh0IjtOO3M6MTA6InRpbWVzdGFtcHMiO2I6MTtzOjEzOiJ1c2VzVW5pcXVlSWRzIjtiOjA7czo5OiIAKgBoaWRkZW4iO2E6MDp7fXM6MTA6IgAqAHZpc2libGUiO2E6MDp7fXM6MTE6IgAqAGZpbGxhYmxlIjthOjExOntpOjA7czo0OiJuYW1lIjtpOjE7czo3OiJhZGRyZXNzIjtpOjI7czo5OiJjcl9udW1iZXIiO2k6MztzOjEwOiJ2YXRfbnVtYmVyIjtpOjQ7czo1OiJwaG9uZSI7aTo1O3M6NToiZW1haWwiO2k6NjtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjc7czo5OiJpc19hY3RpdmUiO2k6ODtzOjExOiJ1bmlxdWVfaGFzaCI7aTo5O3M6MzoibGF0IjtpOjEwO3M6MzoibG5nIjt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fX19czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjg6ImN1cnJlbmN5IjtPOjE5OiJBcHBcTW9kZWxzXEN1cnJlbmN5IjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czoxMDoiY3VycmVuY2llcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjEyOntzOjI6ImlkIjtpOjU7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6MTM6ImN1cnJlbmN5X25hbWUiO3M6NDoiVGFrYSI7czoxMzoiY3VycmVuY3lfY29kZSI7czozOiJCRFQiO3M6MTU6ImN1cnJlbmN5X3N5bWJvbCI7czozOiLgp7MiO3M6MTc6ImN1cnJlbmN5X3Bvc2l0aW9uIjtzOjQ6ImxlZnQiO3M6MTM6Im5vX29mX2RlY2ltYWwiO2k6MDtzOjE4OiJ0aG91c2FuZF9zZXBhcmF0b3IiO3M6MToiLCI7czoxNzoiZGVjaW1hbF9zZXBhcmF0b3IiO3M6MToiLiI7czoxMzoiZXhjaGFuZ2VfcmF0ZSI7TjtzOjk6InVzZF9wcmljZSI7TjtzOjE3OiJpc19jcnlwdG9jdXJyZW5jeSI7czoyOiJubyI7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjEyOntzOjI6ImlkIjtpOjU7czoxMzoicmVzdGF1cmFudF9pZCI7aToxO3M6MTM6ImN1cnJlbmN5X25hbWUiO3M6NDoiVGFrYSI7czoxMzoiY3VycmVuY3lfY29kZSI7czozOiJCRFQiO3M6MTU6ImN1cnJlbmN5X3N5bWJvbCI7czozOiLgp7MiO3M6MTc6ImN1cnJlbmN5X3Bvc2l0aW9uIjtzOjQ6ImxlZnQiO3M6MTM6Im5vX29mX2RlY2ltYWwiO2k6MDtzOjE4OiJ0aG91c2FuZF9zZXBhcmF0b3IiO3M6MToiLCI7czoxNzoiZGVjaW1hbF9zZXBhcmF0b3IiO3M6MToiLiI7czoxMzoiZXhjaGFuZ2VfcmF0ZSI7TjtzOjk6InVzZF9wcmljZSI7TjtzOjE3OiJpc19jcnlwdG9jdXJyZW5jeSI7czoyOiJubyI7fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjA6e31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjA7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTowOnt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoxOiIqIjt9fXM6NzoicGFja2FnZSI7TzoxODoiQXBwXE1vZGVsc1xQYWNrYWdlIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czo4OiJwYWNrYWdlcyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjQ1OntzOjI6ImlkIjtpOjM7czoxMjoicGFja2FnZV9uYW1lIjtzOjk6IkxpZmUgVGltZSI7czo1OiJwcmljZSI7czo2OiIxOTkuMDAiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDk6Mjc6MjAiO3M6MTE6ImN1cnJlbmN5X2lkIjtpOjE7czoxMToiZGVzY3JpcHRpb24iO3M6MzM6IlRoaXMgaXMgYSBsaWZldGltZSBhY2Nlc3MgcGFja2FnZSI7czoxMjoiYW5udWFsX3ByaWNlIjtOO3M6MTM6Im1vbnRobHlfcHJpY2UiO047czoxNDoibW9udGhseV9zdGF0dXMiO2k6MDtzOjEzOiJhbm51YWxfc3RhdHVzIjtpOjA7czoyMToic3RyaXBlX2FubnVhbF9wbGFuX2lkIjtOO3M6MjI6InN0cmlwZV9tb250aGx5X3BsYW5faWQiO047czoyMzoicmF6b3JwYXlfYW5udWFsX3BsYW5faWQiO047czoyNDoicmF6b3JwYXlfbW9udGhseV9wbGFuX2lkIjtOO3M6MjY6ImZsdXR0ZXJ3YXZlX2FubnVhbF9wbGFuX2lkIjtOO3M6Mjc6ImZsdXR0ZXJ3YXZlX21vbnRobHlfcGxhbl9pZCI7TjtzOjIzOiJwYXlzdGFja19hbm51YWxfcGxhbl9pZCI7TjtzOjI0OiJwYXlzdGFja19tb250aGx5X3BsYW5faWQiO047czoyMToieGVuZGl0X2FubnVhbF9wbGFuX2lkIjtOO3M6MjI6InhlbmRpdF9tb250aGx5X3BsYW5faWQiO047czoyMjoicGFkZGxlX2FubnVhbF9wcmljZV9pZCI7TjtzOjIzOiJwYWRkbGVfbW9udGhseV9wcmljZV9pZCI7TjtzOjI0OiJwYWRkbGVfbGlmZXRpbWVfcHJpY2VfaWQiO047czoyMzoic3RyaXBlX2xpZmV0aW1lX3BsYW5faWQiO047czoyNToicmF6b3JwYXlfbGlmZXRpbWVfcGxhbl9pZCI7TjtzOjEzOiJiaWxsaW5nX2N5Y2xlIjtpOjA7czoxMDoic29ydF9vcmRlciI7aTozO3M6MTA6ImlzX3ByaXZhdGUiO2k6MDtzOjc6ImlzX2ZyZWUiO2k6MDtzOjE0OiJpc19yZWNvbW1lbmRlZCI7aToxO3M6MTI6InBhY2thZ2VfdHlwZSI7czo4OiJsaWZldGltZSI7czoxMjoidHJpYWxfc3RhdHVzIjtOO3M6MTA6InRyaWFsX2RheXMiO047czozMDoidHJpYWxfbm90aWZpY2F0aW9uX2JlZm9yZV9kYXlzIjtOO3M6MTM6InRyaWFsX21lc3NhZ2UiO047czoxOToiYWRkaXRpb25hbF9mZWF0dXJlcyI7czoxMTg6IlsiRXhwb3J0IFJlcG9ydCIsIlRhYmxlIFJlc2VydmF0aW9uIiwiUGF5bWVudCBHYXRld2F5IEludGVncmF0aW9uIiwiVGhlbWUgU2V0dGluZyIsIkN1c3RvbWVyIERpc3BsYXkiLCJDaGFuZ2UgQnJhbmNoIl0iO3M6MTI6ImJyYW5jaF9saW1pdCI7aTozO3M6MTQ6Im11bHRpcG9zX2xpbWl0IjtpOi0xO3M6MTY6Im1lbnVfaXRlbXNfbGltaXQiO2k6LTE7czoxMToib3JkZXJfbGltaXQiO2k6LTE7czoxMToic3RhZmZfbGltaXQiO2k6LTE7czoyMjoiYWlfbW9udGhseV90b2tlbl9saW1pdCI7aTotMTtzOjk6InNtc19jb3VudCI7aTowO3M6MTc6ImNhcnJ5X2ZvcndhcmRfc21zIjtpOjA7fXM6MTE6IgAqAG9yaWdpbmFsIjthOjQ1OntzOjI6ImlkIjtpOjM7czoxMjoicGFja2FnZV9uYW1lIjtzOjk6IkxpZmUgVGltZSI7czo1OiJwcmljZSI7czo2OiIxOTkuMDAiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDYiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDk6Mjc6MjAiO3M6MTE6ImN1cnJlbmN5X2lkIjtpOjE7czoxMToiZGVzY3JpcHRpb24iO3M6MzM6IlRoaXMgaXMgYSBsaWZldGltZSBhY2Nlc3MgcGFja2FnZSI7czoxMjoiYW5udWFsX3ByaWNlIjtOO3M6MTM6Im1vbnRobHlfcHJpY2UiO047czoxNDoibW9udGhseV9zdGF0dXMiO3M6MToiMCI7czoxMzoiYW5udWFsX3N0YXR1cyI7czoxOiIwIjtzOjIxOiJzdHJpcGVfYW5udWFsX3BsYW5faWQiO047czoyMjoic3RyaXBlX21vbnRobHlfcGxhbl9pZCI7TjtzOjIzOiJyYXpvcnBheV9hbm51YWxfcGxhbl9pZCI7TjtzOjI0OiJyYXpvcnBheV9tb250aGx5X3BsYW5faWQiO047czoyNjoiZmx1dHRlcndhdmVfYW5udWFsX3BsYW5faWQiO047czoyNzoiZmx1dHRlcndhdmVfbW9udGhseV9wbGFuX2lkIjtOO3M6MjM6InBheXN0YWNrX2FubnVhbF9wbGFuX2lkIjtOO3M6MjQ6InBheXN0YWNrX21vbnRobHlfcGxhbl9pZCI7TjtzOjIxOiJ4ZW5kaXRfYW5udWFsX3BsYW5faWQiO047czoyMjoieGVuZGl0X21vbnRobHlfcGxhbl9pZCI7TjtzOjIyOiJwYWRkbGVfYW5udWFsX3ByaWNlX2lkIjtOO3M6MjM6InBhZGRsZV9tb250aGx5X3ByaWNlX2lkIjtOO3M6MjQ6InBhZGRsZV9saWZldGltZV9wcmljZV9pZCI7TjtzOjIzOiJzdHJpcGVfbGlmZXRpbWVfcGxhbl9pZCI7TjtzOjI1OiJyYXpvcnBheV9saWZldGltZV9wbGFuX2lkIjtOO3M6MTM6ImJpbGxpbmdfY3ljbGUiO2k6MDtzOjEwOiJzb3J0X29yZGVyIjtpOjM7czoxMDoiaXNfcHJpdmF0ZSI7aTowO3M6NzoiaXNfZnJlZSI7aTowO3M6MTQ6ImlzX3JlY29tbWVuZGVkIjtpOjE7czoxMjoicGFja2FnZV90eXBlIjtzOjg6ImxpZmV0aW1lIjtzOjEyOiJ0cmlhbF9zdGF0dXMiO047czoxMDoidHJpYWxfZGF5cyI7TjtzOjMwOiJ0cmlhbF9ub3RpZmljYXRpb25fYmVmb3JlX2RheXMiO047czoxMzoidHJpYWxfbWVzc2FnZSI7TjtzOjE5OiJhZGRpdGlvbmFsX2ZlYXR1cmVzIjtzOjExODoiWyJFeHBvcnQgUmVwb3J0IiwiVGFibGUgUmVzZXJ2YXRpb24iLCJQYXltZW50IEdhdGV3YXkgSW50ZWdyYXRpb24iLCJUaGVtZSBTZXR0aW5nIiwiQ3VzdG9tZXIgRGlzcGxheSIsIkNoYW5nZSBCcmFuY2giXSI7czoxMjoiYnJhbmNoX2xpbWl0IjtpOjM7czoxNDoibXVsdGlwb3NfbGltaXQiO2k6LTE7czoxNjoibWVudV9pdGVtc19saW1pdCI7aTotMTtzOjExOiJvcmRlcl9saW1pdCI7aTotMTtzOjExOiJzdGFmZl9saW1pdCI7aTotMTtzOjIyOiJhaV9tb250aGx5X3Rva2VuX2xpbWl0IjtpOi0xO3M6OToic21zX2NvdW50IjtpOjA7czoxNzoiY2FycnlfZm9yd2FyZF9zbXMiO2k6MDt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6Mzp7czoxMjoicGFja2FnZV90eXBlIjtzOjIxOiJBcHBcRW51bXNcUGFja2FnZVR5cGUiO3M6MTA6InRyaWFsX2RheXMiO3M6NzoiaW50ZWdlciI7czozMDoidHJpYWxfbm90aWZpY2F0aW9uX2JlZm9yZV9kYXlzIjtzOjc6ImludGVnZXIiO31zOjE3OiIAKgBjbGFzc0Nhc3RDYWNoZSI7YTowOnt9czoyMToiACoAYXR0cmlidXRlQ2FzdENhY2hlIjthOjA6e31zOjEzOiIAKgBkYXRlRm9ybWF0IjtOO3M6MTA6IgAqAGFwcGVuZHMiO2E6MDp7fXM6MTk6IgAqAGRpc3BhdGNoZXNFdmVudHMiO2E6MDp7fXM6MTQ6IgAqAG9ic2VydmFibGVzIjthOjA6e31zOjEyOiIAKgByZWxhdGlvbnMiO2E6MDp7fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTowOnt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fX1zOjE1OiJwYXltZW50R2F0ZXdheXMiO086MzU6IkFwcFxNb2RlbHNcUGF5bWVudEdhdGV3YXlDcmVkZW50aWFsIjozMzp7czoxMzoiACoAY29ubmVjdGlvbiI7czo1OiJteXNxbCI7czo4OiIAKgB0YWJsZSI7czoyNzoicGF5bWVudF9nYXRld2F5X2NyZWRlbnRpYWxzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6Nzg6e3M6MjoiaWQiO2k6MTtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czoxMjoicmF6b3JwYXlfa2V5IjtOO3M6MTU6InJhem9ycGF5X3NlY3JldCI7TjtzOjE1OiJyYXpvcnBheV9zdGF0dXMiO2k6MDtzOjEwOiJzdHJpcGVfa2V5IjtOO3M6MTM6InN0cmlwZV9zZWNyZXQiO047czoxMzoic3RyaXBlX3N0YXR1cyI7aTowO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MjY6ImlzX2RpbmVfaW5fcGF5bWVudF9lbmFibGVkIjtpOjA7czoyNzoiaXNfZGVsaXZlcnlfcGF5bWVudF9lbmFibGVkIjtpOjA7czoyNToiaXNfcGlja3VwX3BheW1lbnRfZW5hYmxlZCI7aTowO3M6MjM6ImlzX2Nhc2hfcGF5bWVudF9lbmFibGVkIjtpOjA7czoyMToiaXNfcXJfcGF5bWVudF9lbmFibGVkIjtpOjA7czoyNjoiaXNfb2ZmbGluZV9wYXltZW50X2VuYWJsZWQiO2k6MDtzOjIyOiJvZmZsaW5lX3BheW1lbnRfZGV0YWlsIjtOO3M6MTM6InFyX2NvZGVfaW1hZ2UiO047czoxODoiZmx1dHRlcndhdmVfc3RhdHVzIjtpOjA7czoxNjoiZmx1dHRlcndhdmVfbW9kZSI7czo0OiJ0ZXN0IjtzOjIwOiJ0ZXN0X2ZsdXR0ZXJ3YXZlX2tleSI7TjtzOjIzOiJ0ZXN0X2ZsdXR0ZXJ3YXZlX3NlY3JldCI7TjtzOjIxOiJ0ZXN0X2ZsdXR0ZXJ3YXZlX2hhc2giO047czoyMDoibGl2ZV9mbHV0dGVyd2F2ZV9rZXkiO047czoyMzoibGl2ZV9mbHV0dGVyd2F2ZV9zZWNyZXQiO047czoyMToibGl2ZV9mbHV0dGVyd2F2ZV9oYXNoIjtOO3M6MzE6ImZsdXR0ZXJ3YXZlX3dlYmhvb2tfc2VjcmV0X2hhc2giO047czoxNjoicGF5cGFsX2NsaWVudF9pZCI7TjtzOjEzOiJwYXlwYWxfc2VjcmV0IjtOO3M6MTM6InBheXBhbF9zdGF0dXMiO2k6MDtzOjExOiJwYXlwYWxfbW9kZSI7czo3OiJzYW5kYm94IjtzOjI0OiJzYW5kYm94X3BheXBhbF9jbGllbnRfaWQiO047czoyMToic2FuZGJveF9wYXlwYWxfc2VjcmV0IjtOO3M6MTk6InBheWZhc3RfbWVyY2hhbnRfaWQiO047czoyMDoicGF5ZmFzdF9tZXJjaGFudF9rZXkiO047czoxODoicGF5ZmFzdF9wYXNzcGhyYXNlIjtOO3M6MTI6InBheWZhc3RfbW9kZSI7czo3OiJzYW5kYm94IjtzOjE0OiJwYXlmYXN0X3N0YXR1cyI7aTowO3M6MjQ6InRlc3RfcGF5ZmFzdF9tZXJjaGFudF9pZCI7TjtzOjI1OiJ0ZXN0X3BheWZhc3RfbWVyY2hhbnRfa2V5IjtOO3M6MjM6InRlc3RfcGF5ZmFzdF9wYXNzcGhyYXNlIjtOO3M6MTI6InBheXN0YWNrX2tleSI7TjtzOjE1OiJwYXlzdGFja19zZWNyZXQiO047czoyMzoicGF5c3RhY2tfbWVyY2hhbnRfZW1haWwiO047czoxNToicGF5c3RhY2tfc3RhdHVzIjtpOjA7czoxMzoicGF5c3RhY2tfbW9kZSI7czo3OiJzYW5kYm94IjtzOjE3OiJ0ZXN0X3BheXN0YWNrX2tleSI7TjtzOjIwOiJ0ZXN0X3BheXN0YWNrX3NlY3JldCI7TjtzOjI4OiJ0ZXN0X3BheXN0YWNrX21lcmNoYW50X2VtYWlsIjtOO3M6MjA6InBheXN0YWNrX3BheW1lbnRfdXJsIjtzOjIzOiJodHRwczovL2FwaS5wYXlzdGFjay5jbyI7czoxMzoieGVuZGl0X3N0YXR1cyI7aTowO3M6MTE6InhlbmRpdF9tb2RlIjtzOjc6InNhbmRib3giO3M6MjI6InRlc3RfeGVuZGl0X3B1YmxpY19rZXkiO047czoyMjoidGVzdF94ZW5kaXRfc2VjcmV0X2tleSI7TjtzOjIyOiJsaXZlX3hlbmRpdF9wdWJsaWNfa2V5IjtOO3M6MjI6ImxpdmVfeGVuZGl0X3NlY3JldF9rZXkiO047czoyNToidGVzdF94ZW5kaXRfd2ViaG9va190b2tlbiI7TjtzOjI1OiJsaXZlX3hlbmRpdF93ZWJob29rX3Rva2VuIjtOO3M6MTE6ImVwYXlfc3RhdHVzIjtpOjA7czo5OiJlcGF5X21vZGUiO3M6Nzoic2FuZGJveCI7czoxNDoiZXBheV9jbGllbnRfaWQiO047czoxODoiZXBheV9jbGllbnRfc2VjcmV0IjtOO3M6MTY6ImVwYXlfdGVybWluYWxfaWQiO047czoxOToidGVzdF9lcGF5X2NsaWVudF9pZCI7TjtzOjIzOiJ0ZXN0X2VwYXlfY2xpZW50X3NlY3JldCI7TjtzOjIxOiJ0ZXN0X2VwYXlfdGVybWluYWxfaWQiO047czoxMzoibW9sbGllX3N0YXR1cyI7aTowO3M6MTE6Im1vbGxpZV9tb2RlIjtzOjQ6InRlc3QiO3M6MTU6InRlc3RfbW9sbGllX2tleSI7TjtzOjE1OiJsaXZlX21vbGxpZV9rZXkiO047czoyMToibW9sbGllX3dlYmhvb2tfc2VjcmV0IjtOO3M6MTA6InRhcF9zdGF0dXMiO2k6MDtzOjg6InRhcF9tb2RlIjtzOjc6InNhbmRib3giO3M6MTU6InRhcF9tZXJjaGFudF9pZCI7TjtzOjE5OiJsaXZlX3RhcF9zZWNyZXRfa2V5IjtOO3M6MTk6ImxpdmVfdGFwX3B1YmxpY19rZXkiO047czoxOToidGVzdF90YXBfc2VjcmV0X2tleSI7TjtzOjE5OiJ0ZXN0X3RhcF9wdWJsaWNfa2V5IjtOO31zOjExOiIAKgBvcmlnaW5hbCI7YTo3ODp7czoyOiJpZCI7aToxO3M6MTM6InJlc3RhdXJhbnRfaWQiO2k6MTtzOjEyOiJyYXpvcnBheV9rZXkiO047czoxNToicmF6b3JwYXlfc2VjcmV0IjtOO3M6MTU6InJhem9ycGF5X3N0YXR1cyI7aTowO3M6MTA6InN0cmlwZV9rZXkiO047czoxMzoic3RyaXBlX3NlY3JldCI7TjtzOjEzOiJzdHJpcGVfc3RhdHVzIjtpOjA7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoyNjoiaXNfZGluZV9pbl9wYXltZW50X2VuYWJsZWQiO2k6MDtzOjI3OiJpc19kZWxpdmVyeV9wYXltZW50X2VuYWJsZWQiO2k6MDtzOjI1OiJpc19waWNrdXBfcGF5bWVudF9lbmFibGVkIjtpOjA7czoyMzoiaXNfY2FzaF9wYXltZW50X2VuYWJsZWQiO2k6MDtzOjIxOiJpc19xcl9wYXltZW50X2VuYWJsZWQiO2k6MDtzOjI2OiJpc19vZmZsaW5lX3BheW1lbnRfZW5hYmxlZCI7aTowO3M6MjI6Im9mZmxpbmVfcGF5bWVudF9kZXRhaWwiO047czoxMzoicXJfY29kZV9pbWFnZSI7TjtzOjE4OiJmbHV0dGVyd2F2ZV9zdGF0dXMiO2k6MDtzOjE2OiJmbHV0dGVyd2F2ZV9tb2RlIjtzOjQ6InRlc3QiO3M6MjA6InRlc3RfZmx1dHRlcndhdmVfa2V5IjtOO3M6MjM6InRlc3RfZmx1dHRlcndhdmVfc2VjcmV0IjtOO3M6MjE6InRlc3RfZmx1dHRlcndhdmVfaGFzaCI7TjtzOjIwOiJsaXZlX2ZsdXR0ZXJ3YXZlX2tleSI7TjtzOjIzOiJsaXZlX2ZsdXR0ZXJ3YXZlX3NlY3JldCI7TjtzOjIxOiJsaXZlX2ZsdXR0ZXJ3YXZlX2hhc2giO047czozMToiZmx1dHRlcndhdmVfd2ViaG9va19zZWNyZXRfaGFzaCI7TjtzOjE2OiJwYXlwYWxfY2xpZW50X2lkIjtOO3M6MTM6InBheXBhbF9zZWNyZXQiO047czoxMzoicGF5cGFsX3N0YXR1cyI7aTowO3M6MTE6InBheXBhbF9tb2RlIjtzOjc6InNhbmRib3giO3M6MjQ6InNhbmRib3hfcGF5cGFsX2NsaWVudF9pZCI7TjtzOjIxOiJzYW5kYm94X3BheXBhbF9zZWNyZXQiO047czoxOToicGF5ZmFzdF9tZXJjaGFudF9pZCI7TjtzOjIwOiJwYXlmYXN0X21lcmNoYW50X2tleSI7TjtzOjE4OiJwYXlmYXN0X3Bhc3NwaHJhc2UiO047czoxMjoicGF5ZmFzdF9tb2RlIjtzOjc6InNhbmRib3giO3M6MTQ6InBheWZhc3Rfc3RhdHVzIjtpOjA7czoyNDoidGVzdF9wYXlmYXN0X21lcmNoYW50X2lkIjtOO3M6MjU6InRlc3RfcGF5ZmFzdF9tZXJjaGFudF9rZXkiO047czoyMzoidGVzdF9wYXlmYXN0X3Bhc3NwaHJhc2UiO047czoxMjoicGF5c3RhY2tfa2V5IjtOO3M6MTU6InBheXN0YWNrX3NlY3JldCI7TjtzOjIzOiJwYXlzdGFja19tZXJjaGFudF9lbWFpbCI7TjtzOjE1OiJwYXlzdGFja19zdGF0dXMiO2k6MDtzOjEzOiJwYXlzdGFja19tb2RlIjtzOjc6InNhbmRib3giO3M6MTc6InRlc3RfcGF5c3RhY2tfa2V5IjtOO3M6MjA6InRlc3RfcGF5c3RhY2tfc2VjcmV0IjtOO3M6Mjg6InRlc3RfcGF5c3RhY2tfbWVyY2hhbnRfZW1haWwiO047czoyMDoicGF5c3RhY2tfcGF5bWVudF91cmwiO3M6MjM6Imh0dHBzOi8vYXBpLnBheXN0YWNrLmNvIjtzOjEzOiJ4ZW5kaXRfc3RhdHVzIjtpOjA7czoxMToieGVuZGl0X21vZGUiO3M6Nzoic2FuZGJveCI7czoyMjoidGVzdF94ZW5kaXRfcHVibGljX2tleSI7TjtzOjIyOiJ0ZXN0X3hlbmRpdF9zZWNyZXRfa2V5IjtOO3M6MjI6ImxpdmVfeGVuZGl0X3B1YmxpY19rZXkiO047czoyMjoibGl2ZV94ZW5kaXRfc2VjcmV0X2tleSI7TjtzOjI1OiJ0ZXN0X3hlbmRpdF93ZWJob29rX3Rva2VuIjtOO3M6MjU6ImxpdmVfeGVuZGl0X3dlYmhvb2tfdG9rZW4iO047czoxMToiZXBheV9zdGF0dXMiO2k6MDtzOjk6ImVwYXlfbW9kZSI7czo3OiJzYW5kYm94IjtzOjE0OiJlcGF5X2NsaWVudF9pZCI7TjtzOjE4OiJlcGF5X2NsaWVudF9zZWNyZXQiO047czoxNjoiZXBheV90ZXJtaW5hbF9pZCI7TjtzOjE5OiJ0ZXN0X2VwYXlfY2xpZW50X2lkIjtOO3M6MjM6InRlc3RfZXBheV9jbGllbnRfc2VjcmV0IjtOO3M6MjE6InRlc3RfZXBheV90ZXJtaW5hbF9pZCI7TjtzOjEzOiJtb2xsaWVfc3RhdHVzIjtpOjA7czoxMToibW9sbGllX21vZGUiO3M6NDoidGVzdCI7czoxNToidGVzdF9tb2xsaWVfa2V5IjtOO3M6MTU6ImxpdmVfbW9sbGllX2tleSI7TjtzOjIxOiJtb2xsaWVfd2ViaG9va19zZWNyZXQiO047czoxMDoidGFwX3N0YXR1cyI7aTowO3M6ODoidGFwX21vZGUiO3M6Nzoic2FuZGJveCI7czoxNToidGFwX21lcmNoYW50X2lkIjtOO3M6MTk6ImxpdmVfdGFwX3NlY3JldF9rZXkiO047czoxOToibGl2ZV90YXBfcHVibGljX2tleSI7TjtzOjE5OiJ0ZXN0X3RhcF9zZWNyZXRfa2V5IjtOO3M6MTk6InRlc3RfdGFwX3B1YmxpY19rZXkiO047fXM6MTA6IgAqAGNoYW5nZXMiO2E6MDp7fXM6MTE6IgAqAHByZXZpb3VzIjthOjA6e31zOjg6IgAqAGNhc3RzIjthOjQ6e3M6MTA6InN0cmlwZV9rZXkiO3M6OToiZW5jcnlwdGVkIjtzOjEyOiJyYXpvcnBheV9rZXkiO3M6OToiZW5jcnlwdGVkIjtzOjEzOiJzdHJpcGVfc2VjcmV0IjtzOjk6ImVuY3J5cHRlZCI7czoxNToicmF6b3JwYXlfc2VjcmV0IjtzOjk6ImVuY3J5cHRlZCI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToxOntpOjA7czoxNzoicXJfY29kZV9pbWFnZV91cmwiO31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MDp7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO319fXM6MTA6IgAqAHRvdWNoZXMiO2E6MDp7fXM6Mjc6IgAqAHJlbGF0aW9uQXV0b2xvYWRDYWxsYmFjayI7TjtzOjI2OiIAKgByZWxhdGlvbkF1dG9sb2FkQ29udGV4dCI7TjtzOjEwOiJ0aW1lc3RhbXBzIjtiOjE7czoxMzoidXNlc1VuaXF1ZUlkcyI7YjowO3M6OToiACoAaGlkZGVuIjthOjA6e31zOjEwOiIAKgB2aXNpYmxlIjthOjA6e31zOjExOiIAKgBmaWxsYWJsZSI7YTowOnt9czoxMDoiACoAZ3VhcmRlZCI7YToxOntpOjA7czoyOiJpZCI7fXM6MTc6ImN1c3RvbWVySXBBZGRyZXNzIjtOO3M6MjQ6ImVzdGltYXRpb25CaWxsaW5nQWRkcmVzcyI7YTowOnt9czoxMzoiY29sbGVjdFRheElkcyI7YjowO3M6ODoiY291cG9uSWQiO047czoxNToicHJvbW90aW9uQ29kZUlkIjtOO3M6MTk6ImFsbG93UHJvbW90aW9uQ29kZXMiO2I6MDt9czo2OiJicmFuY2giO3I6MTE4MjtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2NDoiM2M3NmViYTE5NTA1MjhkYTk1MjMyY2ZlMzcyYTRjNzhlOWIyYjUxNzEwMzkyYzk1ZDBlN2FjMWQwYmNhN2QyOSI7czo4OiJ0aW1lem9uZSI7czoxMDoiQXNpYS9EaGFrYSI7czoxMToiZGF0ZV9mb3JtYXQiO3M6NToiZC9tL1kiO3M6MTE6InRpbWVfZm9ybWF0IjtzOjU6Img6aSBBIjtzOjI0OiJjdXJyZW5jeV9mb3JtYXRfc2V0dGluZzUiO086MTk6IkFwcFxNb2RlbHNcQ3VycmVuY3kiOjMzOntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjEwOiJjdXJyZW5jaWVzIjtzOjEzOiIAKgBwcmltYXJ5S2V5IjtzOjI6ImlkIjtzOjEwOiIAKgBrZXlUeXBlIjtzOjM6ImludCI7czoxMjoiaW5jcmVtZW50aW5nIjtiOjE7czo3OiIAKgB3aXRoIjthOjA6e31zOjEyOiIAKgB3aXRoQ291bnQiO2E6MDp7fXM6MTk6InByZXZlbnRzTGF6eUxvYWRpbmciO2I6MDtzOjEwOiIAKgBwZXJQYWdlIjtpOjE1O3M6NjoiZXhpc3RzIjtiOjE7czoxODoid2FzUmVjZW50bHlDcmVhdGVkIjtiOjA7czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO3M6MTM6IgAqAGF0dHJpYnV0ZXMiO2E6MTI6e3M6MjoiaWQiO2k6NTtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czoxMzoiY3VycmVuY3lfbmFtZSI7czo0OiJUYWthIjtzOjEzOiJjdXJyZW5jeV9jb2RlIjtzOjM6IkJEVCI7czoxNToiY3VycmVuY3lfc3ltYm9sIjtzOjM6IuCnsyI7czoxNzoiY3VycmVuY3lfcG9zaXRpb24iO3M6NDoibGVmdCI7czoxMzoibm9fb2ZfZGVjaW1hbCI7aTowO3M6MTg6InRob3VzYW5kX3NlcGFyYXRvciI7czoxOiIsIjtzOjE3OiJkZWNpbWFsX3NlcGFyYXRvciI7czoxOiIuIjtzOjEzOiJleGNoYW5nZV9yYXRlIjtOO3M6OToidXNkX3ByaWNlIjtOO3M6MTc6ImlzX2NyeXB0b2N1cnJlbmN5IjtzOjI6Im5vIjt9czoxMToiACoAb3JpZ2luYWwiO2E6MTI6e3M6MjoiaWQiO2k6NTtzOjEzOiJyZXN0YXVyYW50X2lkIjtpOjE7czoxMzoiY3VycmVuY3lfbmFtZSI7czo0OiJUYWthIjtzOjEzOiJjdXJyZW5jeV9jb2RlIjtzOjM6IkJEVCI7czoxNToiY3VycmVuY3lfc3ltYm9sIjtzOjM6IuCnsyI7czoxNzoiY3VycmVuY3lfcG9zaXRpb24iO3M6NDoibGVmdCI7czoxMzoibm9fb2ZfZGVjaW1hbCI7aTowO3M6MTg6InRob3VzYW5kX3NlcGFyYXRvciI7czoxOiIsIjtzOjE3OiJkZWNpbWFsX3NlcGFyYXRvciI7czoxOiIuIjtzOjEzOiJleGNoYW5nZV9yYXRlIjtOO3M6OToidXNkX3ByaWNlIjtOO3M6MTc6ImlzX2NyeXB0b2N1cnJlbmN5IjtzOjI6Im5vIjt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MDp7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YTowOnt9czoxOToiACoAZGlzcGF0Y2hlc0V2ZW50cyI7YTowOnt9czoxNDoiACoAb2JzZXJ2YWJsZXMiO2E6MDp7fXM6MTI6IgAqAHJlbGF0aW9ucyI7YToxOntzOjEwOiJyZXN0YXVyYW50IjtPOjIxOiJBcHBcTW9kZWxzXFJlc3RhdXJhbnQiOjM5OntzOjEzOiIAKgBjb25uZWN0aW9uIjtzOjU6Im15c3FsIjtzOjg6IgAqAHRhYmxlIjtzOjExOiJyZXN0YXVyYW50cyI7czoxMzoiACoAcHJpbWFyeUtleSI7czoyOiJpZCI7czoxMDoiACoAa2V5VHlwZSI7czozOiJpbnQiO3M6MTI6ImluY3JlbWVudGluZyI7YjoxO3M6NzoiACoAd2l0aCI7YTowOnt9czoxMjoiACoAd2l0aENvdW50IjthOjA6e31zOjE5OiJwcmV2ZW50c0xhenlMb2FkaW5nIjtiOjA7czoxMDoiACoAcGVyUGFnZSI7aToxNTtzOjY6ImV4aXN0cyI7YjoxO3M6MTg6Indhc1JlY2VudGx5Q3JlYXRlZCI7YjowO3M6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDtzOjEzOiIAKgBhdHRyaWJ1dGVzIjthOjk5OntzOjI6ImlkIjtpOjE7czo0OiJuYW1lIjtzOjEwOiJSZXN0YXVyYW50IjtzOjQ6Imhhc2giO3M6MTA6InJlc3RhdXJhbnQiO3M6NzoiYWRkcmVzcyI7czo1NDoiNDUsIE1JIFJvYWQsIEMgU2NoZW1lLCBKYWlwdXIsIFJhamFzdGhhbiAzMDIwMDEsIEluZGlhIjtzOjEyOiJwaG9uZV9udW1iZXIiO2k6MTQ2OTg0NTU4MjI7czoxMDoicGhvbmVfY29kZSI7aTo4ODA7czo1OiJlbWFpbCI7czoyNzoiZGVtby5yZXN0YXVyYW50QGV4YW1wbGUuY29tIjtzOjg6InRpbWV6b25lIjtzOjEwOiJBc2lhL0RoYWthIjtzOjExOiJ0aW1lX2Zvcm1hdCI7czo1OiJoOmkgQSI7czoxMToiZGF0ZV9mb3JtYXQiO3M6NToiZC9tL1kiO3M6OToidGhlbWVfaGV4IjtzOjc6IiNGOTczMTYiO3M6OToidGhlbWVfcmdiIjtzOjEyOiIyNDksIDExNSwgMjIiO3M6NDoibG9nbyI7czozNzoiZmNmZjc5N2Q3ZjY3YWIwMDcxZWY3MGFkNWFhOGRhZmQuanBlZyI7czo5OiJkYXJrX2xvZ28iO047czoxMDoiY291bnRyeV9pZCI7aToxOTtzOjE1OiJoaWRlX25ld19vcmRlcnMiO2k6MDtzOjIxOiJoaWRlX25ld19yZXNlcnZhdGlvbnMiO2k6MDtzOjIzOiJoaWRlX25ld193YWl0ZXJfcmVxdWVzdCI7aTowO3M6MTE6ImN1cnJlbmN5X2lkIjtpOjU7czoxMjoibGljZW5zZV90eXBlIjtzOjQ6ImZyZWUiO3M6OToiaXNfYWN0aXZlIjtpOjE7czoxMDoiY3JlYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoxMDoidXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0xMCAwODoxOTo1OCI7czoyMzoiY3VzdG9tZXJfbG9naW5fcmVxdWlyZWQiO2k6MDtzOjg6ImFib3V0X3VzIjtzOjQzMToiPGRpdj4mbmJzcDtXZWxjb21lIHRvIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4sIHRoZSB1bHRpbWF0ZSBkZXN0aW5hdGlvbiBmb3IgYXV0aGVudGljLCBwcmVtaXVtIDxzdHJvbmc+U3VsdGFuIERpbmU8L3N0cm9uZz4hIFdlIHRha2UgcHJpZGUgaW4gdXNpbmcgdHJhZGl0aW9uYWwgY29va2luZyBtZXRob2RzLCBzbG93LWNvb2tpbmcgdGVuZGVyIG11dHRvbiBhbmQgYXJvbWF0aWMgYmFzbWF0aSByaWNlIHRvIHBlcmZlY3Rpb24gd2l0aCBzZWNyZXQgc3BpY2VzLiBXaGV0aGVyIHlvdSdyZSBkaW5pbmcgaW4gd2l0aCBmYW1pbHkgb3Igb3JkZXJpbmcgYSBmZWFzdCBhdCBob21lLCB3ZSBwcm9taXNlIGFuIHVuZm9yZ2V0dGFibGUgdGFzdGUgb2YgdHJhZGl0aW9uLiBDb21lIHZpc2l0IHVzIG9yIG9yZGVyIG9ubGluZSB0b2RheSEmbmJzcDs8L2Rpdj4iO3M6MzA6ImFsbG93X2N1c3RvbWVyX2RlbGl2ZXJ5X29yZGVycyI7aToxO3M6Mjg6ImFsbG93X2N1c3RvbWVyX3BpY2t1cF9vcmRlcnMiO2k6MTtzOjE3OiJwaWNrdXBfZGF5c19yYW5nZSI7aTo3O3M6MjE6ImFsbG93X2N1c3RvbWVyX29yZGVycyI7aToxO3M6MjA6ImFsbG93X2RpbmVfaW5fb3JkZXJzIjtpOjE7czo4OiJzaG93X3ZlZyI7aToxO3M6MTA6InNob3dfaGFsYWwiO2k6MDtzOjEwOiJwYWNrYWdlX2lkIjtpOjM7czoxMjoicGFja2FnZV90eXBlIjtzOjg6ImxpZmV0aW1lIjtzOjY6InN0YXR1cyI7czo2OiJhY3RpdmUiO3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtOO3M6MTM6InRyaWFsX2VuZHNfYXQiO047czoxODoibGljZW5zZV91cGRhdGVkX2F0IjtzOjE5OiIyMDI2LTA2LTA2IDA1OjQ0OjA4IjtzOjIzOiJzdWJzY3JpcHRpb25fdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czo5OiJzdHJpcGVfaWQiO047czo3OiJwbV90eXBlIjtOO3M6MTI6InBtX2xhc3RfZm91ciI7TjtzOjI1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkIjtpOjE7czozMjoiZGVmYXVsdF90YWJsZV9yZXNlcnZhdGlvbl9zdGF0dXMiO3M6OToiQ29uZmlybWVkIjtzOjIwOiJkaXNhYmxlX3Nsb3RfbWludXRlcyI7aTozMDtzOjE1OiJhcHByb3ZhbF9zdGF0dXMiO3M6ODoiQXBwcm92ZWQiO3M6MTY6InJlamVjdGlvbl9yZWFzb24iO047czoxMzoiZmFjZWJvb2tfbGluayI7czoyNToiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tLyI7czoxNDoiaW5zdGFncmFtX2xpbmsiO3M6MjY6Imh0dHBzOi8vd3d3Lmluc3RhZ3JhbS5jb20vIjtzOjEyOiJ0d2l0dGVyX2xpbmsiO3M6MjQ6Imh0dHBzOi8vd3d3LnR3aXR0ZXIuY29tLyI7czo5OiJ5ZWxwX2xpbmsiO047czoyMDoiZ29vZ2xlX2J1c2luZXNzX2xpbmsiO3M6Mjg6Imh0dHBzOi8vYnVzaW5lc3MuZ29vZ2xlLmNvbS8iO3M6OToid2lmaV9uYW1lIjtOO3M6MTM6IndpZmlfcGFzc3dvcmQiO047czoxNDoic2hvd193aWZpX2ljb24iO2k6MDtzOjE0OiJ0YWJsZV9yZXF1aXJlZCI7aTowO3M6MTQ6InNob3dfbG9nb190ZXh0IjtpOjE7czoxMjoibWV0YV9rZXl3b3JkIjtOO3M6MTY6Im1ldGFfZGVzY3JpcHRpb24iO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzE5MiI7TjtzOjM0OiJ1cGxvYWRfZmF2X2ljb25fYW5kcm9pZF9jaHJvbWVfNTEyIjtOO3M6MzI6InVwbG9hZF9mYXZfaWNvbl9hcHBsZV90b3VjaF9pY29uIjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzE2IjtOO3M6MTc6InVwbG9hZF9mYXZpY29uXzMyIjtOO3M6NzoiZmF2aWNvbiI7TjtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX2Rlc2t0b3AiO2k6MTtzOjM1OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29uX21vYmlsZSI7aToxO3M6MzY6ImlzX3dhaXRlcl9yZXF1ZXN0X2VuYWJsZWRfb3Blbl9ieV9xciI7aTowO3M6MTE6IndlYm1hbmlmZXN0IjtOO3M6MTU6ImVuYWJsZV90aXBfc2hvcCI7aToxO3M6MTQ6ImVuYWJsZV90aXBfcG9zIjtpOjE7czoyNToiaXNfcHdhX2luc3RhbGxfYWxlcnRfc2hvdyI7aTowO3M6MTk6ImF1dG9fY29uZmlybV9vcmRlcnMiO2k6MDtzOjM0OiJhdXRvX2NvbmZpcm1fb3JkZXJzX2JlZm9yZV9wYXltZW50IjtpOjA7czozMzoiYXV0b19jb25maXJtX29yZGVyc19hZnRlcl9wYXltZW50IjtpOjA7czoyOToicmVzdHJpY3RfcXJfb3JkZXJfYnlfbG9jYXRpb24iO2k6MDtzOjIyOiJxcl9vcmRlcl9yYWRpdXNfbWV0ZXJzIjtOO3M6MjM6InNob3dfb3JkZXJfdHlwZV9vcHRpb25zIjtpOjE7czoyNDoiZGlzYWJsZV9vcmRlcl90eXBlX3BvcHVwIjtpOjA7czoyNjoicmVzdGF1cmFudF9vcGVuX2Nsb3NlX21vZGUiO3M6NDoiYXV0byI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjQ6InRpbWUiO3M6MTY6Im1hbnVhbF9vcGVuX3RpbWUiO047czoxNzoibWFudWFsX2Nsb3NlX3RpbWUiO047czoyMToiaXNfdGVtcG9yYXJpbHlfY2xvc2VkIjtpOjA7czoyMToiZGVmYXVsdF9vcmRlcl90eXBlX2lkIjtOO3M6Mjc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX3BvcyI7aTowO3M6Mzc6ImhpZGVfbWVudV9pdGVtX2ltYWdlX29uX2N1c3RvbWVyX3NpdGUiO2k6MDtzOjI4OiJtZW51X2l0ZW1fZGVmYXVsdF9pbWFnZV9wYXRoIjtOO3M6MzE6ImRpc2FibGVfbWVudV9pdGVtX2RlZmF1bHRfaW1hZ2UiO2k6MDtzOjg6InRheF9tb2RlIjtzOjU6Im9yZGVyIjtzOjEzOiJ0YXhfaW5jbHVzaXZlIjtpOjA7czoyNzoiaW5jbHVkZV9jaGFyZ2VzX2luX3RheF9iYXNlIjtpOjA7czoyMjoiY3VzdG9tZXJfc2l0ZV9sYW5ndWFnZSI7czoyOiJlbiI7czoyNDoiZW5hYmxlX2FkbWluX3Jlc2VydmF0aW9uIjtpOjE7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtpOjE7czoxODoibWluaW11bV9wYXJ0eV9zaXplIjtpOjE7czoyNjoidGFibGVfbG9ja190aW1lb3V0X21pbnV0ZXMiO2k6MTA7czoxODoibW9sbGllX2N1c3RvbWVyX2lkIjtOO3M6MzM6ImF1dG9fbWFya19vcmRlcl9jb21wbGV0ZWRfb25fcGFpZCI7aToxO31zOjExOiIAKgBvcmlnaW5hbCI7YTo5OTp7czoyOiJpZCI7aToxO3M6NDoibmFtZSI7czoxMDoiUmVzdGF1cmFudCI7czo0OiJoYXNoIjtzOjEwOiJyZXN0YXVyYW50IjtzOjc6ImFkZHJlc3MiO3M6NTQ6IjQ1LCBNSSBSb2FkLCBDIFNjaGVtZSwgSmFpcHVyLCBSYWphc3RoYW4gMzAyMDAxLCBJbmRpYSI7czoxMjoicGhvbmVfbnVtYmVyIjtzOjExOiIxNDY5ODQ1NTgyMiI7czoxMDoicGhvbmVfY29kZSI7czozOiI4ODAiO3M6NToiZW1haWwiO3M6Mjc6ImRlbW8ucmVzdGF1cmFudEBleGFtcGxlLmNvbSI7czo4OiJ0aW1lem9uZSI7czoxMDoiQXNpYS9EaGFrYSI7czoxMToidGltZV9mb3JtYXQiO3M6NToiaDppIEEiO3M6MTE6ImRhdGVfZm9ybWF0IjtzOjU6ImQvbS9ZIjtzOjk6InRoZW1lX2hleCI7czo3OiIjRjk3MzE2IjtzOjk6InRoZW1lX3JnYiI7czoxMjoiMjQ5LCAxMTUsIDIyIjtzOjQ6ImxvZ28iO3M6Mzc6ImZjZmY3OTdkN2Y2N2FiMDA3MWVmNzBhZDVhYThkYWZkLmpwZWciO3M6OToiZGFya19sb2dvIjtOO3M6MTA6ImNvdW50cnlfaWQiO2k6MTk7czoxNToiaGlkZV9uZXdfb3JkZXJzIjtpOjA7czoyMToiaGlkZV9uZXdfcmVzZXJ2YXRpb25zIjtpOjA7czoyMzoiaGlkZV9uZXdfd2FpdGVyX3JlcXVlc3QiO2k6MDtzOjExOiJjdXJyZW5jeV9pZCI7aTo1O3M6MTI6ImxpY2Vuc2VfdHlwZSI7czo0OiJmcmVlIjtzOjk6ImlzX2FjdGl2ZSI7aToxO3M6MTA6ImNyZWF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6MTA6InVwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMTAgMDg6MTk6NTgiO3M6MjM6ImN1c3RvbWVyX2xvZ2luX3JlcXVpcmVkIjtpOjA7czo4OiJhYm91dF91cyI7czo0MzE6IjxkaXY+Jm5ic3A7V2VsY29tZSB0byA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+LCB0aGUgdWx0aW1hdGUgZGVzdGluYXRpb24gZm9yIGF1dGhlbnRpYywgcHJlbWl1bSA8c3Ryb25nPlN1bHRhbiBEaW5lPC9zdHJvbmc+ISBXZSB0YWtlIHByaWRlIGluIHVzaW5nIHRyYWRpdGlvbmFsIGNvb2tpbmcgbWV0aG9kcywgc2xvdy1jb29raW5nIHRlbmRlciBtdXR0b24gYW5kIGFyb21hdGljIGJhc21hdGkgcmljZSB0byBwZXJmZWN0aW9uIHdpdGggc2VjcmV0IHNwaWNlcy4gV2hldGhlciB5b3UncmUgZGluaW5nIGluIHdpdGggZmFtaWx5IG9yIG9yZGVyaW5nIGEgZmVhc3QgYXQgaG9tZSwgd2UgcHJvbWlzZSBhbiB1bmZvcmdldHRhYmxlIHRhc3RlIG9mIHRyYWRpdGlvbi4gQ29tZSB2aXNpdCB1cyBvciBvcmRlciBvbmxpbmUgdG9kYXkhJm5ic3A7PC9kaXY+IjtzOjMwOiJhbGxvd19jdXN0b21lcl9kZWxpdmVyeV9vcmRlcnMiO2k6MTtzOjI4OiJhbGxvd19jdXN0b21lcl9waWNrdXBfb3JkZXJzIjtpOjE7czoxNzoicGlja3VwX2RheXNfcmFuZ2UiO2k6NztzOjIxOiJhbGxvd19jdXN0b21lcl9vcmRlcnMiO2k6MTtzOjIwOiJhbGxvd19kaW5lX2luX29yZGVycyI7aToxO3M6ODoic2hvd192ZWciO2k6MTtzOjEwOiJzaG93X2hhbGFsIjtpOjA7czoxMDoicGFja2FnZV9pZCI7aTozO3M6MTI6InBhY2thZ2VfdHlwZSI7czo4OiJsaWZldGltZSI7czo2OiJzdGF0dXMiO3M6NjoiYWN0aXZlIjtzOjE3OiJsaWNlbnNlX2V4cGlyZV9vbiI7TjtzOjEzOiJ0cmlhbF9lbmRzX2F0IjtOO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czoxOToiMjAyNi0wNi0wNiAwNTo0NDowOCI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6MTk6IjIwMjYtMDYtMDYgMDU6NDQ6MDgiO3M6OToic3RyaXBlX2lkIjtOO3M6NzoicG1fdHlwZSI7TjtzOjEyOiJwbV9sYXN0X2ZvdXIiO047czoyNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZCI7aToxO3M6MzI6ImRlZmF1bHRfdGFibGVfcmVzZXJ2YXRpb25fc3RhdHVzIjtzOjk6IkNvbmZpcm1lZCI7czoyMDoiZGlzYWJsZV9zbG90X21pbnV0ZXMiO2k6MzA7czoxNToiYXBwcm92YWxfc3RhdHVzIjtzOjg6IkFwcHJvdmVkIjtzOjE2OiJyZWplY3Rpb25fcmVhc29uIjtOO3M6MTM6ImZhY2Vib29rX2xpbmsiO3M6MjU6Imh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS8iO3M6MTQ6Imluc3RhZ3JhbV9saW5rIjtzOjI2OiJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tLyI7czoxMjoidHdpdHRlcl9saW5rIjtzOjI0OiJodHRwczovL3d3dy50d2l0dGVyLmNvbS8iO3M6OToieWVscF9saW5rIjtOO3M6MjA6Imdvb2dsZV9idXNpbmVzc19saW5rIjtzOjI4OiJodHRwczovL2J1c2luZXNzLmdvb2dsZS5jb20vIjtzOjk6IndpZmlfbmFtZSI7TjtzOjEzOiJ3aWZpX3Bhc3N3b3JkIjtOO3M6MTQ6InNob3dfd2lmaV9pY29uIjtpOjA7czoxNDoidGFibGVfcmVxdWlyZWQiO2k6MDtzOjE0OiJzaG93X2xvZ29fdGV4dCI7aToxO3M6MTI6Im1ldGFfa2V5d29yZCI7TjtzOjE2OiJtZXRhX2Rlc2NyaXB0aW9uIjtOO3M6MzQ6InVwbG9hZF9mYXZfaWNvbl9hbmRyb2lkX2Nocm9tZV8xOTIiO047czozNDoidXBsb2FkX2Zhdl9pY29uX2FuZHJvaWRfY2hyb21lXzUxMiI7TjtzOjMyOiJ1cGxvYWRfZmF2X2ljb25fYXBwbGVfdG91Y2hfaWNvbiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8xNiI7TjtzOjE3OiJ1cGxvYWRfZmF2aWNvbl8zMiI7TjtzOjc6ImZhdmljb24iO047czozNjoiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9kZXNrdG9wIjtpOjE7czozNToiaXNfd2FpdGVyX3JlcXVlc3RfZW5hYmxlZF9vbl9tb2JpbGUiO2k6MTtzOjM2OiJpc193YWl0ZXJfcmVxdWVzdF9lbmFibGVkX29wZW5fYnlfcXIiO2k6MDtzOjExOiJ3ZWJtYW5pZmVzdCI7TjtzOjE1OiJlbmFibGVfdGlwX3Nob3AiO2k6MTtzOjE0OiJlbmFibGVfdGlwX3BvcyI7aToxO3M6MjU6ImlzX3B3YV9pbnN0YWxsX2FsZXJ0X3Nob3ciO2k6MDtzOjE5OiJhdXRvX2NvbmZpcm1fb3JkZXJzIjtpOjA7czozNDoiYXV0b19jb25maXJtX29yZGVyc19iZWZvcmVfcGF5bWVudCI7aTowO3M6MzM6ImF1dG9fY29uZmlybV9vcmRlcnNfYWZ0ZXJfcGF5bWVudCI7aTowO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtpOjA7czoyMjoicXJfb3JkZXJfcmFkaXVzX21ldGVycyI7TjtzOjIzOiJzaG93X29yZGVyX3R5cGVfb3B0aW9ucyI7aToxO3M6MjQ6ImRpc2FibGVfb3JkZXJfdHlwZV9wb3B1cCI7aTowO3M6MjY6InJlc3RhdXJhbnRfb3Blbl9jbG9zZV9tb2RlIjtzOjQ6ImF1dG8iO3M6MzM6InJlc3RhdXJhbnRfbWFudWFsX29wZW5fY2xvc2VfdHlwZSI7czo0OiJ0aW1lIjtzOjE2OiJtYW51YWxfb3Blbl90aW1lIjtOO3M6MTc6Im1hbnVhbF9jbG9zZV90aW1lIjtOO3M6MjE6ImlzX3RlbXBvcmFyaWx5X2Nsb3NlZCI7aTowO3M6MjE6ImRlZmF1bHRfb3JkZXJfdHlwZV9pZCI7TjtzOjI3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9wb3MiO2k6MDtzOjM3OiJoaWRlX21lbnVfaXRlbV9pbWFnZV9vbl9jdXN0b21lcl9zaXRlIjtpOjA7czoyODoibWVudV9pdGVtX2RlZmF1bHRfaW1hZ2VfcGF0aCI7TjtzOjMxOiJkaXNhYmxlX21lbnVfaXRlbV9kZWZhdWx0X2ltYWdlIjtpOjA7czo4OiJ0YXhfbW9kZSI7czo1OiJvcmRlciI7czoxMzoidGF4X2luY2x1c2l2ZSI7aTowO3M6Mjc6ImluY2x1ZGVfY2hhcmdlc19pbl90YXhfYmFzZSI7aTowO3M6MjI6ImN1c3RvbWVyX3NpdGVfbGFuZ3VhZ2UiO3M6MjoiZW4iO3M6MjQ6ImVuYWJsZV9hZG1pbl9yZXNlcnZhdGlvbiI7aToxO3M6Mjc6ImVuYWJsZV9jdXN0b21lcl9yZXNlcnZhdGlvbiI7aToxO3M6MTg6Im1pbmltdW1fcGFydHlfc2l6ZSI7aToxO3M6MjY6InRhYmxlX2xvY2tfdGltZW91dF9taW51dGVzIjtpOjEwO3M6MTg6Im1vbGxpZV9jdXN0b21lcl9pZCI7TjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO2k6MTt9czoxMDoiACoAY2hhbmdlcyI7YTowOnt9czoxMToiACoAcHJldmlvdXMiO2E6MDp7fXM6ODoiACoAY2FzdHMiO2E6MTg6e3M6MTc6ImxpY2Vuc2VfZXhwaXJlX29uIjtzOjg6ImRhdGV0aW1lIjtzOjE1OiJ0cmlhbF9leHBpcmVfb24iO3M6ODoiZGF0ZXRpbWUiO3M6MTg6ImxpY2Vuc2VfdXBkYXRlZF9hdCI7czo4OiJkYXRldGltZSI7czoyMzoic3Vic2NyaXB0aW9uX3VwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6ODoiZGF0ZXRpbWUiO3M6MjM6ImN1c3RvbV9kZWxpdmVyeV9vcHRpb25zIjtzOjU6ImFycmF5IjtzOjk6ImlzX2FjdGl2ZSI7czo3OiJib29sZWFuIjtzOjI0OiJlbmFibGVfYWRtaW5fcmVzZXJ2YXRpb24iO3M6NzoiYm9vbGVhbiI7czoyNzoiZW5hYmxlX2N1c3RvbWVyX3Jlc2VydmF0aW9uIjtzOjc6ImJvb2xlYW4iO3M6Mjk6InJlc3RyaWN0X3FyX29yZGVyX2J5X2xvY2F0aW9uIjtzOjc6ImJvb2xlYW4iO3M6MTA6ImFpX2VuYWJsZWQiO3M6NzoiYm9vbGVhbiI7czoxNjoiYWlfYWxsb3dlZF9yb2xlcyI7czo1OiJhcnJheSI7czoxOToiYWlfbW9udGhseV9yZXNldF9hdCI7czo0OiJkYXRlIjtzOjIxOiJpc190ZW1wb3JhcmlseV9jbG9zZWQiO3M6NzoiYm9vbGVhbiI7czozMzoicmVzdGF1cmFudF9tYW51YWxfb3Blbl9jbG9zZV90eXBlIjtzOjY6InN0cmluZyI7czozMToiZGlzYWJsZV9tZW51X2l0ZW1fZGVmYXVsdF9pbWFnZSI7czo3OiJib29sZWFuIjtzOjMzOiJhdXRvX21hcmtfb3JkZXJfY29tcGxldGVkX29uX3BhaWQiO3M6NzoiYm9vbGVhbiI7fXM6MTc6IgAqAGNsYXNzQ2FzdENhY2hlIjthOjA6e31zOjIxOiIAKgBhdHRyaWJ1dGVDYXN0Q2FjaGUiO2E6MDp7fXM6MTM6IgAqAGRhdGVGb3JtYXQiO047czoxMDoiACoAYXBwZW5kcyI7YToyOntpOjA7czo4OiJsb2dvX3VybCI7aToxO3M6MTM6ImRhcmtfbG9nb191cmwiO31zOjE5OiIAKgBkaXNwYXRjaGVzRXZlbnRzIjthOjA6e31zOjE0OiIAKgBvYnNlcnZhYmxlcyI7YTowOnt9czoxMjoiACoAcmVsYXRpb25zIjthOjA6e31zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjoxO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MDp7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MjoiaWQiO31zOjE3OiJjdXN0b21lcklwQWRkcmVzcyI7TjtzOjI0OiJlc3RpbWF0aW9uQmlsbGluZ0FkZHJlc3MiO2E6MDp7fXM6MTM6ImNvbGxlY3RUYXhJZHMiO2I6MDtzOjg6ImNvdXBvbklkIjtOO3M6MTU6InByb21vdGlvbkNvZGVJZCI7TjtzOjE5OiJhbGxvd1Byb21vdGlvbkNvZGVzIjtiOjA7fX1zOjEwOiIAKgB0b3VjaGVzIjthOjA6e31zOjI3OiIAKgByZWxhdGlvbkF1dG9sb2FkQ2FsbGJhY2siO047czoyNjoiACoAcmVsYXRpb25BdXRvbG9hZENvbnRleHQiO047czoxMDoidGltZXN0YW1wcyI7YjowO3M6MTM6InVzZXNVbmlxdWVJZHMiO2I6MDtzOjk6IgAqAGhpZGRlbiI7YTowOnt9czoxMDoiACoAdmlzaWJsZSI7YTowOnt9czoxMToiACoAZmlsbGFibGUiO2E6MDp7fXM6MTA6IgAqAGd1YXJkZWQiO2E6MTp7aTowO3M6MToiKiI7fX1zOjg6ImN1cnJlbmN5IjtzOjM6IuCnsyI7czo1OiJpc1J0bCI7YjowO3M6MTY6Imxhc3Rfb3JkZXJfY291bnQiO2k6MDtzOjE3OiJ0b2RheV9vcmRlcl9jb3VudCI7aTowO3M6Mjg6ImFjdGl2ZV93YWl0ZXJfcmVxdWVzdHNfY291bnQiO2k6MDtzOjg6ImJyYW5jaGVzIjtyOjExODA7czoyMzoiY3VycmVuY3lfZm9ybWF0X3NldHRpbmciO3I6MTgxMDt9',1785042919);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `split_order_items`
--

DROP TABLE IF EXISTS `split_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `split_order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `split_order_id` bigint unsigned NOT NULL,
  `order_item_id` bigint unsigned NOT NULL,
  `quantity` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `split_order_items_split_order_id_foreign` (`split_order_id`),
  KEY `split_order_items_order_item_id_foreign` (`order_item_id`),
  CONSTRAINT `split_order_items_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `split_order_items_split_order_id_foreign` FOREIGN KEY (`split_order_id`) REFERENCES `split_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `split_order_items`
--

LOCK TABLES `split_order_items` WRITE;
/*!40000 ALTER TABLE `split_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `split_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `split_orders`
--

DROP TABLE IF EXISTS `split_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `split_orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `status` enum('pending','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` enum('cash','upi','card','bank_transfer','due','stripe','razorpay') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `payer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `split_orders_order_id_foreign` (`order_id`),
  CONSTRAINT `split_orders_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `split_orders`
--

LOCK TABLES `split_orders` WRITE;
/*!40000 ALTER TABLE `split_orders` DISABLE KEYS */;
INSERT INTO `split_orders` VALUES (1,21,200.00,'paid','cash','01','2026-06-09 01:23:20','2026-06-09 01:23:20'),(2,21,200.00,'paid','cash','02','2026-06-09 01:23:20','2026-06-09 01:23:20'),(3,21,164.00,'paid','cash','03','2026-06-09 01:23:20','2026-06-09 01:23:20'),(4,28,200.00,'paid','cash','df','2026-06-09 03:13:29','2026-06-09 03:13:29'),(5,28,200.00,'paid','cash','gf','2026-06-09 03:13:29','2026-06-09 03:13:29'),(6,28,175.00,'paid','cash','fgf','2026-06-09 03:13:29','2026-06-09 03:13:29'),(7,29,500.00,'paid','cash','01','2026-06-09 03:18:10','2026-06-09 03:18:10'),(8,29,500.00,'paid','cash','02','2026-06-09 03:18:10','2026-06-09 03:18:10'),(9,29,500.00,'paid','cash','03','2026-06-09 03:18:10','2026-06-09 03:18:10'),(10,29,500.00,'paid','cash','04','2026-06-09 03:18:10','2026-06-09 03:18:10'),(11,30,500.00,'paid','cash','01','2026-06-09 03:19:35','2026-06-09 03:19:35'),(12,30,500.00,'paid','cash','02','2026-06-09 03:19:35','2026-06-09 03:19:35'),(13,30,500.00,'paid','cash','03','2026-06-09 03:19:35','2026-06-09 03:19:35'),(14,30,800.00,'paid','cash','04','2026-06-09 03:19:35','2026-06-09 03:19:35'),(15,31,500.00,'paid','cash','01','2026-06-09 03:22:42','2026-06-09 03:22:42'),(16,31,500.00,'paid','cash','02','2026-06-09 03:22:42','2026-06-09 03:22:42'),(17,31,500.00,'paid','cash','03','2026-06-09 03:22:42','2026-06-09 03:22:42'),(18,31,1375.00,'paid','cash','04','2026-06-09 03:22:42','2026-06-09 03:22:42'),(19,32,575.00,'paid','cash','01','2026-06-09 03:24:21','2026-06-09 03:24:21'),(20,32,575.00,'paid','cash','2','2026-06-09 03:24:21','2026-06-09 03:24:21'),(21,32,575.00,'paid','cash','03','2026-06-09 03:24:21','2026-06-09 03:24:21'),(22,32,575.00,'paid','cash','04','2026-06-09 03:24:21','2026-06-09 03:24:21'),(23,37,69.00,'paid','cash',NULL,'2026-06-09 04:00:53','2026-06-09 04:00:53'),(24,37,69.00,'paid','cash',NULL,'2026-06-09 04:00:53','2026-06-09 04:00:53'),(25,38,287.50,'paid','cash','01','2026-06-09 04:01:17','2026-06-09 04:01:17'),(26,38,287.50,'paid','cash','02','2026-06-09 04:01:17','2026-06-09 04:01:17'),(27,42,5.75,'paid','cash','01','2026-06-09 04:03:41','2026-06-09 04:03:41'),(28,42,5.75,'paid','cash','02','2026-06-09 04:03:41','2026-06-09 04:03:41'),(29,44,69.00,'paid','due','014','2026-06-09 04:05:45','2026-06-09 04:05:45'),(30,44,69.00,'paid','bank_transfer',NULL,'2026-06-09 04:05:45','2026-06-09 04:05:45'),(31,44,69.00,'paid','cash',NULL,'2026-06-09 04:05:45','2026-06-09 04:05:45');
/*!40000 ALTER TABLE `split_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_payments`
--

DROP TABLE IF EXISTS `stripe_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stripe_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `payment_status` enum('pending','requested','declined','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_error_response` text COLLATE utf8mb4_unicode_ci,
  `stripe_payment_intent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_session_id` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stripe_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `stripe_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_payments`
--

LOCK TABLES `stripe_payments` WRITE;
/*!40000 ALTER TABLE `stripe_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `superadmin_payment_gateways`
--

DROP TABLE IF EXISTS `superadmin_payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `superadmin_payment_gateways` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `razorpay_type` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_razorpay_key` text COLLATE utf8mb4_unicode_ci,
  `test_razorpay_secret` text COLLATE utf8mb4_unicode_ci,
  `razorpay_test_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `live_razorpay_key` text COLLATE utf8mb4_unicode_ci,
  `live_razorpay_secret` text COLLATE utf8mb4_unicode_ci,
  `razorpay_live_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `razorpay_status` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_type` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_stripe_key` text COLLATE utf8mb4_unicode_ci,
  `test_stripe_secret` text COLLATE utf8mb4_unicode_ci,
  `stripe_test_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `live_stripe_key` text COLLATE utf8mb4_unicode_ci,
  `live_stripe_secret` text COLLATE utf8mb4_unicode_ci,
  `stripe_live_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `stripe_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `flutterwave_status` tinyint(1) NOT NULL DEFAULT '0',
  `flutterwave_type` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_flutterwave_key` text COLLATE utf8mb4_unicode_ci,
  `test_flutterwave_secret` text COLLATE utf8mb4_unicode_ci,
  `test_flutterwave_hash` text COLLATE utf8mb4_unicode_ci,
  `flutterwave_test_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `live_flutterwave_key` text COLLATE utf8mb4_unicode_ci,
  `live_flutterwave_secret` text COLLATE utf8mb4_unicode_ci,
  `live_flutterwave_hash` text COLLATE utf8mb4_unicode_ci,
  `flutterwave_live_webhook_key` text COLLATE utf8mb4_unicode_ci,
  `live_paypal_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_paypal_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paypal_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paypal_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_status` tinyint(1) NOT NULL DEFAULT '0',
  `paypal_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `live_payfast_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_payfast_merchant_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_payfast_passphrase` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_payfast_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_payfast_merchant_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_payfast_passphrase` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payfast_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `payfast_status` tinyint(1) NOT NULL DEFAULT '0',
  `live_paystack_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_paystack_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_paystack_merchant_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paystack_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paystack_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paystack_merchant_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_payment_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'https://api.paystack.co',
  `paystack_status` tinyint(1) NOT NULL DEFAULT '0',
  `paystack_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `xendit_status` tinyint(1) NOT NULL DEFAULT '0',
  `xendit_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `test_xendit_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_xendit_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_xendit_webhook_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_xendit_webhook_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paddle_status` tinyint(1) NOT NULL DEFAULT '0',
  `paddle_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `test_paddle_vendor_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paddle_api_key` text COLLATE utf8mb4_unicode_ci,
  `test_paddle_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_paddle_client_token` text COLLATE utf8mb4_unicode_ci,
  `live_paddle_vendor_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_paddle_api_key` text COLLATE utf8mb4_unicode_ci,
  `live_paddle_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_paddle_client_token` text COLLATE utf8mb4_unicode_ci,
  `paddle_webhook_secret` text COLLATE utf8mb4_unicode_ci,
  `mollie_status` tinyint(1) NOT NULL DEFAULT '0',
  `mollie_mode` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `test_mollie_key` text COLLATE utf8mb4_unicode_ci,
  `live_mollie_key` text COLLATE utf8mb4_unicode_ci,
  `tap_merchant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_tap_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_tap_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_tap_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_tap_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tap_status` tinyint(1) NOT NULL DEFAULT '0',
  `tap_mode` enum('sandbox','live') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `superadmin_payment_gateways`
--

LOCK TABLES `superadmin_payment_gateways` WRITE;
/*!40000 ALTER TABLE `superadmin_payment_gateways` DISABLE KEYS */;
INSERT INTO `superadmin_payment_gateways` VALUES (1,'test',NULL,NULL,NULL,NULL,NULL,NULL,0,'test',NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-06-05 23:41:48','2026-06-05 23:41:48',0,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,'sandbox',0,NULL,NULL,NULL,NULL,NULL,NULL,'https://api.paystack.co',0,'sandbox',0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox'),(2,'test',NULL,NULL,NULL,NULL,NULL,NULL,0,'test',NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-06-05 23:44:10','2026-06-05 23:44:10',0,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,'sandbox',0,NULL,NULL,NULL,NULL,NULL,NULL,'https://api.paystack.co',0,'sandbox',0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'sandbox');
/*!40000 ALTER TABLE `superadmin_payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_sessions`
--

DROP TABLE IF EXISTS `table_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `table_id` bigint unsigned NOT NULL,
  `locked_by_user_id` bigint unsigned DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `session_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_sessions_session_token_unique` (`session_token`),
  KEY `table_sessions_branch_id_foreign` (`branch_id`),
  KEY `table_sessions_locked_by_user_id_foreign` (`locked_by_user_id`),
  KEY `table_sessions_table_id_locked_by_user_id_index` (`table_id`,`locked_by_user_id`),
  KEY `table_sessions_last_activity_at_index` (`last_activity_at`),
  CONSTRAINT `table_sessions_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `table_sessions_locked_by_user_id_foreign` FOREIGN KEY (`locked_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `table_sessions_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_sessions`
--

LOCK TABLES `table_sessions` WRITE;
/*!40000 ALTER TABLE `table_sessions` DISABLE KEYS */;
INSERT INTO `table_sessions` VALUES (1,3,7,NULL,NULL,NULL,'0QGKelmcp3zT7oxfz5x9Z1pnKwXRLQtb','2026-06-10 01:28:52','2026-06-10 01:28:52'),(2,3,5,NULL,NULL,NULL,NULL,'2026-06-10 01:30:33','2026-06-10 05:24:56'),(3,3,9,NULL,NULL,NULL,'28UNhL0Ao4imf1ZKFA4a1q7Dc7SwrQeS','2026-06-10 03:32:28','2026-06-10 03:32:28'),(4,3,2,NULL,NULL,NULL,NULL,'2026-06-10 03:38:26','2026-06-10 03:45:56');
/*!40000 ALTER TABLE `table_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tables`
--

DROP TABLE IF EXISTS `tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tables` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned DEFAULT NULL,
  `table_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `available_status` enum('available','reserved','running') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `area_id` bigint unsigned NOT NULL,
  `seating_capacity` tinyint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tables_area_id_foreign` (`area_id`),
  KEY `idx_tables_branch_code` (`branch_id`,`table_code`),
  KEY `idx_tables_branch_status` (`branch_id`,`available_status`),
  CONSTRAINT `tables_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tables_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tables`
--

LOCK TABLES `tables` WRITE;
/*!40000 ALTER TABLE `tables` DISABLE KEYS */;
INSERT INTO `tables` VALUES (1,1,'T01','878917d15d1b13ff2a50baa2bbfa1e21','active','available',1,4,'2026-06-06 02:05:27','2026-06-06 02:05:27'),(2,3,'GA-01','f8c26f6ba516562fa46bde2949f64c13','active','available',2,6,'2026-06-10 01:13:41','2026-06-10 03:45:56'),(3,3,'GA-02','58d9368a9a0eca70889a9d94dadfca31','active','available',2,5,'2026-06-10 01:18:11','2026-06-10 01:18:11'),(4,3,'GA-03','cd4e7edadc6364106b403a91179c95f2','active','available',2,8,'2026-06-10 01:18:28','2026-06-10 01:18:28'),(5,3,'Fl-01','76c27677b9ad0765d2f52c335664a8a0','active','available',3,6,'2026-06-10 01:26:30','2026-06-10 05:24:56'),(6,3,'Fl-02','3411df4afc7374bc722ea2a41da363fd','active','available',3,8,'2026-06-10 01:26:43','2026-06-10 01:26:43'),(7,3,'Fl-03','12748d9a4880d962b25ab66edf90ec27','active','available',3,5,'2026-06-10 01:27:03','2026-06-10 01:27:03'),(8,3,'Rf-01','0584308ca43fe02449cff4ad5bbebaf7','inactive','available',4,4,'2026-06-10 01:27:20','2026-06-10 01:30:02'),(9,3,'Rf-02','fc1a1184cbcf9f831754e6954679f17a','active','available',4,4,'2026-06-10 01:27:53','2026-06-10 03:44:49'),(10,3,'Rf-03','f5cd4612d47f651cfd6c258cbe8ee334','active','available',4,2,'2026-06-10 01:28:12','2026-06-10 01:28:12'),(11,3,'Rf-04','3197d8f45890a9c1b3fd9fdaea6ab9b6','active','available',4,3,'2026-06-10 01:28:27','2026-06-10 01:28:27'),(12,1,'T02','c64773e68a8495035a378ea3e57e1f2b','active','available',1,6,'2026-06-10 04:16:38','2026-06-10 04:18:59');
/*!40000 ALTER TABLE `tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tap_payments`
--

DROP TABLE IF EXISTS `tap_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tap_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tap_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_error_response` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tap_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `tap_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tap_payments`
--

LOCK TABLES `tap_payments` WRITE;
/*!40000 ALTER TABLE `tap_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tap_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `tax_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_percent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taxes_restaurant_id_foreign` (`restaurant_id`),
  KEY `taxes_branch_id_foreign` (`branch_id`),
  CONSTRAINT `taxes_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `taxes_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` VALUES (3,1,2,'SGST','2.5','2026-06-05 23:44:10','2026-06-05 23:44:10'),(4,1,2,'CGST','2.5','2026-06-05 23:44:10','2026-06-05 23:44:10'),(7,1,1,'Demo Tax','10','2026-06-08 23:31:49','2026-06-08 23:31:49'),(8,1,3,'Demo Tax','10','2026-06-10 00:34:49','2026-06-10 00:34:49');
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms_and_privacy_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `marketing_emails_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_restaurant_id_foreign` (`restaurant_id`),
  KEY `users_stripe_id_index` (`stripe_id`),
  KEY `idx_branch_email` (`branch_id`,`email`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,'Emma Holden','superadmin@example.com',NULL,NULL,0,0,NULL,'$2y$12$2lzVZZwpBpSpo4N1KowTT.1N.Q6V7xrWf9yQ2HcScvnO2yViUzns6',NULL,NULL,NULL,'cLeJybYXhzDsJXORNk8nGfqezCJgURodigt7lHzVmTfBze1UjCqVGK56uDHu',NULL,NULL,'2026-06-05 23:44:08','2026-06-05 23:44:08','en',NULL,NULL,NULL,NULL),(2,1,NULL,'John Doe','admin@example.com',NULL,NULL,0,0,NULL,'$2y$12$dOinNcSC5J6HfgAKpr.Uo.hQuTuvoZMns0CW7q/GasNov.Q9.Jvly',NULL,NULL,NULL,'HAGp9fTBhShrDXu1YaCy6VsrX8Zzp1bN8e3zPmE46k8dcFdzOmpLUTTiOmkM',NULL,NULL,'2026-06-05 23:44:10','2026-06-05 23:44:10','en',NULL,NULL,NULL,NULL),(3,1,1,'Waiter 1','waiter@example.com',NULL,NULL,0,0,NULL,'$2y$12$VZiTHbcgd0B9eNV0wuIHiu6T9bAZTQmXNbl96XCl47CgGHHMRQE86',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 23:44:11','2026-06-05 23:44:11','en',NULL,NULL,NULL,NULL),(4,1,1,'Waiter 2','waiter2@example.com',NULL,NULL,0,0,NULL,'$2y$12$hdLTZgPmabLunt/R4T4wiOReYy4UgYaeB8GY6FY/hnUFvy07oRUL6',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 23:44:11','2026-06-05 23:44:11','en',NULL,NULL,NULL,NULL),(5,1,1,'Waiter 3','waiter3@example.com',NULL,NULL,0,0,NULL,'$2y$12$En4U6PIqaQ0n4LwHUSP8Huy2xTPkXHuWDZER5oKw0Q3VUT0xeauFy',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 23:44:11','2026-06-05 23:44:11','en',NULL,NULL,NULL,NULL),(6,1,1,'Waiter 4','waiter4@example.com',NULL,NULL,0,0,NULL,'$2y$12$Jjto2Z3DOmto3NM7oRc7T.RraL/6yG3gEU1OxJOImig4.UarRTWuW',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 23:44:12','2026-06-05 23:44:12','en',NULL,NULL,NULL,NULL),(7,1,1,'Waiter 5','waiter5@example.com',NULL,NULL,0,0,NULL,'$2y$12$bIUiT01cK0/oZMq.9Cw9cer4NDGTvvIMLg9adIkgaYyad239Bp/.q',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 23:44:12','2026-06-05 23:44:12','en',NULL,NULL,NULL,NULL),(8,1,1,'50%','admin-second@gmail.com','17123456789','880',0,0,NULL,'$2y$12$RhQN8I82UKvq2qr5PMqP1O4.OQtp/Wfe4qY0d94FPqyxdO./Vrpw.',NULL,NULL,NULL,'rgUzrGgbZdfor7PectMi3mKnq0tJfAhxBqaEXVcJPqr7nQ555krynaajqEZ1',NULL,NULL,'2026-06-06 02:41:56','2026-06-06 02:41:56','en',NULL,NULL,NULL,NULL),(9,1,1,'table02','dev4retailsolution@gmail.com','1909430970','880',0,0,NULL,'$2y$12$h9QtShsuZI8tHj39gubCf.VjIMtlwOsnztPoRGJxYTsgs3m8T4Jr6',NULL,NULL,NULL,'ViuUswj8FHDo7D0VUSaDFpkmHvgzHDeVQanPnzzCzCQZ31atpLeaWQhtCU7U',NULL,NULL,'2026-06-09 04:52:22','2026-06-09 04:52:22','en',NULL,NULL,NULL,NULL),(10,1,3,'manager','manager@gmail.com','1909430970','880',0,0,NULL,'$2y$12$ntZFHg7Vlyfl8Gd0c3vmOOk4F18Sfwy3kvAuAPytIhTcV7uOaELkq',NULL,NULL,NULL,'roDBPix4Ikg8u4pbwkYS5le9zliyvDjzJv3kfExP2DtWM3cyUkugTChlTMfm',NULL,NULL,'2026-06-10 02:10:11','2026-06-10 02:10:11','en',NULL,NULL,NULL,NULL),(11,1,3,'waiter-01','waiter@gmail.com','01909430970','880',0,0,NULL,'$2y$12$sg4SLPDVNDe6tsHWUO.8kOQvUL5MOurlav/daxsdcoDiWBc5TiAaS',NULL,NULL,NULL,'YXECnII0P1ep6XiqGUS7tArDaCek92ia8ZHbnTa7hszblOJFIZB13M8EoRbH',NULL,NULL,'2026-06-10 02:10:53','2026-06-10 03:04:27','en',NULL,NULL,NULL,NULL),(12,1,3,'chef-01','chef@gmail.com','01909430970','880',0,0,NULL,'$2y$12$lFqUbErEUMDQ8nR.OKXehuS5ARYmUht90bThWwNdqqHLHGWaGL2vC',NULL,NULL,NULL,'shAnQsHPUj4ON08q5rOtiTJ2XnUeVPrPLkQw2F1l5wgQpdv5UxdKki4P9ek5',NULL,NULL,'2026-06-10 02:11:34','2026-06-10 03:04:52','en',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waiter_requests`
--

DROP TABLE IF EXISTS `waiter_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `waiter_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` bigint unsigned NOT NULL,
  `table_id` bigint unsigned NOT NULL,
  `status` enum('pending','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waiter_requests_branch_id_foreign` (`branch_id`),
  KEY `waiter_requests_table_id_foreign` (`table_id`),
  CONSTRAINT `waiter_requests_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `waiter_requests_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waiter_requests`
--

LOCK TABLES `waiter_requests` WRITE;
/*!40000 ALTER TABLE `waiter_requests` DISABLE KEYS */;
INSERT INTO `waiter_requests` VALUES (1,3,5,'completed','2026-06-10 04:03:36','2026-06-10 05:22:07'),(2,3,5,'completed','2026-06-10 04:04:30','2026-06-10 05:22:07'),(3,3,9,'pending','2026-06-10 04:21:40','2026-06-10 04:21:40'),(4,3,5,'completed','2026-06-10 04:22:26','2026-06-10 05:22:07'),(5,3,5,'completed','2026-06-10 04:30:15','2026-06-10 05:22:07'),(6,3,5,'completed','2026-06-10 04:44:48','2026-06-10 05:22:07'),(7,3,5,'completed','2026-06-10 04:55:27','2026-06-10 05:22:07'),(8,3,5,'completed','2026-06-10 05:22:03','2026-06-10 05:22:07');
/*!40000 ALTER TABLE `waiter_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xendit_payments`
--

DROP TABLE IF EXISTS `xendit_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xendit_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `payment_status` enum('pending','requested','declined','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_error_response` text COLLATE utf8mb4_unicode_ci,
  `xendit_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xendit_invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xendit_external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `xendit_payments_order_id_foreign` (`order_id`),
  CONSTRAINT `xendit_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xendit_payments`
--

LOCK TABLES `xendit_payments` WRITE;
/*!40000 ALTER TABLE `xendit_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `xendit_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tabletra1_v1_3_02'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-26 11:16:02
